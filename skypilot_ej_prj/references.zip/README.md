# Reproducing the Kubernetes launch-latency benchmarks

`reproduce_benchmarks.py` reruns every measurement behind the launch-latency
design docs in this directory:

- the `sky jobs launch` A/B against master;
- the breakdown of the provisioning phase (phase D);
- the storage-cloud lookup probe;
- the pod-side probes;
- the `imagePullPolicy` test.

This README sets it up in a fresh clone.

| Subcommand | What it measures | Results in `launch_latency_consolidated_design.md` | Time with defaults |
|---|---|---|---|
| `jobs-ab` | `sky jobs launch` A/B of two git refs: per-phase times A–H, phase D split into stages, permutation test | §13 (4 nodes), §14 (6 nodes), §15 | ~22 min |
| `storage-probe` | Duration and caller of each storage-cloud lookup inside `jobs.launch`, for two refs | §13 | ~6 min |
| `pod-probe` | One throwaway cluster, measured inside its pods (see [pod-probe](#pod-probe)) | §15 | ~2 min |
| `pull-policy` | Pod start time with `imagePullPolicy: IfNotPresent` against the template's `Always` | §15 | ~5 min |
| `sky-launch-ab` | The `sky launch` A/B, run through `bench_launch_latency.py` | §7.1 | ~30 min |

The phases A–H and the stages of phase D are defined in
`launch_latency_consolidated_design.md` §13 and §15. The script's own `--help`
lists them too.

## 1. Prerequisites

- **Linux or macOS**, with `git`, `kubectl` and [`uv`](https://docs.astral.sh/uv/)
  on `PATH`.
- **Docker and [kind](https://kind.sigs.k8s.io/)**, if you use the local test
  cluster described below.
- **CPU.** The published numbers come from one kind node with 12 cores. A run
  needs one core per task node, plus room for the jobs controller, which runs
  inside the API server. For `--nodes 6`, 8 or more free cores are enough.
- **An idle SkyPilot setup.** The script fails if another managed job is in
  progress.
  - **It stops and restarts your local API server.** `jobs-ab` and
    `storage-probe` restart it on each ref they test. Other clients of that
    server lose it while the benchmark runs.
  - **It shares `~/.sky` with your normal work.** Clusters and jobs you
    launch at the same time slow the runs down.

## 2. Set up a clean clone

### 2.1 Clone the repo and fetch the branches

```bash
git clone https://github.com/skypilot-org/skypilot.git skypilot-bench
cd skypilot-bench

# The optimization branches live on the fork.
git remote add fork https://github.com/siliconej/skypilot.git
git fetch fork

# The default candidate ref is the local branch ej-prj-3-job1.
git branch ej-prj-3-job1 fork/ej-prj-3-job1
```

### 2.2 Create the virtualenv

The install must be editable (`-e`). The script switches the checkout between
refs and restarts the API server, which then runs whatever code is checked
out.

```bash
uv venv --seed --python 3.11
source .venv/bin/activate
uv pip install -e ".[kubernetes]"
```

### 2.3 Copy in the `ej/` scripts

`ej/` is not committed on any branch, so a fresh clone doesn't have it. Copy
it in from a working tree that does:

```bash
mkdir -p ej
cp /path/to/your/skypilot/ej/{reproduce_benchmarks.py,bench_launch_latency.py,job.yaml,README.md} ej/

# Have git ignore ej/ locally.
echo 'ej/' >> .git/info/exclude
```

Keep `ej/` **untracked**:

- **Why:** `jobs-ab` and `storage-probe` switch between the base and the
  candidate. If `ej/` were committed on only one of them, switching would
  delete the scripts and the result directory under them, or refuse to switch.
- **What git checks:** the script refuses to start when *tracked* files have
  uncommitted changes. Untracked files are never touched.

### 2.4 Create a Kubernetes cluster and enable it

```bash
# Creates the kind cluster and the kubectl context `kind-skypilot`.
sky local up
sky check kubernetes
```

If `~/.sky/config.yaml` sets `kubernetes.allowed_contexts`, the list must
include `kind-skypilot`. To use a different cluster, pass
`--context <name>` to every subcommand.

### 2.5 Pull the image before you measure

The first pod on a node pulls the SkyPilot image, which is several GB. Do one
throwaway launch so that no measured run includes the pull:

```bash
sky api start --deploy
sky launch -y -c bench-warm --infra k8s/kind-skypilot --cpus 1+ --memory 1+ 'echo ok'
sky down -y bench-warm
```

## 3. Run the benchmarks

Run every command from the repo root, with the venv active.

### `jobs-ab`

Reproduces §14 (6 nodes) of the consolidated design doc. The arms are pinned
to the commits used there.

```bash
python ej/reproduce_benchmarks.py jobs-ab --nodes 6 \
    --base 815e61a76 --candidate 7aeec8ede
```

- **Commits:** `815e61a76` is master as of 2026-10-31. `7aeec8ede` is
  `ej-prj-3-job1` without the later `.pyi` stub fix, which changes nothing at
  runtime.
- **Defaults:** the base is `origin/master` and the candidate is
  `ej-prj-3-job1`. Without the flags you measure the current master instead.
- **4-node run (§13):** use `--nodes 4`.

How it runs:

1. **4 alternating blocks:** base, candidate, base, candidate.
2. **A server restart before each block,** on that block's ref. The script
   checks that the server reports the expected commit.
3. **1 warm-up run per block,** which is dropped, then **4 measured runs.**
   That gives 8 measured runs per side.
4. **A wait for teardown after each run.** The script waits until the job's
   pods are gone, so a teardown never overlaps the next run or restart.

A run whose trace saw another job (`CONTAMINATED`), or that failed, is
excluded from the statistics. Change the sample size with `--blocks`,
`--runs` and `--warmup`.

### `storage-probe`

```bash
python ej/reproduce_benchmarks.py storage-probe --nodes 6 \
    --base 815e61a76 --candidate 7aeec8ede
```

- **What it does:** patches `sky/data/storage.py` for the duration of the run,
  so that each storage-cloud lookup is logged with its duration and caller.
  The patch is reverted afterwards.
- **Expected result:**
  - **2 lookups per launch** on both refs.
  - **The first takes about 4.8 s** on both refs.
  - **The second takes about 0.2–0.3 s on master** and about 0.001 s on the
    candidate.

### `pod-probe`

```bash
git switch ej-prj-3-job1 && sky api stop && sky api start --deploy
python ej/reproduce_benchmarks.py pod-probe --nodes 6
```

- **What it measures:**
  - the per-pod `uv` dry-run resolve and the setup-marker time;
  - the per-worker waits in `setup_runtime_on_cluster`;
  - an offline against an online wheel resolve;
  - a cold against a warm `attempt_skylet` import.
- **What it tests:** the code of the API server that is currently running,
  which is why the first line restarts the server on the branch. `jobs-ab`
  and `storage-probe` handle that themselves.
- **Cluster:** `bench-pod-probe`, torn down afterwards. Pass `--keep` to
  inspect the pods yourself. Cluster names must start with `bench-`.

### `pull-policy`

```bash
python ej/reproduce_benchmarks.py pull-policy --nodes 6
```

- **What it does:** launches `bench-pull-always` 3 times with the template's
  policy, then `bench-pull-ifnotpresent` 3 times. The second set overrides the
  policy through the task's `config.kubernetes.pod_config`.
- **Reported time:** pods created to Running, from `provision.log`.
- **Check:** confirm that the "Policy on the pod" column reads
  `IfNotPresent` for the second set.
- **Sample size:** use `--runs` and `--baseline-runs`.

### `sky-launch-ab`

```bash
python ej/reproduce_benchmarks.py sky-launch-ab -- \
    run --candidate-ref ej-prj-3-job1 --task ej/job.yaml --runs 5
```

- **What it does:** passes its arguments to `ej/bench_launch_latency.py`.
- **Isolation:** each build gets its own git worktree in `/tmp/sky-bench-ab`,
  its own `uv` venv, and its own API server, on ports 46601 and 46602.
- **What it leaves alone:** your checkout and your main API server.
- **Cost:** the first run installs both venvs.
- **Options:** `-- run --help` lists them, including `--baseline-ref`.

## 4. Results

Each run writes to `ej/bench_results/<YYYYmmdd-HHMMSS>-<subcommand>/`. Pass
`--out DIR` to choose another directory. Each directory contains:

- **`report.md`:** the tables, ready to paste into a design doc.
- **`summary.json`:** every number in the report, per run.
- **Raw traces:**
  - `jobs-ab` and `storage-probe` save one trace per run, holding the client
    output and the job status changes, with timestamps.
  - `pod-probe` saves the launch output in `launch.log`.
  - `storage-probe` saves the patched lookups' log in `probe.log`.

Numbers measured on the reference machine:

| Measurement | Base | Candidate |
|---|---|---|
| `jobs-ab`, 6 nodes, client total (mean) | 70.8 s | 54.8 s |
| `jobs-ab`, 6 nodes, phase D (mean) | 32.7 s | 26.3 s |
| `jobs-ab`, 4 nodes, client total (mean) | 61.5 s | 50.1 s |
| `storage-probe`, 2nd lookup | 0.18–0.33 s | 0.001 s |

| Measurement | Result |
|---|---|
| `pod-probe`, wheel resolve | offline 12 ms; online with an empty cache 3–6 s |
| `pod-probe`, `attempt_skylet` import | cold 4.5–4.7 s; warm 1.3–1.5 s |
| `pull-policy`, pods to Running (2–6 nodes) | `Always` 3.4–6.6 s; `IfNotPresent` 1.5–3.1 s |

Expect the per-run spread to be large: 51–58 s for the candidate and 61–78 s
for the base at 6 nodes. Compare medians and the permutation p-value, not
single runs.

## 5. If a run is interrupted

**Ctrl-C** is safe. On exit, `jobs-ab` and `storage-probe`:

- revert `sky/data/storage.py`;
- switch back to the ref you started from;
- restart the API server on it.

**If the process was killed** (for example with `kill -9` or by closing the
terminal), restore by hand:

```bash
git checkout -- sky/data/storage.py   # drop storage-probe's patch, if present
git switch <your branch>
sky api stop && sky api start --deploy
sky jobs queue                        # cancel any leftover benchab/benchprobe job
sky status                            # tear down any leftover bench-* cluster
```

## 6. Notes

- **The server is restarted in consolidation mode.**
  - **Mode:** `--deploy`, so the jobs controller runs inside the API server, as
    in the published numbers.
  - **After a run:** the server stays in that mode. Run
    `sky api stop && sky api start` to switch back.
  - **Request history:** each restart clears the server's request history.
- **`ej/bench_jobs/` is superseded.** It holds the one-off scripts
  `reproduce_benchmarks.py` replaced, with paths and job IDs hard-coded to the
  original runs.
