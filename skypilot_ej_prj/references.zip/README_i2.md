# Benchmarking launch latency on the latest branch

This is how to benchmark `sky launch` and `sky jobs launch` on the latest branch, `ej-prj-i2-6`, against master. It replaces `README.md` for these two benchmarks.

## What changed from `README.md`

| | `README.md` | This procedure |
|---|---|---|
| **Candidate** | `ej-prj-3-job1` | `ej-prj-i2-6` |
| **Base** | `origin/master`, or a pinned commit | The commit the candidate is based on |
| **Images** | One image for both arms | A separate task, and so an image, for each arm |
| **Pull policy** | The template's `Always` | `IfNotPresent` in both arms |
| **Candidate image** | Published image | Bytecode image, built and loaded locally |
| **Sample size** | Defaults; 5 runs for `sky launch` | 8 measured runs per arm for both |

Always pass `--candidate` and `--candidate-ref`, because the script's defaults still point at `ej-prj-3-job1`.

## 1. Prerequisites

- **Tools:** `git`, `kubectl`, [`uv`](https://docs.astral.sh/uv/), Docker and [kind](https://kind.sigs.k8s.io/).
- **CPU:** the reference numbers come from one kind node with 12 cores. For 6 nodes, 8 or more free cores are enough.
- **Time:** about 45 minutes for both benchmarks.
- **An idle setup:** no other managed jobs or launches on the context. They would slow the runs down, and `jobs-ab` fails if another managed job is in progress.
- **Your API server is restarted:** `jobs-ab` stops and restarts your local server for each block. Other clients lose it during the run.

## 2. Set up

If you already work in a checkout with the venv, `ej/` and a kind cluster, skip to [2.4](#24-build-and-load-the-bytecode-image).

### 2.1 Get the code

```bash
git clone https://github.com/skypilot-org/skypilot.git skypilot-bench
cd skypilot-bench
git remote add fork https://github.com/siliconej/skypilot.git
git fetch fork

# The scripts look refs up by local name.
git branch ej-prj-i2-6 fork/ej-prj-i2-6
git branch ej-prj-i2-5 fork/ej-prj-i2-5
```

### 2.2 Create the virtualenv and switch to the branch

The install must be editable, because the script switches the checkout and the server runs whatever is checked out.

```bash
git switch ej-prj-i2-6
uv venv --seed --python 3.11
source .venv/bin/activate
uv pip install -e ".[kubernetes]"
```

### 2.3 Copy in `ej/`, and create the cluster

`ej/` isn't committed on any branch. Copy in the script and both task files, and keep them untracked, so that switching refs leaves them alone:

```bash
mkdir -p ej
cp /path/to/your/skypilot/ej/{reproduce_benchmarks.py,task_bytecode.yaml,task_published_ifnotpresent.yaml} ej/
echo 'ej/' >> .git/info/exclude

# Creates the kind cluster `skypilot` and the context `kind-skypilot`.
sky local up
sky check kubernetes
```

If `~/.sky/config.yaml` sets `kubernetes.allowed_contexts`, it must include `kind-skypilot`.

### 2.4 Build and load the bytecode image

The candidate's task uses `skypilot-k8s-ej-prj-3:bytecode`, which is never published. With `IfNotPresent`, a launch fails with an image pull error if it isn't on the node. Build it from this branch's `Dockerfile_k8s`, which has `--compile-bytecode`:

```bash
docker build -t skypilot-k8s-ej-prj-3:bytecode - < Dockerfile_k8s
kind load docker-image skypilot-k8s-ej-prj-3:bytecode --name skypilot
```

Check that the node has it:

```bash
docker exec skypilot-control-plane crictl images | grep bytecode
```

If `Dockerfile_k8s` changes, build and load the image under a new tag, and update `ej/task_bytecode.yaml` to match. With `IfNotPresent`, reusing a tag can keep the old image.

### 2.5 Warm up both images

The published image is several GB. Do one throwaway launch per task, so that no measured run includes a pull:

```bash
sky api stop; sky api start --deploy
sky launch -y -c bench-warm ej/task_published_ifnotpresent.yaml
sky down -y bench-warm
sky launch -y -c bench-warm ej/task_bytecode.yaml
sky down -y bench-warm
```

**Always use `--deploy`.** Plain `sky api start` turns consolidation mode off, and the next `sky jobs launch` creates a separate controller pod with 4 CPUs and 16 GB, which then invalidates your numbers.

## 3. Run the benchmarks

Run these from the repo root on `ej-prj-i2-6`, with the venv active. The `sky launch` benchmark comes from the checkout you start in, and `--candidate-task` exists only on `ej-prj-i2-5` and later.

### 3.1 Check that you're ready

```bash
git status --short --untracked-files=no          # must print nothing
kubectl --context kind-skypilot get pods -A -l parent=skypilot   # must find no pods
sky jobs queue                                   # no jobs in progress

BASE=$(git merge-base origin/master ej-prj-i2-6)
echo "$BASE"
```

`$BASE` is the commit the branch is based on, so the comparison contains only this branch's changes. `origin/master` itself may be newer. To compare with the current master anyway, rebase the branch first.

### 3.2 `sky launch`

About 15–20 minutes, plus the first install of both venvs.

```bash
python ej/reproduce_benchmarks.py sky-launch-ab --nodes 6 -- \
    run --baseline-ref "$BASE" --candidate-ref ej-prj-i2-6 \
    --task ej/task_published_ifnotpresent.yaml \
    --candidate-task ej/task_bytecode.yaml \
    --runs 8 --warmup 1
```

- **How it runs:** each build gets its own worktree in `/tmp/sky-bench-ab`, its own venv, and its own API server on ports 46601 and 46602. Launches alternate between the builds.
- **What it leaves alone:** your checkout and your main API server.

### 3.3 `sky jobs launch`

About 20–25 minutes.

```bash
python ej/reproduce_benchmarks.py jobs-ab --nodes 6 \
    --base "$BASE" --candidate ej-prj-i2-6 \
    --base-task ej/task_published_ifnotpresent.yaml \
    --candidate-task ej/task_bytecode.yaml \
    --blocks 4 --runs 4 --warmup 1
```

- **How it runs:** 4 alternating blocks, base first. Each block switches the checkout, restarts the server with `--deploy`, and checks that the server reports the expected commit. It then does 1 warm-up run, which is dropped, and 4 measured runs. That's 20 launches and 8 measured runs per arm.
- **Between runs:** it waits until the job's pods are gone.
- **Excluded from the statistics:** a run that failed, or whose trace saw another job (`CONTAMINATED`).
- **Afterwards:** it switches back to your ref and restarts the server on it. **Don't edit tracked files or launch anything during the run.**

### 3.4 Other comparisons

To measure only the newest changes, use the same image in both arms:

```bash
python ej/reproduce_benchmarks.py jobs-ab --nodes 6 \
    --base ej-prj-i2-5 --candidate ej-prj-i2-6 \
    --base-task ej/task_bytecode.yaml \
    --candidate-task ej/task_bytecode.yaml \
    --blocks 4 --runs 4 --warmup 1
```

To reproduce the most recent results, use `--base 796c5bcc8` with `ej-prj-i2-5` as the candidate in both 3.2 and 3.3.

## 4. Read the results

Results go to `ej/bench_results/<timestamp>-<subcommand>/`. If you pass `--out`, give it a new subdirectory, because the files are written straight into it.

| Benchmark | Main report | Also there |
|---|---|---|
| `sky launch` | `summary.md` | `results.csv`, `meta.json`, `logs/` |
| `sky jobs launch` | `report.md` | `summary.json`, one trace per run |

**Check first:**
- **`sky launch`:** every box in the Checks list is ticked, and the commits in the provision logs are the ones you meant.
- **`sky launch` verdict:** "VALID" tests only the time from runtime setup to cluster launched. The heading says "baseline vs. ej-prj-1" for any candidate. Read the whole table.
- **`sky jobs launch`:** the Runs table shows `Clean` True and `rc` 0, and each arm has 8 measured runs.

**The phases of `sky jobs launch`:**

| Phase | From → to |
|---|---|
| A | Client start → job row created |
| B | Row created → STARTING |
| C | STARTING → provisioning starts |
| D | Provisioning → job submitted |
| E | Job runs on the cluster |
| F | Job ended → RUNNING |
| G | RUNNING → SUCCEEDED |
| H | SUCCEEDED → client exits |

**Reference results** (6 nodes, 8 measured runs per arm, medians). These are for `ej-prj-i2-5`. The only A/B of `ej-prj-i2-6` is against `ej-prj-i2-5`.

| Comparison | Measure | Base | Candidate | p |
|---|---|---|---|---|
| master `796c5bcc8` vs `ej-prj-i2-5` | `sky launch` wall time | 44.13 s | 29.67 s | 0.0002 |
| | `sky jobs launch` client total | 79.1 s | 45.0 s | < 0.001 |
| `ej-prj-i2-5` vs `ej-prj-i2-6` | SUCCEEDED → client exits | 4.3 s | 2.6 s | 0.0002 |
| | `sky jobs launch` client total | 41.3 s | 40.0 s | 0.19 |

**How to compare:**
- **Compare the two arms within one run,** not numbers from different runs. Absolute times move between sessions.
- **Phases A and C switch between two levels** in both arms, for a reason not yet found: A is about 3 s or about 7 s, and C about 1 s or about 3 s. Together that's about 6 s of client total.
- **Runtime setup stalls remain.** It's sometimes about 10 s longer on either arm, and one master run took 107.9 s. Read the ranges next to the medians, and compare medians and p-values rather than single runs.
- **These aren't the numbers users get today.** The bytecode image isn't published, and the template still sets `Always`.

## 5. If a run is interrupted

**Ctrl-C is safe** for `jobs-ab`: it switches back to your ref and restarts the server.

**If the process was killed,** restore by hand:

```bash
git switch <your branch>
sky api stop; sky api start --deploy
sky jobs queue     # cancel any leftover benchab job
sky status         # tear down any leftover bench-* or benchab-* cluster
```

**After an interrupted `sky launch` run,** check these. Each should show nothing except your own checkout:

```bash
kubectl --context kind-skypilot get pods -A -l parent=skypilot
ss -ltn | grep -E ':4660[12]'
git worktree list
```

**If you see `sky-jobs-controller-*` in `sky status`,** the server was started without `--deploy`. Check that no jobs are in progress, take it down with `sky down`, and restart with `sky api start --deploy`.

## 6. Other subcommands

`reproduce_benchmarks.py` also has `storage-probe`, `pod-probe` and `pull-policy`, described in `README.md`. They haven't been rerun on the `ej-prj-i2-*` branches. If you use them:

- Pass `--base` and `--candidate` to `storage-probe`.
- `pod-probe` tests whichever code your server is running, so restart the server on the branch first.
- `README.md`'s expected numbers predate these branches. For example, the first storage lookup isn't always 4.8 s.

## 7. Notes

- **After a run, the server stays in `--deploy` mode.** Run `sky api stop; sky api start` to change that.
- **Each restart clears the server's request history.**
- **`bench_launch_latency.py` needs an `origin/master` ref** in the repo, and `uv` on `PATH`.
- **Design docs:** `launch_latency_design_after_job2.md` covers what's in the latest branch. `pr_descriptions_i2.md` has the full tables against master.
