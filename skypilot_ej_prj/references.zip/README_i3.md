# Benchmarking launch latency on the latest branch

This is how to benchmark `sky launch` and `sky jobs launch` on the latest branch, `ej-prj-i3-2`, against master. It replaces `README_i2.md`.

## What changed from `README_i2.md`

| | `README_i2.md` | This procedure |
|---|---|---|
| **Candidate** | `ej-prj-i2-6` | `ej-prj-i3-2` |
| **`ej/` files** | All copied in by hand | Task files come with the branch; only `reproduce_benchmarks.py` is copied |
| **Virtualenv** | `.[kubernetes]` | `.[kubernetes,aws]`, so `aws` is on `PATH` like the reference runs |
| **Phases A and C** | "Two levels, reason not found" | Explained: `aws` on the server's `PATH`, and now the 10-minute expiry |
| **Config variants** | Not covered | With or without the speedup settings (3.5, 3.6) |

Always pass `--candidate` and `--candidate-ref`, because the script's defaults still point at `ej-prj-3-job1`.

## The branches

Both branches add one commit to `ej-prj-i2-6` (`407784c57`), separately. Neither includes the other's commit.

| Branch | Commit | Change |
|---|---|---|
| `ej-prj-i3-2` (latest) | `d771518f1` | Reuse an empty storage check result for an unchanged config |
| `ej-prj-i3-1` | `650eb5a67` | Create a file mount's target in the same call as rsync |

## 1. Prerequisites

- **Tools:** `git`, `kubectl`, [`uv`](https://docs.astral.sh/uv/), Docker and [kind](https://kind.sigs.k8s.io/).
- **CPU:** the reference numbers come from one kind node with 12 cores. For 6 nodes, 8 or more free cores are enough.
- **Time:** about 40 minutes for both benchmarks: about 15 for `sky launch` and 25 for `sky jobs launch`, plus the first install of the benchmark's venvs.
- **An idle setup:** no other managed jobs or launches on the context. They would slow the runs down, and `jobs-ab` fails if another managed job is in progress.
- **Your API server is restarted:** `jobs-ab` stops and restarts your local server for each block. Other clients lose it during the run.

## 2. Set up

If you already work in a checkout with the venv, `ej/reproduce_benchmarks.py` and a kind cluster, skip to [2.4](#24-build-and-load-the-bytecode-image).

### 2.1 Get the code

```bash
git clone https://github.com/skypilot-org/skypilot.git skypilot-bench
cd skypilot-bench
git remote add fork https://github.com/siliconej/skypilot.git
git fetch fork

# The scripts look refs up by local name.
git branch ej-prj-i3-2 fork/ej-prj-i3-2
git branch ej-prj-i3-1 fork/ej-prj-i3-1
git branch ej-prj-i2-6 fork/ej-prj-i2-6
```

### 2.2 Create the virtualenv and switch to the branch

The install must be editable, because the script switches the checkout and the server runs whatever is checked out.

```bash
git switch ej-prj-i3-2
uv venv --seed --python 3.11
source .venv/bin/activate
uv pip install -e ".[kubernetes,aws]"
```

The `aws` extra provides the `aws` CLI, which the reference runs had on `PATH`. Without it, phases A and C are faster on master and on any run that does the check, and the gap to the branch shrinks (see section 4).

### 2.3 Copy in the script, and create the cluster

This branch tracks `ej/task_bytecode.yaml`, `ej/task_published_ifnotpresent.yaml`, `ej/job.yaml`, `ej/job2.yaml` and an old copy of `ej/bench_launch_latency.py`. The benchmark itself runs `tests/kubernetes/launching_benchmarks/bench_launch_latency.py`.

`ej/reproduce_benchmarks.py` isn't committed on any branch. Copy it in and keep it untracked, so that switching refs leaves it alone:

```bash
cp /path/to/your/skypilot/ej/reproduce_benchmarks.py ej/
echo 'ej/' >> .git/info/exclude

# Creates the kind cluster `skypilot` and the context `kind-skypilot`.
sky local up
sky check kubernetes
```

If `~/.sky/config.yaml` sets `kubernetes.allowed_contexts`, it must include `kind-skypilot`.

**Tracked `ej/` files come and go.** Master doesn't have them, so they disappear from your checkout while `jobs-ab` is on the base, then come back. `jobs-ab` copies the task files to its results folder first, so this doesn't affect the run.

### 2.4 Build and load the bytecode image

The candidate's task uses `skypilot-k8s-ej-prj-3:bytecode`, which is never published. With `IfNotPresent`, a launch fails with an image pull error if it isn't on the node. Build it from this branch's `Dockerfile_k8s`, which has `--compile-bytecode`:

```bash
docker build -t skypilot-k8s-ej-prj-3:bytecode - < Dockerfile_k8s
kind load docker-image skypilot-k8s-ej-prj-3:bytecode --name skypilot
```

Check that the node has it:

```bash
docker exec skypilot-control-plane crictl images | grep bytecode
```

If `Dockerfile_k8s` changes, build and load the image under a new tag, and update `ej/task_bytecode.yaml` to match. With `IfNotPresent`, reusing a tag can keep the old image.

### 2.5 Warm up both images

The published image is several GB. Do one throwaway launch per task, so that no measured run includes a pull:

```bash
sky api stop; sky api start --deploy
sky launch -y -c bench-warm ej/task_published_ifnotpresent.yaml
sky down -y bench-warm
sky launch -y -c bench-warm ej/task_bytecode.yaml
sky down -y bench-warm
```

**Always use `--deploy`.** Plain `sky api start` turns consolidation mode off, and the next `sky jobs launch` creates a separate controller pod with 4 CPUs and 16 GB, which then invalidates your numbers.

## 3. Run the benchmarks

Run these from the repo root on `ej-prj-i3-2`, with the venv active. The `sky launch` benchmark comes from the checkout you start in, and `--candidate-task` exists only on `ej-prj-i2-5` and later.

### 3.1 Check that you're ready

```bash
git status --short --untracked-files=no          # must print nothing
kubectl --context kind-skypilot get pods -A -l parent=skypilot   # must find no pods
sky jobs queue                                   # no jobs in progress
which aws                                        # must find the CLI

BASE=$(git merge-base origin/master ej-prj-i3-2)
echo "$BASE"
```

`$BASE` is the commit the branch is based on, so the comparison contains only this branch's changes. `origin/master` itself may be newer. To compare with the current master anyway, rebase the branch first.

### 3.2 `sky launch`

```bash
python ej/reproduce_benchmarks.py sky-launch-ab --nodes 6 -- \
    run --baseline-ref "$BASE" --candidate-ref ej-prj-i3-2 \
    --task ej/task_published_ifnotpresent.yaml \
    --candidate-task ej/task_bytecode.yaml \
    --runs 8 --warmup 1
```

- **How it runs:** each build gets its own worktree in `/tmp/sky-bench-ab`, its own venv, and its own API server on ports 46601 and 46602. Launches alternate between the builds.
- **What it leaves alone:** your checkout and your main API server.
- **Its config is its own:** these servers ignore `~/.sky/config.yaml`, and always set `allowed_clouds: [kubernetes]`. To remove or add settings, see 3.5 and 3.6.
- **Its venvs have no AWS libraries:** the `aws` CLI comes from your `PATH`, but cloud checks stop earlier than on your main server.

### 3.3 `sky jobs launch`

```bash
python ej/reproduce_benchmarks.py jobs-ab --nodes 6 \
    --base "$BASE" --candidate ej-prj-i3-2 \
    --base-task ej/task_published_ifnotpresent.yaml \
    --candidate-task ej/task_bytecode.yaml \
    --blocks 4 --runs 4 --warmup 1
```

- **How it runs:** 4 alternating blocks, base first. Each block switches the checkout, restarts the server with `--deploy`, and checks that the server reports the expected commit. It then does 1 warm-up run, which is dropped, and 4 measured runs. That's 20 launches and 8 measured runs per arm.
- **Its config is yours:** it uses `~/.sky/config.yaml`, or the file in `SKYPILOT_GLOBAL_CONFIG`.
- **Between runs:** it waits until the job's pods are gone.
- **Excluded from the statistics:** a run that failed, or whose trace saw another job (`CONTAMINATED`).
- **Afterwards:** it switches back to your ref and restarts the server on it. **Don't edit tracked files or launch anything during the run.**

### 3.4 Other comparisons

To measure only the newest change, use the same image in both arms:

```bash
python ej/reproduce_benchmarks.py jobs-ab --nodes 6 \
    --base ej-prj-i2-6 --candidate ej-prj-i3-2 \
    --base-task ej/task_bytecode.yaml \
    --candidate-task ej/task_bytecode.yaml \
    --blocks 4 --runs 4 --warmup 1
```

To test `ej-prj-i3-1`, use it in place of `ej-prj-i3-2`, in the merge-base too.

**Don't expect `sky launch` to show the storage check reuse.** It reaches that check only for tasks with storage mounts (`sky/task.py:1690`), and these tasks have none.

**`jobs-ab` won't run with uncommitted changes.** To test a patch before committing it, compare with and without it on one commit, as `bench_results/20261103-empty-storage-check-ab/run.py` does.

### 3.5 `sky launch` with no speedup settings

To remove `allowed_clouds` from the isolated servers, run the benchmark through a wrapper that rewrites their config before they start. `sky_launch_no_tips.py` does this, keeping only `kubernetes.allowed_contexts`, which pins the context:

```bash
export PATH="$PWD/.venv/bin:$PATH"
OUT=$PWD/ej/bench_results/$(date +%Y%m%d-%H%M%S)-no-tips
mkdir -p "$OUT"

python ej/bench_results/20261103-i3-2-vs-master-no-tips/sky_launch_no_tips.py \
    run --baseline-ref "$BASE" --candidate-ref ej-prj-i3-2 \
    --task "$PWD/ej/task_published_ifnotpresent.yaml" \
    --candidate-task "$PWD/ej/task_bytecode.yaml" \
    --runs 8 --warmup 1 --context kind-skypilot --out "$OUT/sky-launch"
```

This wrapper is untracked, so it exists only in the original checkout. Its `REPO` path is written in, so change that if you copy it elsewhere.

### 3.6 With the speedup settings

To apply `allowed_clouds` and `aws.remote_identity: NO_UPLOAD` from `local_run_speedup_tips.md` to both arms without editing your config:

```bash
# sky jobs launch: pass the settings with an environment variable.
SKYPILOT_GLOBAL_CONFIG=$PWD/ej/bench_results/20261103-i3-1-vs-master-tips/config_tips.yaml \
    python ej/reproduce_benchmarks.py jobs-ab --nodes 6 \
    --base "$BASE" --candidate ej-prj-i3-2 \
    --base-task ej/task_published_ifnotpresent.yaml \
    --candidate-task ej/task_bytecode.yaml \
    --blocks 4 --runs 4 --warmup 1

# Then put your server back on your own config.
sky api stop; sky api start --deploy
```

**The second step matters:** `jobs-ab` restores your server with the variable still set, so it would otherwise keep the speedup settings.

For `sky launch`, `ej/bench_results/20261103-i3-1-vs-master-tips/sky_launch_with_tips.py` adds `NO_UPLOAD` the same way as 3.5. The same untracked and `REPO` notes apply.

## 4. Read the results

Results go to `ej/bench_results/<timestamp>-<subcommand>/`. If you pass `--out`, give it a new subdirectory, because the files are written straight into it.

| Benchmark | Main report | Also there |
|---|---|---|
| `sky launch` | `summary.md` | `results.csv`, `meta.json`, `logs/` |
| `sky jobs launch` | `report.md` | `summary.json`, one trace per run |

**Check first:**
- **`sky launch`:** every box in the Checks list is ticked, and the commits in the provision logs are the ones you meant.
- **`sky launch` verdict:** "VALID" tests only the time from runtime setup to cluster launched. The heading says "baseline vs. ej-prj-1" for any candidate. Wall time isn't in `summary.md`; it's the `launch_wall_s` column in `results.csv`.
- **`sky jobs launch`:** the Runs table shows `Clean` True and `rc` 0, and each arm has 8 measured runs.
- **`sky jobs launch` p-value:** the report rounds it, and shows 0.0000 when every run of one arm beats the other. With 8 runs per arm, the exact two-sided value is then 0.0002.

**The phases of `sky jobs launch`:**

| Phase | From → to |
|---|---|
| A | Client start → job row created |
| B | Row created → STARTING |
| C | STARTING → provisioning starts |
| D | Provisioning → job submitted |
| E | Job runs on the cluster |
| F | Job ended → RUNNING |
| G | RUNNING → SUCCEEDED |
| H | SUCCEEDED → client exits |

**Reference results** (6 nodes, 8 measured runs per arm, medians):

| Comparison | Measure | Base | Candidate | p |
|---|---|---|---|---|
| master `796c5bcc8` vs `ej-prj-i3-2`, no speedup settings | `sky launch` wall time | 46.70 s | 27.57 s | 0.0002 |
| | `sky jobs launch` client total | 74.3 s | 34.2 s | 0.0002 |
| | Phase A | 7.0 s | 2.1 s | 0.0002 |
| master `796c5bcc8` vs `ej-prj-i3-1`, both speedup settings | `sky launch` wall time | 46.23 s | 27.37 s | 0.0002 |
| | `sky jobs launch` client total | 67.5 s | 34.7 s | 0.0002 |
| `ej-prj-i2-6` vs its patch, `d771518f1` | `sky jobs launch` client total | 41.31 s | 37.06 s | 0.013 |
| | Phase A | 6.85 s | 2.20 s | 0.0047 |
| `ej-prj-i2-6` vs `ej-prj-i3-1` | File mounts stage in `sky launch` | 1.45 s | 1.08 s | 0.32 on means, 0.046 on ranks |

The `ej-prj-i3-1` file mounts result came with no change in total or wall time. Results are in `20261103-i3-2-vs-master-no-tips/`, `20261103-i3-1-vs-master-tips/`, `20261103-empty-storage-check-ab/` and `20261103-i3-1-mkdir-ab/`.

**How to compare:**
- **Compare the two arms within one run,** not numbers from different runs. Absolute times move between sessions.
- **Phases A and C depend on `aws` being on the API server's `PATH`.** In a controlled test on the same code, A was 3.49 vs 7.03 s and C 0.98 vs 3.42 s, without and with it.
- **On `ej-prj-i3-2`, phase A has two levels:** about 2 s when the storage check is reused, and about 7 s when it reruns. An empty result is reused for 10 minutes on an unchanged config. Launches here are about 40 s apart, the best case; launches over 10 minutes apart get no saving. A branch run with phase A around 7 s is probably an expiry, which you can confirm against the timestamp in `~/.sky/state.db`.
- **Phase C stays about 3 s without `NO_UPLOAD`.** Its `aws` call is a separate path from the storage check.
- **Runtime setup stalls remain.** It's sometimes about 10 s longer on either arm. Read the ranges next to the medians, and compare medians and p-values rather than single runs.
- **File mounts were slower on the branch than on master** in both master comparisons, for a reason not yet found: 1.05 vs 2.33 s and 1.76 vs 2.26 s.
- **Master comparisons measure the image too.** Master uses the published image and the branch uses the bytecode image.
- **These aren't the numbers users get today.** The bytecode image isn't published, and the template still sets `Always`.

## 5. If a run is interrupted

**Ctrl-C is safe** for `jobs-ab`: it switches back to your ref and restarts the server.

**If the process was killed,** restore by hand:

```bash
git switch <your branch>
sky api stop; sky api start --deploy
sky jobs queue     # cancel any leftover benchab job
sky status         # tear down any leftover bench-* or benchab-* cluster
```

If you used `SKYPILOT_GLOBAL_CONFIG`, unset it first, or start the server in a shell without it.

**After an interrupted `sky launch` run,** check these. Each should show nothing except your own checkout:

```bash
kubectl --context kind-skypilot get pods -A -l parent=skypilot
ss -ltn | grep -E ':4660[12]'
git worktree list
```

**If you see `sky-jobs-controller-*` in `sky status`,** the server was started without `--deploy`. Check that no jobs are in progress, take it down with `sky down`, and restart with `sky api start --deploy`.

## 6. Other subcommands

`reproduce_benchmarks.py` also has `storage-probe`, `pod-probe` and `pull-policy`, described in `README.md`. They haven't been rerun on the `ej-prj-i2-*` or `ej-prj-i3-*` branches. If you use them:

- Pass `--base` and `--candidate` to `storage-probe`.
- `pod-probe` tests whichever code your server is running, so restart the server on the branch first.
- `README.md`'s expected numbers predate these branches. For example, the first storage lookup isn't always 4.8 s.

## 7. Notes

- **After a run, the server stays in `--deploy` mode.** Run `sky api stop; sky api start` to change that.
- **Each restart clears the server's request history.**
- **`bench_launch_latency.py` needs an `origin/master` ref** in the repo, and `uv` on `PATH`.
- **Design docs:** `launch_latency_design_after_job2.md` covers the `ej-prj-i2-*` line, and `empty_storage_check_reuse_design.md` covers `ej-prj-i3-2`. `ej-prj-i3-1` has no design doc yet. `pr_descriptions_i2.md` has the full tables against master.
- **Workflow diagram:** `sky_jobs_launch_workflow_i3_2.svg` shows every phase's breakdown on `ej-prj-i3-2`.
- **Speedup settings:** `local_run_speedup_tips.md`.
