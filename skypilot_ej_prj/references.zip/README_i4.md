# Benchmarking launch latency on the latest branch

This is how to benchmark `sky launch` and `sky jobs launch` on the latest branch, `ej-prj-i4-5`, against master. It replaces `README_i3.md`.

## TL;DR

```bash
git switch ej-prj-i4-5 && source .venv/bin/activate
export PATH="$PWD/.venv/bin:$PATH"
BASE=$(git merge-base origin/master ej-prj-i4-5)      # 796c5bcc8
OUT=$PWD/ej/bench_results/$(date +%Y%m%d-%H%M%S)-i4-5-vs-master; mkdir -p "$OUT"

# sky launch, about 15 minutes
python ej/bench_results/20261105-i4-5b-vs-master/sky_launch_no_tips.py \
    run --baseline-ref "$BASE" --candidate-ref ej-prj-i4-5 \
    --task "$PWD/ej/task_published_ifnotpresent.yaml" \
    --candidate-task "$PWD/ej/task_bytecode.yaml" \
    --runs 8 --warmup 1 --context kind-skypilot --out "$OUT/sky-launch"

# sky jobs launch, about 25 minutes
python ej/reproduce_benchmarks.py jobs-ab --nodes 6 \
    --base "$BASE" --candidate ej-prj-i4-5 \
    --base-task "$PWD/ej/task_published_ifnotpresent.yaml" \
    --candidate-task "$PWD/ej/task_bytecode.yaml" \
    --blocks 4 --runs 4 --warmup 1 --out "$OUT/jobs"
```

`ej/bench_results/20261105-i4-5b-vs-master/run.sh` runs both, exactly as for the reference results. Before running, do the setup in section 2 and the checks in 3.1.

## What changed from `README_i3.md`

| | `README_i3.md` | This procedure |
|---|---|---|
| **Candidate** | `ej-prj-i3-2` | `ej-prj-i4-5` (`fa974f21e`) |
| **Main `sky launch` command** | `reproduce_benchmarks.py sky-launch-ab` | `sky_launch_no_tips.py`, with no speedup settings, as the reference runs used |
| **Bytecode image** | Needed only for its bytecode | Also needs its uv cache, for the offline wheel install |
| **Runtime setup stalls** | On either arm | Master only: the branch installs the wheel offline |
| **File mounts slower on the branch** | An open question | Gone: no difference from master |
| **Measuring an uncommitted change** | Mentioned | Described in 3.4 |
| **Tracing Ray's startup** | Not covered | Section 5 |

Always pass `--candidate` and `--candidate-ref`, because the scripts' defaults still point at `ej-prj-3-job1`.

## The branches

Every `ej-prj-i4-*` branch builds on `ej-prj-i3-2` (`d771518f1`). `ej-prj-i4-5` has every change:

| Branch | Adds | Change |
|---|---|---|
| `ej-prj-i4-1` | `925abd467` | Poll for the head node every 0.2 s |
| `ej-prj-i4-2` | `afd94a698` | Start skylet without importing `sky` (split from `ej-prj-i4-1`) |
| `ej-prj-i4-3` | `8bfc6e4c6` | Install the SkyPilot wheel without the network |
| `ej-prj-i4-4` | `d6fa30e94` | `ej-prj-i4-3` plus the lean skylet launcher |
| `ej-prj-i4-5` (latest) | `1266cccd2`, `fa974f21e` | No Ray dashboard; 0.2 s Ray local connect retry |

Details and PR text: `pr_description_i4.md`.

## 1. Prerequisites

- **Tools:** `git`, `kubectl`, [`uv`](https://docs.astral.sh/uv/), Docker and [kind](https://kind.sigs.k8s.io/).
- **CPU:** the reference numbers come from one kind node with 12 cores. For 6 nodes, 8 or more free cores are enough.
- **Time:** about 40 minutes for both benchmarks, plus the first install of the `sky launch` benchmark's venvs.
- **An idle setup:** no other managed jobs, clusters or launches on the context. A 6-node cluster left running takes the CPU the next launch needs, and that launch fails with "Insufficient cpu". `jobs-ab` also fails if another managed job is in progress.
- **Your API server is restarted:** `jobs-ab` stops and restarts your local server for each block. Other clients lose it during the run.

## 2. Set up

If you already work in a checkout with the venv, `ej/reproduce_benchmarks.py`, a kind cluster and the bytecode image, skip to [3](#3-run-the-benchmarks).

### 2.1 Get the code

```bash
git clone https://github.com/skypilot-org/skypilot.git skypilot-bench
cd skypilot-bench
git remote add fork https://github.com/siliconej/skypilot.git
git fetch fork

# The scripts look refs up by local name.
for b in ej-prj-i4-5 ej-prj-i4-4 ej-prj-i4-3 ej-prj-i4-1 ej-prj-i3-2; do
    git branch $b fork/$b
done
```

### 2.2 Create the virtualenv and switch to the branch

The install must be editable, because `jobs-ab` switches the checkout and the server runs whatever is checked out.

```bash
git switch ej-prj-i4-5
uv venv --seed --python 3.11
source .venv/bin/activate
uv pip install -e ".[kubernetes,aws]"
```

The `aws` extra provides the `aws` CLI, which the reference runs had on `PATH`. Without it, phases A and C are faster on master and on any run that does the check, and the gap to the branch shrinks (see section 4).

### 2.3 Copy in the scripts, and create the cluster

The branch tracks `ej/task_bytecode.yaml`, `ej/task_published_ifnotpresent.yaml`, `ej/job.yaml`, `ej/job2.yaml` and an old copy of `ej/bench_launch_latency.py`. The scripts below aren't committed on any branch. Copy them in and keep them untracked, so that switching refs leaves them alone:

```bash
SRC=/path/to/your/skypilot/ej
cp $SRC/reproduce_benchmarks.py ej/
mkdir -p ej/bench_results/20261105-i4-5b-vs-master
cp $SRC/bench_results/20261105-i4-5b-vs-master/{run.sh,sky_launch_no_tips.py} \
   ej/bench_results/20261105-i4-5b-vs-master/
echo 'ej/' >> .git/info/exclude

# Creates the kind cluster `skypilot` and the context `kind-skypilot`.
sky local up
sky check kubernetes
```

**`run.sh` and `sky_launch_no_tips.py` have the original checkout's path written in** (`REPO=` and `OUT=` in `run.sh`, `REPO` in the wrapper). Change both if you copy them elsewhere.

If `~/.sky/config.yaml` sets `kubernetes.allowed_contexts`, it must include `kind-skypilot`.

**Tracked `ej/` files come and go.** Master doesn't have them, so they disappear from your checkout while `jobs-ab` is on the base, then come back. `jobs-ab` copies the task files to its results folder first, so this doesn't affect the run.

### 2.4 Build and load the bytecode image

The branch's task uses `skypilot-k8s-ej-prj-3:bytecode`, which is never published. With `IfNotPresent`, a launch fails with an image pull error if it isn't on the node. Build it from the branch's `Dockerfile_k8s`, which has `--compile-bytecode`:

```bash
docker build -t skypilot-k8s-ej-prj-3:bytecode - < Dockerfile_k8s
kind load docker-image skypilot-k8s-ej-prj-3:bytecode --name skypilot
```

Check that the node has it, and that the image has a uv cache:

```bash
docker exec skypilot-control-plane crictl images | grep bytecode
docker run --rm --entrypoint bash skypilot-k8s-ej-prj-3:bytecode \
    -c 'ls ~/.cache/uv/archive-v0 | wc -l'    # should be well above 0; the reference image has 133
```

**The uv cache matters.** With it, the pod skips the PyPI dry run and installs the wheel offline. Without it, the pod falls back to the network install, as master does, and runtime setup stalls can come back.

If `Dockerfile_k8s` changes, build and load the image under a new tag, and update `ej/task_bytecode.yaml` to match. With `IfNotPresent`, reusing a tag can keep the old image.

### 2.5 Warm up both images

The published image is several GB. Do one throwaway launch per task, so that no measured run includes a pull:

```bash
sky api stop; sky api start --deploy
sky launch -y -c bench-warm ej/task_published_ifnotpresent.yaml
sky down -y bench-warm
sky launch -y -c bench-warm ej/task_bytecode.yaml
sky down -y bench-warm
```

**Always use `--deploy`.** Plain `sky api start` turns consolidation mode off, and the next `sky jobs launch` creates a separate controller pod with 4 CPUs and 16 GB, which then invalidates your numbers.

## 3. Run the benchmarks

Run these from the repo root on `ej-prj-i4-5`, with the venv active and on `PATH`.

### 3.1 Check that you're ready

```bash
git status --short --untracked-files=no          # must print nothing
kubectl --context kind-skypilot get pods -A -l parent=skypilot   # must find no pods
sky status                                       # no clusters left up
sky jobs queue                                   # no jobs in progress
which aws                                        # must find the CLI

BASE=$(git merge-base origin/master ej-prj-i4-5)
echo "$BASE"                                     # 796c5bcc8 for the reference runs
```

`$BASE` is the commit the branch is based on, so the comparison contains only the branch's changes. `origin/master` itself is newer (`25aae4c18` at last check). To compare with the current master, rebase the branch first.

### 3.2 `sky launch`

```bash
OUT=$PWD/ej/bench_results/$(date +%Y%m%d-%H%M%S)-i4-5-vs-master; mkdir -p "$OUT"

python ej/bench_results/20261105-i4-5b-vs-master/sky_launch_no_tips.py \
    run --baseline-ref "$BASE" --candidate-ref ej-prj-i4-5 \
    --task "$PWD/ej/task_published_ifnotpresent.yaml" \
    --candidate-task "$PWD/ej/task_bytecode.yaml" \
    --runs 8 --warmup 1 --context kind-skypilot --out "$OUT/sky-launch"
```

- **How it runs:** each build gets its own worktree in `/tmp/sky-bench-ab`, its own venv, and its own API server on ports 46601 and 46602. Launches alternate between the builds, after 1 warm-up each.
- **What it leaves alone:** your checkout and your main API server.
- **Its config is its own:** the wrapper gives both servers only `kubernetes.allowed_contexts: [kind-skypilot]`, with no speedup settings. Plain `reproduce_benchmarks.py sky-launch-ab` instead sets `allowed_clouds: [kubernetes]`, which makes both arms faster and isn't how the reference ran.
- **Its venvs have no AWS libraries:** the `aws` CLI comes from your `PATH`, but cloud checks stop earlier than on your main server.
- **It needs committed code:** each worktree checks out a ref, so uncommitted changes aren't tested.

### 3.3 `sky jobs launch`

```bash
python ej/reproduce_benchmarks.py jobs-ab --nodes 6 \
    --base "$BASE" --candidate ej-prj-i4-5 \
    --base-task "$PWD/ej/task_published_ifnotpresent.yaml" \
    --candidate-task "$PWD/ej/task_bytecode.yaml" \
    --blocks 4 --runs 4 --warmup 1 --out "$OUT/jobs"
```

- **How it runs:** 4 alternating blocks, base first. Each block switches the checkout, restarts the server with `--deploy`, and checks that the server reports the expected commit. It then does 1 warm-up run, which is dropped, and 4 measured runs. That's 20 launches and 8 measured runs per arm.
- **Its config is yours:** it uses `~/.sky/config.yaml`, or the file in `SKYPILOT_GLOBAL_CONFIG`.
- **Between runs:** it waits until the job's pods are gone.
- **Excluded from the statistics:** a run that failed, or whose trace saw another job (`CONTAMINATED`).
- **Afterwards:** it switches back to your ref and restarts the server on it. **Don't edit tracked files or launch anything during the run.**
- **It needs a clean tree:** it refuses to start with uncommitted changes to tracked files.

### 3.4 Measuring one change

Against master, the effect of one recent change is too small to see: the master arm's run-to-run spread is larger than the change. Compare the change against the commit before it instead, with the bytecode image in both arms:

```bash
python ej/reproduce_benchmarks.py jobs-ab --nodes 6 \
    --base 1266cccd2 --candidate fa974f21e \
    --base-task "$PWD/ej/task_bytecode.yaml" \
    --candidate-task "$PWD/ej/task_bytecode.yaml" \
    --blocks 4 --runs 4 --warmup 1
```

For `sky launch`, pass the same two commits to `--baseline-ref` and `--candidate-ref`, with `--task` and `--candidate-task` both `ej/task_bytecode.yaml`.

**To measure an uncommitted change,** both harnesses need a commit, so either commit it first, or switch the change in and out of the working tree between blocks, on one commit. `bench_results/20261105-no-dashboard-ab/run.py` does the second: it copies the changed files in for one arm and runs `git checkout --` for the other, in blocks ABBAABBA, and always restores the change at the end. It has its file list and paths written in, so copy and adapt it.

**More runs help here.** The single-change A/Bs used 16 measured runs per side rather than 8.

## 4. Read the results

| Benchmark | Main report | Also there |
|---|---|---|
| `sky launch` | `sky-launch/summary.md` | `results.csv`, `meta.json`, `logs/` |
| `sky jobs launch` | `jobs/report.md` | `summary.json`, one trace per run |

**Check first:**
- **`sky launch`:** every box in the Checks list is ticked, and the commits in the provision logs are the ones you meant.
- **`sky launch` verdict:** "VALID" tests only the time from runtime setup to cluster launched. The heading says "baseline vs. ej-prj-1" for any candidate. Wall time isn't in `summary.md`; it's the `launch_wall_s` column in `results.csv`.
- **`sky jobs launch`:** the Runs table shows `Clean` True and `rc` 0, and each arm has 8 measured runs.
- **p-values:** `summary.md` is one-sided, and `report.md` shows 0.0000 when every run of one arm beats the other. With 8 runs per arm, the exact two-sided value is then 0.0002. The reports in `ej/report_*.md` recompute two-sided values; `bench_results/20261105-i4-5b-vs-master/stats_two_sided.txt` shows how.

**The phases of `sky jobs launch`:**

| Phase | From → to |
|---|---|
| A | Client start → job row created |
| B | Row created → STARTING |
| C | STARTING → provisioning starts |
| D | Provisioning → job submitted |
| E | Job runs on the cluster |
| F | Job ended → RUNNING |
| G | RUNNING → SUCCEEDED |
| H | SUCCEEDED → client exits |

Phase D is split into stages in `report.md`: create pods, SSH readiness, `internal_file_mounts`, `setup_runtime_on_cluster`, Ray wait + skylet start, and cluster launched → job submitted. Every `ej-prj-i4-*` change acts inside phase D.

**Reference results** (6 nodes, 8 measured runs per arm unless stated, medians):

| Comparison | Measure | Base | Candidate | p |
|---|---|---|---|---|
| master `796c5bcc8` vs `ej-prj-i4-5` `fa974f21e`, no speedup settings | `sky launch` wall time | 45.67 s | 22.44 s | 0.0002 |
| | `sky jobs launch` client total | 74.95 s | 30.84 s | 0.0002 |
| | Phase D | 33.08 s | 10.43 s | 0.0002 |
| | Ray wait + skylet start | 16.84 s | 1.06 s | 0.0002 |
| | Runtime setup | 7.98 s (2.5–24.3) | 2.00 s (1.8–2.3) | 0.0002 |
| master `796c5bcc8` vs `ej-prj-i4-5` `1266cccd2` (before the retry change) | `sky launch` wall time | 43.96 s | 23.08 s | 0.0002 |
| | `sky jobs launch` client total | 72.24 s | 31.20 s | 0.0002 |
| `ej-prj-i4-4` without vs with no dashboard, 16 runs per side | `sky jobs launch` client total | 34.33 s | 30.76 s | < 0.0001 |
| | `sky launch` wall time | 26.10 s | 22.98 s | < 0.0001 |

Results: `20261105-i4-5b-vs-master/`, `20261105-i4-5-vs-master/` and `20261105-no-dashboard-ab/`. Reports: `report_i4_5b_vs_master.md` and `report_i4_5_vs_master.md`.

**How to compare:**
- **Compare the two arms within one run,** not numbers from different runs. Absolute times move between sessions: the master arm's `sky jobs launch` was 72.24 s in one session and 74.95 s in the next.
- **Phases A and C depend on `aws` being on the API server's `PATH`.** In a controlled test on the same code, A was 3.49 vs 7.03 s and C 0.98 vs 3.42 s, without and with it.
- **On the branch, phase A has two levels:** about 2 s when the storage check is reused, and about 7 s when it reruns. An empty result is reused for 10 minutes on an unchanged config. One branch run of 8 has had a 7.4 s phase A with launches under a minute apart, for a reason not yet found.
- **Phase C stays about 3 s without `aws.remote_identity: NO_UPLOAD`.**
- **Runtime setup stalls now happen on master only.** Master's setup ranged up to 24.3 s, the branch's to 2.4 s. Read master's ranges next to its medians.
- **Master comparisons measure the image too.** Master uses the published image and the branch uses the bytecode image.
- **These aren't the numbers users get today.** The bytecode image isn't published, and the template still sets `imagePullPolicy: Always`.

## 5. Tracing Ray's startup (optional)

The timing diagrams (`sky_ray_time_workflow_i4_5_v4.svg` and earlier) come from launches on a trace image, which records Ray API calls, sleeps and process lifetimes in every Python process. **Never benchmark latency with it: the timers slow every process.**

```bash
# Build the trace image from the bytecode image.
B=ej/bench_results/20261105-ray-timeline-v4/image
docker build -q -t skypilot-k8s-ej-prj-3:raytl $B
kind load docker-image skypilot-k8s-ej-prj-3:raytl --name skypilot

# Restart the server on the code to trace, then collect 6 launches.
sky api stop; sky api start --deploy
OUT=$PWD/ej/bench_results/$(date +%Y%m%d)-ray-timeline-new; mkdir -p $OUT
cp ej/bench_results/20261105-ray-timeline-v4/{task.yaml,analyze.py} $OUT/
```

Then collect and analyze:

```bash
bash ej/bench_results/20261105-ray-timeline-v4/collect.sh $OUT   # about 5 minutes
python $OUT/analyze.py                                           # writes $OUT/timeline.json
```

For each of 6 runs, `collect.sh` launches, copies each pod's `/tmp/ray_trace` and Ray logs out, saves the provision log and tears the cluster down.

To draw the diagram, copy `ej/gen_sky_ray_time_workflow_i4_5_v4.py`, point its `timeline.json` path (line 18) at `$OUT`, and set `RUN_N` (line 19) to the run to show. It stops if a code line it labels no longer matches.

- **Ray's C++ waits aren't traced by the hook.** Read them from Ray's logs instead. For example, the plasma connect retry is the gap between "Starting object store" and "ObjectManager server started" in each pod's `raylet.out`.
- **Tear each cluster down before the next launch.** On one kind node, a leftover 6-node cluster makes the next launch fail for lack of CPU.

## 6. If a run is interrupted

**Ctrl-C is safe** for `jobs-ab`: it switches back to your ref and restarts the server.

**If the process was killed,** restore by hand:

```bash
git switch ej-prj-i4-5
sky api stop; sky api start --deploy
sky jobs queue     # cancel any leftover benchab job
sky status         # tear down any leftover bench-* or benchab-* cluster
```

If you used `SKYPILOT_GLOBAL_CONFIG`, unset it first, or start the server in a shell without it.

**After an interrupted `sky launch` run,** check these. Each should show nothing except your own checkout:

```bash
kubectl --context kind-skypilot get pods -A -l parent=skypilot
ss -ltn | grep -E ':4660[12]'
git worktree list
```

**If you see `sky-jobs-controller-*` in `sky status`,** the server was started without `--deploy`. Check that no jobs are in progress, take it down with `sky down`, and restart with `sky api start --deploy`.

## 7. Notes

- **After a run, the server stays in `--deploy` mode.** Run `sky api stop; sky api start` to change that.
- **Each restart clears the server's request history.**
- **`bench_launch_latency.py` needs an `origin/master` ref** in the repo, and `uv` on `PATH`.
- **With the speedup settings:** `README_i3.md` sections 3.5 and 3.6 still apply, with `ej-prj-i4-5` as the candidate.
- **Other subcommands** (`storage-probe`, `pod-probe`, `pull-policy`) are described in `README.md` and haven't been rerun on these branches.
- **Clusters without the Ray dashboard:** on `ej-prj-i4-5`, Ray's dashboard, metrics export and job and state APIs aren't available on a launched cluster. Port 8266 is closed.
- **Docs:** `pr_description_i4.md` (one section per change), `report_i4_5b_vs_master.md` (the latest full report), `ray_api_trace_report.md` (how Ray starts up), and `sky_ray_time_workflow_i4_5_v4.svg` (the latest timeline).
