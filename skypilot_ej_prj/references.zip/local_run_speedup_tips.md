# Speeding up local SkyPilot runs

Settings that make `sky jobs launch` faster on a local setup, with no code changes. A tip is listed here only once an A/B has confirmed it.

**Test setup for every number below:** `ej-prj-i2-6` on `kind-skypilot`, one kind node with 12 cores, a one-line `echo` on 6 nodes (`ej/task_bytecode.yaml`), consolidation mode (`sky api start --deploy`), and the AWS CLI on the API server's `PATH`. Each A/B has 4 alternating blocks, with 8 measured runs per setup, and all launches succeeded. Your numbers will differ.

## Limit SkyPilot to the clouds you use

**Saves about 5.8 s per `sky jobs launch`:** from 39.77 s to 33.98 s (p = 0.0099).

Add this to `~/.sky/config.yaml`, listing only the clouds you use:

```yaml
allowed_clouds:
  - kubernetes
```

Then restart the API server so it picks up the change:

```bash
sky api stop; sky api start --deploy
```

**Why it helps.** Every launch checks which clouds can store files, and it goes through all allowed clouds, even if your task names only Kubernetes. With no storage cloud enabled, the empty result isn't treated as cached, so the check runs again on every launch. Without `allowed_clouds`, that means running the `aws` and `gcloud` commands each time.

**Results** (median, with range):

| Phase | Your config | With `allowed_clouds` | Change | p |
|---|---|---|---|---|
| **A: client start → job row** | 7.04 s (6.3–7.5) | **2.29 s** (1.8–2.5) | **−4.75 s** | 0.0002 |
| C: STARTING → provisioning | 3.09 s (2.5–3.6) | 3.18 s (2.9–3.4) | +0.09 s | 0.54 |
| **Client total** | 39.77 s (36.9–40.6) | **33.98 s** (32.9–41.6) | **−5.79 s** | 0.0099 |

- **Only phase A changes significantly,** at about 4.75 s. The total's extra 1 s isn't tied to any one phase, and may be noise.
- **Phase C doesn't change.** It makes its own `aws` call, which ignores `allowed_clouds`.
- **Some runs are still slow.** Two of the 8 runs with this setting took 39.7 s and 41.6 s, at least partly from setup stalls in provisioning, which this doesn't fix.

**How much you'll save depends on your setup.** These runs had `aws` on the server's `PATH`, because `.venv/bin` was on it. Without it, phase A was already about 3.5 s in a separate test, so expect a smaller saving.

**What you give up:**
- Clouds not on the list can't be used until you add them back. That includes launching on them and using their storage.
- This wasn't tested with a job that uses cloud storage.

**Check it's working:** `sky status` should show only the clouds you listed under `Enabled Infra`.

**Results:** `bench_results/20261103-allowed-clouds-ab/`.

## Skip the AWS credential upload

**Saves about 2.1 s per `sky jobs launch`:** from 39.15 s to 37.03 s (p = 0.043).

Add this to `~/.sky/config.yaml`, then restart the API server as above:

```yaml
aws:
  remote_identity: NO_UPLOAD
```

**Why it helps.** While preparing a cluster, SkyPilot works out which credential files to upload, going through every cloud whatever your task's `infra` says. For AWS, that runs `aws configure list`, about 2.2 s, even if there's no credentials file to upload. `NO_UPLOAD` excludes AWS from that step, so the command doesn't run there.

**Results** (median, with range):

| Phase | Your config | With `NO_UPLOAD` | Change | p |
|---|---|---|---|---|
| A: client start → job row | 7.01 s (6.4–7.2) | 6.86 s (6.5–7.2) | −0.15 s | 0.92 |
| **C: STARTING → provisioning** | 3.21 s (2.9–3.9) | **0.90 s** (0.2–1.6) | **−2.31 s** | 0.0002 |
| **Client total** | 39.15 s (38.6–39.8) | **37.03 s** (35.8–42.1) | **−2.12 s** | 0.043 |

- **Only phase C changes significantly.**
- **It only helps if `aws` is on the API server's `PATH`.** Otherwise the command fails right away, and there's little to save.

**What you give up:** your AWS credentials are no longer uploaded to any cluster, on any cloud. A job that needs them, for example to read a private S3 bucket, would have to get access another way. If you have no AWS credentials, you lose nothing. This wasn't tested with a job that uses AWS.

**Results:** `bench_results/20261103-no-upload-ab/`.

## Using both

```yaml
allowed_clouds:
  - kubernetes
aws:
  remote_identity: NO_UPLOAD
```

Together, phase A was 1.9–2.3 s and phase C 0.6–1.6 s, and client total was **29.9–34.4 s** (median about 31.7 s), against about 39 s with neither setting. All 5 launches succeeded, including the warm-up.

This is a compatibility check of 4 measured runs in one block, after the A/B, not an A/B of its own, so treat the total as a rough figure. It's in line with the two savings adding up.
