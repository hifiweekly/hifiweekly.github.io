# PR descriptions: `ej-prj-i2-2` to `ej-prj-i2-5`

Continues `pr_descriptions.md`, in the same format. One section per branch on `fork` (https://github.com/siliconej/skypilot). Copy everything under a branch's heading into its PR.

**Stacking.** `ej-prj-i2-2`, `-3` and `-4` build on `ej-prj-3-job1`, on master `5ef55efa4`:

`ej-prj-3-job1` → `ej-prj-i2-2` → `ej-prj-i2-3` → `ej-prj-i2-4`

`ej-prj-i2-5` is that whole stack rebased onto master `796c5bcc8`, plus one benchmark commit. **Use one or the other, not both.** Since the older branches are behind master, I'd open PRs from `ej-prj-i2-5`'s commits and treat the `ej-prj-i2-2`, `-3` and `-4` sections as the text for each piece.

**Not included:** `ej-prj-i2-6`, also on the fork at `d080ff076`, adds two more `[Jobs]` commits on top of `ej-prj-i2-5`.

**Test environment for every number below:**
- **Cluster:** `kind-skypilot`, one kind node with 12 cores.
- **Task:** a one-line `echo` on 6 nodes, `ej/task_bytecode.yaml` or `ej/task_published_ifnotpresent.yaml`.
- **Images:** `imagePullPolicy: IfNotPresent` in both arms, unless stated. The bytecode image is built locally.
- **Managed jobs:** consolidation mode (`sky api start --deploy`).
- **A/Bs:** 8 measured runs per arm, medians.

**Checks run on every branch below, in its own worktree:**
- `yapf --diff` and `isort --check` are clean on the changed Python files.
- Pylint on the changed files under `sky/` rates 10.00/10.
- `mypy $(cat tests/mypy_files.txt)` has no errors beyond master's 2 in `fetch_nebius.py`.

**No smoke tests or backward compatibility tests are recorded for any of these commits.** The boxes are left unchecked, with suggestions.

---

## `ej-prj-i2-2`: [Jobs] Keep job timestamps exact over gRPC

Commit: `a84ddc783`. Stacked on `ej-prj-3-job1`.

### Summary

- **Problem:**
  - `GetJobSubmittedTimestamp` and `GetJobEndedTimestamp` return the time in a protobuf `float`, which can hold a current Unix time only to the nearest 128 s.
  - With `SKYPILOT_ENABLE_GRPC` on, a managed job's start and end times were off by up to about a minute, and a short job's duration was recorded as 0 s.
- **Fix:**
  - Add `optional double timestamp_double` to both responses. A float can't be widened in place without breaking the wire format.
  - Keep setting the float, so older clients still work.
  - When a skylet doesn't set the new field, read the exact value through the existing head command instead of accepting the rounded one.
  - Bump `SKYLET_VERSION` to 44, so existing clusters pick this up.
- **Not a speedup:** gRPC is off by default, so launch times don't change.

Files: `sky/schemas/proto/jobsv1.proto` and the generated files, `sky/skylet/services.py`, `sky/skylet/constants.py`, `sky/jobs/utils.py`, and a new test file.

### Tested

- [x] Code formatting: `yapf --diff` and `isort --check` are clean on the changed files. Pylint on the changed `sky/` files rates 10.00/10. mypy has no errors beyond master's 2 in `fetch_nebius.py`.
- [x] Any manual or new tests for this PR (please specify below)
  - **New unit tests:** `tests/unit_tests/test_sky/jobs/test_job_timestamp.py`, 8 passed; 6 of them fail without this change. They cover:
    - the skylet sets both fields;
    - the client reads the exact value;
    - the client ignores a rounded value from an older skylet;
    - the client falls back when the method is missing.
  - **Manual, on kind:** 4 `sky jobs launch` runs with `SKYPILOT_ENABLE_GRPC=1`. Job durations went from 0.00 s to 6.32–6.82 s, and in the run checked the end time is within about 6 ms of the last task's output.
  - **Only tested with mocks:** a new client with an older skylet.
- [ ] All smoke tests: `/smoke-test` (CI) or `pytest tests/test_smoke.py` (local)
- [ ] Relevant individual tests: `/smoke-test -k test_name` (CI) or `pytest tests/test_smoke.py::test_name` (local)
  - Not run. Suggested, with gRPC on: `test_managed_job.py::test_managed_jobs_basic`.
- [ ] Backward compatibility: `/quicktest-core` (CI) or `pytest tests/smoke_tests/test_backward_compat.py` (local)
  - Not run; recommended, as this changes the skylet's proto and version.

---

## `ej-prj-i2-3`: [Kubernetes] Start Ray and notice running pods sooner

Commits: `cab8b302a`, `0038650ac`, `16738238e`. Stacked on `ej-prj-i2-2`.

### Summary

- **Precompile runtime bytecode in the k8s images** (`cab8b302a`).
  - `uv` doesn't compile bytecode by default, so every pod compiled Ray and its dependencies on first import, before GCS started, which delayed every worker.
  - Add `--compile-bytecode` to the runtime install in `Dockerfile_k8s` and `Dockerfile_k8s_gpu`. The image grows from 1.67 GB to 1.83 GB.
  - This takes effect once the image is rebuilt and published.
- **Don't import Ray Serve in `ray start`** (`0038650ac`).
  - `ray start` imported `ray.serve.scripts` only to register the `ray serve` command, which pulls in pandas and FastAPI on every pod.
  - A patch to Ray's `scripts.py` registers that command lazily, so Serve is imported only when `ray serve` is used.
  - `apply_patches.py` imported each module to find its file, which would have imported Serve to patch the file that avoids it. It now uses `find_spec`, which doesn't run the module.
- **Watch pods between polls** (`16738238e`).
  - `_wait_for_pods_to_run` slept 1 s between polls, so a launch noticed its last pod about 0.5 s late on average.
  - A watch now ends the wait early when every waiting pod is running or a pod is going away. The poll that follows still makes every decision, and any watch failure falls back to sleeping out the interval.

Files: `Dockerfile_k8s`, `Dockerfile_k8s_gpu`, `sky/skylet/ray_patches/`, `sky/provision/kubernetes/instance.py`, and tests.

### Tested

- [x] Code formatting: `yapf --diff` and `isort --check` are clean on the changed files. Pylint on the changed `sky/` files rates 10.00/10. mypy has no errors beyond master's 2 in `fetch_nebius.py`.
- [x] Any manual or new tests for this PR (please specify below)
  - **Unit tests:** `test_ray_patches_payload.py` and the new `tests/unit_tests/kubernetes/test_pod_run_wait.py`, 37 passed. They cover:
    - locating a module without running it, and failing on one it can't locate;
    - the wait ends when the last waiting pod runs, and not while others wait or a pod isn't ready;
    - a pod going away ends the wait for the poll to report;
    - a watch error or a failed watch start falls back to sleeping;
    - only the rest of the interval is slept.
  - **Bytecode A/B** (`sky launch`, pins image vs pins + flag):
    - launch wall time 34.90 → **26.25 s** (p = 0.0002);
    - provisioning total 19.34 → 12.66 s (p = 0.0005).
  - **Lazy Serve + pod watch A/B** (`sky launch`, measured together):
    - head container → GCS first log 5.82 → **3.37 s** (p = 0.0002);
    - head container → last raylet 14.22 → 11.77 s (p = 0.0005);
    - last container started → SkyPilot notices 0.70 → **0.16 s** (p = 0.0061);
    - create pods, wait until Running 6.04 → 5.15 s (p = 0.026).
  - **Manual:** on Ray 2.56.1 in a container, `ray serve` still works: `--help`, `-h`, subcommands, an unknown subcommand's error, and a real `ray serve status`. An image that can't be pulled still fails in 8 s with `ErrImagePull`.
  - **Only tested with unit tests:** deleting a pod during the wait.
  - **Not tested:** the GPU image hasn't been built.
- [ ] All smoke tests: `/smoke-test` (CI) or `pytest tests/test_smoke.py` (local)
- [ ] Relevant individual tests: `/smoke-test -k test_name` (CI) or `pytest tests/test_smoke.py::test_name` (local)
  - Not run. Suggested:
    - `test_basic.py::test_minimal`
    - `test_cluster_job.py::test_multi_hostname`, `test_kubernetes_pod_failure_detection`
    - `test_kubernetes_pod_loss.py::test_launch_fails_fast_when_pod_deleted`
    - a test that runs `ray serve` on a launched cluster
- [ ] Backward compatibility: `/quicktest-core` (CI) or `pytest tests/smoke_tests/test_backward_compat.py` (local)
  - Not run. Only new pods get the patch. There's no API change.

---

## `ej-prj-i2-4`: [Jobs] Get a finished job's end time with its status

Commit: `b848c9c1e`. Stacked on `ej-prj-i2-3`.

**Before opening a PR:** this commit's message says the client "still waits for its own log tail", which is wrong. Use the reworded copy on `ej-prj-i2-5` (`7db718aa0`), or the wording below.

### Summary

- **Problem:** after a managed job ended, the controller ran two commands on the head node (status, then end time), and the log follower ran its own status check. Without gRPC, each is a `kubectl exec` or SSH round trip of a second or more.
- **Fix:**
  - The combined head command now also returns the end time.
  - A launch that saw the job succeed hands its status and end time to the monitor loop, which then needs no head command.
  - The monitor loop's status check also returns the end time, so a finished job doesn't fetch it separately. With gRPC or a runtime, it still does.
  - The follower trusts a tail exit code of SUCCEEDED, and reads the recorded status every 0.2 s instead of every 1 s until the controller writes it.
- **Compatibility:** the generated code only calls functions older cluster runtimes already have.
- **Side effect:** the wait after SUCCEEDED grows, because the controller saves the logs after SUCCEEDED and the client now reaches that wait sooner. The total still improves slightly.

Files: `sky/jobs/controller.py`, `sky/jobs/recovery_strategy.py`, `sky/jobs/utils.py`, `sky/skylet/job_lib.py`, and tests.

### Tested

- [x] Code formatting: `yapf --diff` and `isort --check` are clean on the changed files. Pylint on the changed `sky/` files rates 10.00/10. mypy has no errors beyond master's 2 in `fetch_nebius.py`.
- [x] Any manual or new tests for this PR (please specify below)
  - **New unit tests** (15), covering:
    - a success seen at launch needs no head command, and without a time it's checked;
    - the end time from a status check is reused;
    - the launch's end time is handed over once, and a recovery doesn't inherit it;
    - a tail that says SUCCEEDED needs no status check, and one that says FAILED still checks;
    - the final wait polls quickly;
    - an end time is dropped for a job not yet seen finished;
    - the codegen returns the end time against a real job table.
  - **`tests/unit_tests/test_sky/jobs`:** 1390 passed, 1 failed. The failure, `test_storage_teardown_retries_a_transient_error`, passes when run alone and also fails intermittently on master.
  - **A/B on kind** (`sky jobs launch`, bytecode image, against `ej-prj-i2-3`):

    | Phase | Before | After | p |
    |---|---|---|---|
    | RUNNING → SUCCEEDED | 3.35 s | **0.12 s** | 0.0001 |
    | SUCCEEDED → client exits | 2.48 s | 3.84 s | 0.0001 |
    | Client total | 36.07 s | 34.31 s | see below |

    For the total, the rank test gives p = 0.038 and the permutation test on means gives p = 0.38, because of one 41.6 s candidate run.
  - **Manual, on kind:** one launch each for a job that succeeds, one that fails (exit 3), one still running when its launch returned, and one with `SKYPILOT_ENABLE_GRPC=1`. Recorded end times are within 6–60 ms of the job's last output.
- [ ] All smoke tests: `/smoke-test` (CI) or `pytest tests/test_smoke.py` (local)
- [ ] Relevant individual tests: `/smoke-test -k test_name` (CI) or `pytest tests/test_smoke.py::test_name` (local)
  - Not run. Suggested:
    - `test_managed_job.py`: `test_managed_jobs_basic`, `test_managed_jobs_cli_exit_codes`, `test_managed_jobs_logs_tail`, `test_managed_jobs_recovery_kubernetes_multinode`, `test_managed_jobs_exit_code_recovery_single`
    - `test_basic.py::test_jobs_launch_and_logs`
  - The non-consolidation (controller cluster) path also needs a CI run.
- [ ] Backward compatibility: `/quicktest-core` (CI) or `pytest tests/smoke_tests/test_backward_compat.py` (local)
  - Not run; recommended. The codegen uses only `job_lib` functions that existing cluster runtimes have.

---

## `ej-prj-i2-5`: The launch latency changes, rebased on master

Commits: 20 on master `796c5bcc8`, ending at `7e488f558`. Of these, `7e488f558` is the only new work; the other 19 are the earlier stack, rebased.

This branch is large for one PR. Use it as the base for smaller PRs, or as a reference for the combined result.

### Summary

- **Rebase.** Brings `ej-prj-3-job1` and `ej-prj-i2-2` to `ej-prj-i2-4` onto `796c5bcc8`, which is 14 commits newer than their base. The one conflict, in `sky/utils/annotations.py` and `test_annotations.py`, kept both sides.
- **Reworded message.** `7db718aa0` corrects `b848c9c1e`'s explanation of the longer wait after SUCCEEDED. The code is the same.
- **`[Test] Let the launch benchmark use a separate task for the candidate`** (`7e488f558`).
  - A candidate that needs its own image can't share a task YAML with the baseline.
  - `--candidate-task` in `bench_launch_latency.py` sets the candidate's task, and defaults to `--task`. The two tasks must have the same `num_nodes`.
- **Everything in the branch:**

  | Area | Commits |
  |---|---|
  | Ray and pod startup | `7251606a1`, `ab543979c`, `863c66883`, `c727790d3`, `0c576e860`, `1ddcc3240`, `71b3c9213` |
  | Lost pods | `b7f871174`, `ee4e69d1a`, `fab8e57ed`, `cd9a21dcc` |
  | Managed jobs | `04040ba00`, `96019e28a`, `30890119e`, `7db718aa0` |
  | Storage lookup | `dc6c01a92` |
  | Benchmark | `e08dabd78`, `6de470672`, `08a101ba1`, `7e488f558` |

### Tested

- [x] Code formatting: `yapf --diff` and `isort --check` are clean on the changed files. Pylint on the changed `sky/` files rates 10.00/10. mypy has no errors beyond master's 2 in `fetch_nebius.py`.
- [x] Any manual or new tests for this PR (please specify below)
  - **`tests/unit_tests/test_sky/jobs`, `test_pod_run_wait.py` and `test_ray_patches_payload.py`:** 1432 passed, 1 failed. The failure is the same `test_storage_teardown_retries_a_transient_error`, which also fails intermittently on master.
  - **Full unit suite:** 11,001 passed. 3 failed and passed on rerun, and on master. `test_adaptor.py` hangs, also on master.
  - **`--candidate-task`:** used for the `sky launch` A/B below.
  - **A/B against master:** see "Benchmark against master" below.
- [ ] All smoke tests: `/smoke-test` (CI) or `pytest tests/test_smoke.py` (local)
- [ ] Relevant individual tests: `/smoke-test -k test_name` (CI) or `pytest tests/test_smoke.py::test_name` (local)
  - Not run on this branch. The 32 chosen tests in `launch_latency_consolidated_design.md` §7.5 ran on `ej-prj-3-job1`, before the `ej-prj-i2-*` commits and this rebase. Re-run them here.
- [ ] Backward compatibility: `/quicktest-core` (CI) or `pytest tests/smoke_tests/test_backward_compat.py` (local)
  - Not run; recommended.

### Benchmark against master

`ej-prj-i2-5` (`7e488f558`, bytecode image) against master `796c5bcc8`, the commit it's based on (published image). Both use `IfNotPresent`, 6 nodes, 8 measured runs per arm, and all runs succeeded. Real master defaults to `Always`, so this setup slightly favors master.

**`sky launch`:**

| Metric | master | `ej-prj-i2-5` | Change | p |
|---|---|---|---|---|
| **Launch wall time** | 44.13 s (42.1–49.7) | **29.67 s** (24.7–32.5) | **−14.46 s (−33%)** | 0.0002 |
| Provisioning total | 27.03 s (25.1–32.1) | 15.24 s (10.6–18.0) | −11.79 s (−44%) | 0.0002 |
| Runtime setup end → launched | 17.41 s (14.9–21.0) | 3.58 s (2.2–6.0) | −13.83 s (−79%) | 0.0002 |
| Pods ready | 2.77 s (2.6–3.1) | 1.92 s (1.5–2.2) | −0.85 s (−31%) | 0.0002 |
| Runtime setup | 6.70 s (4.8–14.3) | 9.27 s (4.4–13.8) | +2.58 s | 0.49 (not significant) |

**`sky jobs launch`:**

| Phase | master | `ej-prj-i2-5` | Change |
|---|---|---|---|
| A: client start → job row created | 6.7 (6.4–7.1) | 7.0 (6.9–7.4) | +0.2 |
| B: row created → STARTING | 2.6 (2.2–4.4) | 2.5 (2.1–4.4) | −0.1 |
| C: STARTING → provisioning starts | 3.4 (3.1–3.9) | 2.9 (2.5–4.0) | −0.4 |
| **D: provisioning → job submitted** | 37.4 (29.5–124.8) | **17.8** (13.8–21.9) | **−19.6** |
| E: job runs on the cluster | 8.5 (8.2–8.5) | 6.7 (6.4–6.8) | −1.8 |
| F: job ended → RUNNING | 2.8 (1.8–3.6) | 2.6 (2.0–3.1) | −0.2 |
| **G: RUNNING → SUCCEEDED** | 14.5 (10.3–17.6) | **0.1** (0.1–1.6) | **−14.4** |
| H: SUCCEEDED → client exits | 2.8 (2.3–5.4) | 3.9 (2.6–5.1) | +1.2 |
| **Client total** | **79.1** (70.0–166.7) | **45.0** (39.1–49.2) | **−34.0 (−43%)** |

The client total's p-value is below 0.001 (permutation test on means).

- **Every `ej-prj-i2-5` launch beat every master launch,** on both benchmarks.
- **Runtime setup stalls remain on both arms.** In `sky launch`, 4 of 8 `ej-prj-i2-5` runs spent 13.3–13.8 s in runtime setup, and the others 4.4–5.3 s. The cause in this run wasn't found.
- **Master's setup was unusually slow in the `sky jobs launch` run:** a median of 19.9 s, and 107.9 s in the 166.7 s run, against 6.27 s on `ej-prj-i2-5`. That likely inflates this −34.0 s. An earlier A/B from the older base `5ef55efa4` measured −28.8 s (69.9 → 41.1 s).
- **Users won't see all of this yet.** The bytecode image isn't published, and the template still sets `imagePullPolicy: Always`.

Results: `ej/bench_results/20261102-1942-master-i2-5/` (`sky-launch/summary.md`, `jobs/report.md`).
