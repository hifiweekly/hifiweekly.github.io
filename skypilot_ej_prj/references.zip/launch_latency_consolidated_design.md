# Design: faster Kubernetes launches for `sky launch` and `sky jobs launch`

This doc consolidates five changes:

| Branch | Change | Layer | Detailed design |
|---|---|---|---|
| `ej-prj-0` | Start Ray in the pod before preparing SkyPilot | Pod template | `ray_first_pod_bootstrap_design.md` |
| `ej-prj-1` | Wait for Ray in one blocking call; start skylet during the wait | Provisioner | `ray_wait_and_skylet_overlap_design.md` |
| `ej-prj-3` | Skip the needless `ray stop`; pre-install the runtime pins in the image | Ray start commands, image | `ray_start_sooner_ej-prj-3.md` |
| `ej-prj-job0` | Fetch status and submitted-at in one call; skip the first status-check sleep when the job already finished; re-check status when the controller logs | Managed-jobs controller, client log follower | `launch_latency_managed_jobs_ej-prj-3.md` §3, §7, §10 |
| `ej-prj-job1` | Look up the enabled storage clouds once per request | Server request (`jobs.launch`) | §12 of this doc |

- **Combined branch:** `ej-prj-3-job1` (renamed from `ej-prj-3-job0`), which has all five. Pushed to the fork at `8786d20be`.
- **Every branch is pushed to the fork** (https://github.com/siliconej/skypilot). PR descriptions, with the Tested checklist filled in, are in `pr_descriptions.md`.
- **Diagrams:** `sky_jobs_launch_sequence.svg` (4 nodes) and `sky_jobs_launch_sequence_6nodes.svg` (6 nodes) show where each change acts in the `sky jobs launch` sequence.
- **Also in that branch:** `ej-prj-bonus`, the fail-fast change for pods lost during setup (`pod_loss_fail_fast_design.md`). It doesn't change launch latency, so it's only covered where it touches the same code.

## 1. Summary

A multi-node launch on Kubernetes spent most of its time waiting for Ray to come up on every pod. For managed jobs, another 15–35 s went to controller polling.

- The pod-side and provisioner changes (`ej-prj-0`, `ej-prj-1`, `ej-prj-3`) start Ray sooner and notice sooner that it's up.
- The controller change (`ej-prj-job0`) notices sooner that a managed job has started and finished.
- The request change (`ej-prj-job1`) stops the server's `jobs.launch` from running the storage check twice. It saves only about 0.2 s; the first check (4.8 s) remains (§13).
- **The gain grows with cluster size:** −11.4 s on 4 nodes, −16.0 s on 6 (§14). Every 6-node branch run beat every master run.
- **Provisioning has two clear next steps** (§15): drop the pod's PyPI dry run by installing the wheel offline, and stop re-pulling SkyPilot's immutable default image. Both were tested by hand and are worth about 3.5 s each on 6 nodes.

Headline numbers, from kind running `ej/job.yaml` (details in §7, §13 and §14):

| Measure | Before | After |
|---|---|---|
| `sky launch`: runtime setup end → "Cluster launched" | 12.5 s | 9.4 s (`ej-prj-0` + `ej-prj-1`) |
| `sky launch`: provisioning total | 20.9 s | 16.8 s (`ej-prj-0` + `ej-prj-1`) |
| `sky launch`: head container start → whole cluster in Ray | 12.95 s | 11.37 s (adding `ej-prj-3`) |
| `sky jobs launch`: provisioning start → job submitted | 24.9 s | 22.5 s (19.1–20.1 s in fast runs) |
| `sky jobs launch`: job ended → SUCCEEDED (F + G) | 14.3 s (random) | **4.9 s** (steady) |
| `sky jobs launch`: client start → job SUCCEEDED | 59.0 s | **48.4 s** |
| `sky jobs launch`: client total | 61.5 s | **50.1 s** (−11.4 s) |
| `sky jobs launch`, **6 nodes**: provisioning start → job submitted | 32.7 s | **26.3 s** |
| `sky jobs launch`, **6 nodes**: client total | 70.8 s | **54.8 s** (−16.0 s) |

The `sky jobs launch` rows are medians of interleaved A/Bs of master (`815e61a76`) against `ej-prj-3-job1` (`7aeec8ede`), 8 runs per side: 4 nodes in §13, 6 nodes in §14. Rows without "6 nodes" are 4 nodes.

## 2. Background: where a launch spent its time

### 2.1 `sky launch` on master

```
CLI ─▶ write config ─▶ create pods ─▶ pods Running ─▶ file mounts ─▶ runtime setup ─▶ wait for Ray ─▶ skylet ─▶ submit job
                                                                                     (61–67% of provisioning)
```

Inside each pod, step 2 of the template's startup script ran in sequence:
1. Install Ray, and the `setuptools<70` and `click<8.3.0` pins.
2. Install SkyPilot from PyPI.
3. Apply the Ray patches.
4. Run `ray stop`.
5. Run `ray start`.

Workers wait for the head's GCS port before they start, so a late head delays the whole cluster.

The provisioner polled for Ray once a second. Each probe was a `kubectl exec` that started three Python interpreters, about 2.3–4 s, so it could learn that Ray was up as much as a full probe late. Skylet started only after that.

### 2.2 `sky jobs launch` on top of that

The jobs controller (in consolidation mode, inside the API server) runs the same `sky.launch` path for each job's cluster. It adds its own steps:

| Phase | Median on master |
|---|---|
| Client start → job row created (the server's `jobs.launch`) | 7.4 s |
| Row created → controller picks the job up | 2.5 s |
| Controller → provisioning starts | 3.1 s |
| **Provisioning → job submitted on the cluster** | 26.8 s |
| Job runs (a one-line `echo` on 4 nodes) | 7.7 s |
| Job finished → controller marks it RUNNING | 3.0 s |
| **RUNNING → SUCCEEDED** | 7.7–15.8 s (random) |
| SUCCEEDED → client exits | 2.6–2.8 s |

## 3. Design

### 3.1 `ej-prj-0`: start Ray before preparing SkyPilot in the pod

**Where:** `sky/templates/kubernetes-ray.yml.j2` (step 2), plus docstrings in `sky/provision/instance_setup.py`.

**Problem.**
- The PyPI install of `skypilot[kubernetes,remote]` sat on Ray's critical path.
- Nothing before `ray start` imports `sky`: the patches and the hostNetwork probe are shipped inline.
- The installed copy is thrown away when `setup_runtime_on_cluster` installs the cluster's own wheel.

**New order of step 2:**

```
ray install (unchanged)
[HA only] uv pip install skypilot[kubernetes,remote]
apply Ray patches (unchanged)
( ray start --head | wait for head port + ray start ) &      # background
[non-HA] uv pip install --dry-run 'skypilot[kubernetes,remote]'   # warms uv's cache
touch /tmp/ray_skypilot_installation_complete               # marker for setup_commands
wait $SKY_RAY_START_PID                                      # step still fails if Ray fails
```

**Key points:**
- **The dry run was needed for this design.** The old install also warmed uv's cache. Without it, the wheel install's dependency resolve took 4.5–6 s instead of about 20 ms.
  - **Superseded by §15.** On 6 nodes the dry run itself became the slowest step of provisioning: the slowest pod's PyPI resolve sets how long runtime setup takes. An offline wheel install (12 ms, no PyPI) makes the dry run unnecessary.
  - `--dry-run` changes nothing in the environment, so it is safe to run while Ray starts.
  - It is best-effort (`|| echo WARNING`).
- **The marker keeps its meaning:** "setup_commands may install the wheel now". It is written after every step that changes the environment.
- **A Ray start failure still fails the step.** Under `set -e`, the final `wait` propagates Ray's exit code, so `/tmp/runtime-setup.failed` is written and the pod exits, as before.
- **HA controllers keep the PyPI install before `ray start`.** HA recovery imports `sky` before `setup_commands` run again.

### 3.2 `ej-prj-1`: one blocking Ray wait, with skylet started meanwhile

**Where:** `sky/provision/instance_setup.py` (`_WAIT_ALIVE_NODES_PY`, `ray_wait_for_alive_nodes_command`, `RAY_WAIT_DONE_MARKER`) and `sky/provision/provisioner.py` (`wait_for_ray_cluster_healthy`, `_run_alongside`, `parse_ray_probe`).

**Blocking wait.** The provisioner makes one `kubectl exec` that runs a small Python script on the head. The script uses only the standard library and `ray`, and is sent base64-encoded. Each round it:

1. Re-reads the Ray port file.
2. TCP-checks the port.
3. Keeps one `GcsClient` open and counts ALIVE nodes.
4. Sleeps 0.2 s.

It returns when `alive == num_nodes` or the deadline passes.

- **Output** has the same format as the old probe, plus a final `SKY_RAY_WAIT_DONE` line.
- **Missing done line.** Output without it means the exec dropped, not that Ray is down. The call is retried with the time left.
- **Hung exec.** A local timeout of `remaining + 30 s` bounds a hung exec.

**Skylet during the wait.** `_run_alongside(main, background)` runs `start_skylet_on_head_node` in a thread while the main thread waits for Ray.
- The thread gets the provision log path, which is thread-local, and the request's `contextvars`.
- It is joined before returning, and its errors are re-raised.
- Skylet's startup doesn't use Ray, and no job can be submitted until both finish, so starting skylet early is safe.

**Unchanged:**
- the exact-count health rule;
- the 90 s fallback that starts Ray from the provisioner;
- the `no_restart=True` path for workers;
- relaunches of an existing cluster and non-K8s clouds, which still use the single probe.

### 3.3 `ej-prj-3`: start the head's Ray sooner

**Where:** `sky/provision/instance_setup.py` (`RAY_STOP_IF_RUNNING`), `Dockerfile_k8s`, `Dockerfile_k8s_gpu`, and `docs/source/reference/kubernetes/kubernetes-getting-started.rst`.

**Guarded `ray stop`.**
- **The cost:** both start commands ran `ray stop` before `ray start`. On a fresh pod there is nothing to stop, yet it costs a Python start: 1.4–1.5 s idle, 2.9–3.8 s while the pod is busy.
- **The guard:** `RAY_STOP_IF_RUNNING` now runs it only if a GCS, raylet or dashboard process is running.

```bash
if ! command -v pgrep > /dev/null 2>&1 || pgrep -f \
  "ray/core/src/ray/[g]cs/gcs_server|ray/core/src/ray/[r]aylet/raylet|ray/[d]ashboard/" \
  > /dev/null 2>&1; then ray stop; fi;
```

- **It can't match itself.** A bracketed letter means the pattern doesn't match the command line of the shell running it.
- **Without `pgrep`, Ray is always stopped,** as before.
- **Restart paths still stop Ray first,** because Ray is running there.

**Pins in the image.**
- **The cost:** the template pins `setuptools<70` and `click<8.3.0` at pod start, but the image ships setuptools 84. Every pod downloaded setuptools from PyPI before it could start Ray: 0.6 s usually, 12 s in one traced launch.
- **The fix:** the Dockerfiles and the docs' custom-image snippet now install both pins, so a pod only checks them (about 2 ms).
- **It takes effect only after the image is rebuilt and published.**

**Not changed:**
- **The dashboard.** Disabling it saves about 0.9 s on the head's own `ray start`, but not on the GCS port the workers wait for. Users may also rely on it.
- **Baking the Ray patches into the image.** That saves about 1 s, but needs a version stamp.

### 3.4 `ej-prj-job0`: notice a short managed job's end sooner

**Where:**
- `sky/jobs/recovery_strategy.py`: `_wait_until_job_starts_on_cluster` and `pop_job_status_seen_at_launch`.
- `sky/jobs/controller.py`: the first sleep of the monitor loop.
- `sky/jobs/utils.py`: `get_job_status_and_submitted_at`, `_job_status_and_submitted_at_on_head` and `_fetch_job_status_on_head`.
- `sky/skylet/job_lib.py`: `JobLibCodeGen.get_job_status_and_submitted_timestamp`.

**One head command for status and submitted-at.**
- **The cost:** after `sky.launch` returns, the controller confirms that the job started by fetching its status, then its submitted-at time. Without gRPC, each fetch is a `kubectl exec` of about 1.6 s.
- **The fix:** a new codegen prints both payloads from one command. The parser takes them in order.
- **It works on older cluster runtimes.** It calls only `job_lib.get_statuses_payload` and `job_lib.get_job_submitted_or_ended_timestamp_payload`, which today's code already calls on clusters.
- **Fallback:** with gRPC, or if the time is missing, the old separate call is still made.
- **Error handling is unchanged.** `_fetch_job_status_on_head` is shared with `get_job_status`, so transient and fatal errors are told apart exactly as before.

**No first-check sleep when the launch already saw the job finish.**
- **The cost:** the monitor loop sleeps `uniform(0, 15)` s before its first status check, to spread out loops that start together.
- **Why it was wasted:** for short jobs, the launch had already seen the job finish, and threw that status away.
- **The fix:** the executor now remembers the status the launch (or a recovery) saw. If it is terminal, the loop checks immediately.
- **Running jobs keep the jittered first gap.** Checking a running job sooner wouldn't help: the next check is still a full gap later.
- **Executors built without `__init__` are covered.** The remembered status is a class-level default of `None`, so subclasses and tests that skip `__init__` work.
- **Stale statuses are cleared.** The value is reset at the start of every wait, and when the timestamp fetch fails, so it can't carry over from an earlier launch.

### 3.5 `ej-prj-job0`, continued: the client checks the status when the controller logs

See §11. The follower in `_stream_logs_by_id` re-checks the job's status as soon as the controller writes a plain line to the job's log, instead of only every 15 s.

### 3.6 `ej-prj-job1`: look up the enabled storage clouds once per request

See §12. The answer, including "no storage cloud", is cached for the rest of the request, keyed by workspace and config.

## 4. How the changes compose

They change different code and different phases of the launch, so their gains add up:

| Phase | Changed by |
|---|---|
| Server request: storage-cloud lookups in `jobs.launch` | `ej-prj-job1` |
| Pod startup: PyPI install before `ray start` | `ej-prj-0` |
| Pod startup: `ray stop` before `ray start`; setuptools download | `ej-prj-3` |
| Provisioner: noticing Ray is up; skylet start | `ej-prj-1` |
| Controller: confirming the job started | `ej-prj-job0` (status + submitted-at) |
| Controller: noticing the job finished | `ej-prj-job0` (first-check sleep) |

**Interactions:**
- **`ej-prj-0` needs `ej-prj-1` to show.** Alone, its earlier Ray was usually seen on the same 3–5 s probe, so its A/B was not significant (§7.1). With the 0.2 s blocking wait, the gain appears.
- **`ej-prj-3` moves the bottleneck.** Once Ray is up sooner, the skylet start (3–4 s, running alongside the wait) is close to being the critical path. Further Ray-side gains matter less unless skylet also starts earlier.
  - **Why skylet takes 3.4 s on the branch, against 1.6 s on master** (§15): `import sky.skylet.attempt_skylet` runs `sky/__init__.py`, which imports the whole SDK. On a freshly installed wheel that compiles bytecode: 4.5 s cold, 1.3 s warm. It isn't CPU contention, as first assumed.
- **All of the provisioning gains reach managed jobs.** The controller launches job clusters through the same `sky.launch`. In consolidation mode it runs the server's code; otherwise the controller cluster gets a wheel built from the same code.
- **`ej-prj-job0` makes managed-job results comparable.** It removes the controller's random 0–15 s wait, which used to swamp the provisioning gains in the totals.

## 5. Failure handling

| Situation | Behaviour with all the changes |
|---|---|
| `ray start` fails in a pod | The step fails through `wait $SKY_RAY_START_PID`; the pod exits. Same as master. |
| The uv dry run fails (no PyPI) | A warning is logged and the step continues. The wheel install resolves on a cold cache, or fails on its own. |
| A worker never joins within 90 s | The wait returns a partial count; workers are started with `no_restart=True`. Same as master. |
| `kubectl exec` drops during the wait | Missing done line, so the call is retried. It doesn't trigger a Ray restart. |
| Ray is already running when a start command runs | The guard finds it and runs `ray stop`, as before. |
| No `pgrep` in a custom image | The guard always runs `ray stop`, as before. |
| Skylet fails to start | The launch fails once the wait returns. |
| A pod is deleted during setup | `ej-prj-bonus` fails the launch in about 5–11 s instead of about 100 s; managed jobs recover sooner. |
| The combined status fetch errors | Same transient/fatal classification as `get_job_status`; the wait retries. |
| The cluster runtime lacks the submitted-at payload | `submitted_at` is None, and the old separate call is made. |
| The launch saw the job RUNNING | The jittered first check is unchanged. |
| A controller restart resumes jobs | No launch status is remembered, so the jittered first check is unchanged. |

## 6. Compatibility

- **API, client and server:** no change, so there is no `API_VERSION` bump. Everything is server-side or in the cluster's startup script.
- **Existing clusters:** pod arguments apply only to new pods. The controller's combined fetch uses functions every supported runtime has, and falls back if the timestamp is missing.
- **Custom images:**
  - Their dependencies now install in `setup_commands` (`ej-prj-0`), off Ray's critical path.
  - Without the pins pre-installed, they still download setuptools at pod start, which is no worse than before.
  - The docs snippet now suggests installing the pins.
- **HA controllers:** keep the PyPI install before `ray start`.
- **gRPC (`SKYPILOT_ENABLE_GRPC=1`):** unaffected by the combined fetch, which keeps two cheap gRPC calls. gRPC separately saves about 3.5 s per launch in job submission (measured in `launch_latency_analysis_4_nodes.md` §6).

## 7. Results

All measurements are on `kind-skypilot` (one kind node, 12 host cores), with `ej/job.yaml` on 4 nodes. Medians of 5 runs unless stated.

### 7.1 `sky launch` A/B (`bench_launch_latency.py`)

| Candidate | Baseline | Runtime setup end → launched | Provisioning total | Verdict |
|---|---|---|---|---|
| `ej-prj-1` (`532cced15`) | `1f9136510` | 12.47 → **9.89 s** (−21%, p=0.004) | 20.38 → **17.38 s** (−15%) | VALID |
| `ej-prj-0` alone (`9c42bf108`) | `5ef55efa4` | 12.73 → 12.43 s (−2%) | 20.56 → 20.86 s | NOT PROVEN (masked by the old polling) |
| `ej-prj-0` + `ej-prj-1` (`a291dec2a`) | `5ef55efa4` | 12.49 → **9.43 s** (−24%, p=0.004) | 20.85 → **16.77 s** (−20%) | VALID |

### 7.2 `ej-prj-3` on top (pod-side timing, 3 runs against 5)

| Metric | `ej-prj-bonus` (0+1+bonus) | `ej-prj-3` | Δ |
|---|---|---|---|
| Head container start → GCS up | 7.31 s | 5.89 s | −1.4 s |
| Head container start → whole cluster in Ray | 12.95 s | 11.37 s | −1.6 s |
| Client total, runs without a slow pod | 33.4–35.0 s | 32.0 / 32.4 s | about −2 s |

The image pins are not in these numbers: kind pulls the published image.

### 7.3 `sky jobs launch` (consolidation mode, `sky api start --deploy`)

An earlier session, with blocks of runs rather than interleaved ones. The interleaved A/Bs in §13 (4 nodes) and §14 (6 nodes) supersede these totals.

| Phase (median) | master | master (re-run) | job0 only | ej-prj-3 (0+1+bonus+3) | **combined** |
|---|---|---|---|---|---|
| Provisioning → job submitted | 26.8 | 27.2 | 25.5 | 19.2 | **18.7** |
| Job finished → RUNNING | 3.0 | 2.9 | 1.3 | 3.1 | **1.8** |
| RUNNING → SUCCEEDED | 7.7 | 15.8 | 3.4 | 14.5 | **3.4** |
| SUCCEEDED → client exits | 2.8 | 2.6 | 4.6 | 4.5 | 6.7 (2.6–12.3) |
| **Client start → SUCCEEDED** | 60.4 | 70.1 | 55.0 | 59.6 | **45.3** |
| Client total | 62.9 | 72.4 | 58.9 | 63.0 | **57.6** (46.4–67.1) |

- **The provisioning changes save about 8 s per managed job.**
- **`ej-prj-job0` saves 1.2–1.7 s while confirming the job started.** It also reduces RUNNING → SUCCEEDED to a steady 3.4 s, against a random 7.7–15.8 s, so about 7.5 s on average.
- **The controller has the job done by 45 s, against 60–70 s on master.** The client's exit now varies the most: two combined runs exited quickly and finished in 46.4 s and 46.9 s end to end.
- **The first combined run was a warm-up after a server restart:** its submit request took 13.4 s and the controller's launch 9.0 s.

### 7.4 Unit tests

- **New tests by change:**
  - `ej-prj-0`: `test_pod_starts_ray_before_preparing_skypilot`.
  - `ej-prj-1`: 12 tests in `test_provisioner_ray_wait.py`.
  - `ej-prj-3`: 6 tests in `test_ray_stop_if_running.py`.
  - `ej-prj-job0`: 14 tests, including one that runs the generated codegen against a real job table.
  - `ej-prj-job1`: 14 tests (11 for the cache, 3 for `ttl_cache`).
  - `ej-prj-bonus`: 9 tests for the lost-pod checks and the exec retry rule.
- **On `ej-prj-3-job1`:** the jobs, skylet, provision and Kubernetes suites ran 3141 passed and 2 failed.
  - `test_details_is_none_when_no_state_or_failure` also fails on master.
  - `test_pending_volume_probe::...one_cluster_event_per_second` is timing-sensitive; it passes when run alone.
- **Each branch on its own** (a worktree per branch, its own code imported): every branch's new tests pass. The only failure, on `ej-prj-job0`, is the `test_details_is_none...` that also fails on master.
- **Lint:** yapf and isort are clean on every branch. Pylint on `sky/`, which is what CI lints, adds no messages over master; the new messages are all in test files.
- **mypy:** `ej-prj-bonus` added `command_runner.is_exec_target_gone()` but not to its type stub, so CI's mypy check would have failed on `ej-prj-bonus`, `ej-prj-3` and `ej-prj-3-job1`. Fixed by `7aed7c84e` on `ej-prj-bonus`, cherry-picked as `aeb9e96f7` and `8786d20be`. Every branch now has only master's 2 mypy errors (`fetch_nebius.py`).

### 7.5 Smoke tests

Run locally with `--kubernetes` on kind, consolidation mode, against `ej-prj-3-job1` before `ej-prj-job1` was added. 32 tests chosen by what each change touches:

| Change area | Tests | Result |
|---|---|---|
| Pod startup (`ej-prj-0`, `ej-prj-3`) | `test_minimal`, `test_launch_fast`, `test_multi_hostname`, `test_multi_node_failure`, `test_kubernetes_non_debian_image` ×2, host-network ×3, image tests ×2, `test_kubernetes_post_provision_runcmd` | 11 passed, 1 not run |
| Provisioner (`ej-prj-1`, `ej-prj-bonus`) | `test_kubernetes_pod_loss` ×2 (new), `test_kubernetes_recovery`, `test_kubernetes_pod_failure_detection`, provision-log streaming ×2, `test_kubernetes_provision_command_timeout` | 7 passed |
| Managed-jobs controller (`ej-prj-job0`) | `basic`, `pipeline`, recovery ×2, exit-code recovery ×2, `retry_logs`, `wait_success`, `node_names_multi_node` | 9 passed |
| Client follower (`ej-prj-job0`) | `logs_tail`, `cli_exit_codes`, `cancelled_job_logs`, `test_jobs_launch_and_logs` | 4 passed |

- **3 tests first failed for lack of CPU** on the one kind node, with 4 tests running at once. They passed when rerun one at a time.
- **Not run:** `test_kubernetes_host_network_relaunch_after_ray_stopped` needs 2 schedulable nodes. `test_managed_jobs_log_tail_cleanup` is skipped in consolidation mode, and the HA tests need an HA controller.
- **Not yet run with `ej-prj-job1`:** the storage tests, which need a storage cloud.

## 8. Risks

- **One long-lived exec per launch.** The Ray wait holds a `kubectl exec` open for up to 90 s, and some proxies drop idle streams. Drops are retried; if they turn out to be common, add a heartbeat line.
- **More concurrent work on the head during startup.** Skylet, the uv dry run and Ray all start together. That's fine on the clusters tested, but it could slow pods with less than 1 CPU.
- **PyPI still matters, more with more nodes.** The uv dry run is the remaining PyPI step on the pod's path. Runtime setup waits for the slowest pod's resolve, so the chance of a slow one grows with the node count: about 1 run in 5 on 4 nodes, 6 of 8 runs on 6 nodes (§15).
- **Package changes on custom images while Ray runs.** Dependencies the wheel adds are now installed after Ray has started. Ray's lazy imports could see a changed package.
- **The guard depends on Ray's process paths.** If Ray renames `gcs_server` or `raylet`, the guard sees no Ray and skips `ray stop` on a restart. A test pins the pattern, and on a fresh pod skipping is correct anyway.
- **The image change needs a rebuild and publish.** Until then it has no effect.
- **The first-check skip is for short jobs only.** A job still running when the launch returns still waits up to 15 s past its end. For long jobs that's a small fraction of the run.

## 9. Remaining work, by expected gain

Gains are for a 6-node `sky jobs launch` on kind (§14, §15).

1. **Install the cluster's wheel offline first and drop the pod's uv dry run** (`kubernetes-ray.yml.j2`, `SKYPILOT_WHEEL_INSTALLATION_COMMANDS`). About −3.4 s at the median, up to −5.7 s; it also removes PyPI from the pod's path. Fall back to the online install when the offline one fails (custom images missing dependencies). Tested by hand in §15.
2. **Use `imagePullPolicy: IfNotPresent` for SkyPilot's default image.** Its tag is date-stamped and never changes. About −3.5 s (pods up in 1.6–3.1 s against 5.1–6.6 s). Keep `Always` for user images and mutable tags such as `:latest`. Tested by hand in §15.
3. **Cache the first storage check across requests** (4.8 s of phase A's 6.8–7.1 s, §13). Cache "no storage cloud enabled" with a TTL instead of per request.
4. **Steady RUNNING → SUCCEEDED (3.4–3.6 s).** Reuse the terminal status the launch saw, and fetch the end time with it, so only one head command remains.
5. **Cluster launched → job submitted (3.8 s).** Separate `kubectl exec` calls for file sync, setup and job submission. Turn on gRPC by default for Kubernetes clusters (about 3.5 s per launch earlier), or merge the calls.
6. **Make the skylet start import less** (`attempt_skylet` imports the whole SDK: 4.5 s with cold bytecode, 1.3 s warm). It overlaps the Ray wait today, but less once item 1 lands; estimated about 2 s then.
7. **Bake the Ray patches into the image,** with a version stamp (about 1 s per pod).
8. **Publish the rebuilt image** (`ej-prj-3`'s pins). Pods still download `setuptools<70` (0.3–0.9 s each on 6 nodes).

Done: the client exit after SUCCEEDED (§11), and the repeated storage checks (`ej-prj-job1`, §12, about 0.2 s). The slow runtime setup seen in half the 4-node runs is root-caused in §15 (item 1).

## 10. Reproducing

```bash
# sky launch A/B (builds two worktrees, alternates runs)
python ej/bench_launch_latency.py run --candidate-ref ej-prj-3-job1 \
    --task ej/job.yaml --runs 5

# sky jobs launch A/B, master against ej-prj-3-job1: 4 alternating blocks of
# (switch code, sky api start --deploy, 1 warm-up + 4 measured runs).
# Set num_nodes in ej/job.yaml first. Results go to ej/bench_jobs/out/.
bash ej/bench_jobs/run_ab.sh
python3 ej/bench_jobs/analyze_ab.py ej/bench_jobs/out master branch    # phases A-H
python3 ej/bench_jobs/breakdown_d.py ej/bench_jobs/out master branch   # phase D stages
```

- **Per-phase times** come from `spot.created_at`/`start_at`/`end_at` and `job_events` in `~/.sky/spot_jobs.db`, `cluster_events` in `~/.sky/state.db`, and each run's `provision.log`.
- **`trace_job2.py`** runs one `sky jobs launch`. It refuses to start if another managed job is running, and marks a trace CONTAMINATED if one appears.
- **`instrument.py`** temporarily wraps the storage lookup to log each call to `~/storage_probe.log`. Restore `sky/data/storage.py` afterwards.

## 11. Update: client exit fix (`ej-prj-job0` `7c26bd708`; on `ej-prj-3-job1` `f506c2f1c`)

**The problem.** While a job isn't RUNNING, the client's log follower (`_stream_logs_by_id`) re-checks the job's status only every 15 s. After §3.4 shortened RUNNING to about 3.4 s, the client usually missed it, and noticed the job had finished up to 15 s late. That made the total either about 46 s or about 57 s, depending on a sub-second race (`launch_latency_managed_jobs_ej-prj-3.md` §9).

**The fix.** The follower already reads the controller's per-job log every second. It now also re-checks the status as soon as the controller writes a line of its own there. The controller writes such lines right after each status change, and only about 15 while a cluster is being set up, so the extra checks are few. The 15 s check stays as a fallback.

**Result on `ej-prj-3-job1`** (6 clean runs):
- **Client exit:** 2.4–3.0 s after SUCCEEDED, against 1.6–12.6 s before.
- **`sky jobs launch` total:** median 49.0 s; 48.8 s without the warm-up run after the server restart. Master took 62.9–72.4 s.

This was item 1 of the earlier remaining-work list (§9 now lists it as done).

## 12. Update: storage-cloud lookup once per request (`ej-prj-job1` `d37133a6f`; on `ej-prj-3-job1` `7aeec8ede`)

**The problem.**
- `storage_lib.get_cached_enabled_storage_cloud_names_or_refresh()` lists the clouds whose object storage can be used. It reads the cached enabled clouds for the STORAGE capability, then checks the storage-only providers (R2, CoreWeave, VAST Data, Hugging Face).
- With no storage cloud enabled (here, Kubernetes only), the cached list is empty. `get_cached_enabled_clouds_or_refresh` treats empty as "not checked yet", so every call re-ran the storage check: 0.3–0.7 s warm, about 4.8 s cold. The storage-only provider checks take about 0 ms.
- One `jobs.launch` calls it three times:
  - `sky/jobs/server/core.py`, to decide whether file mounts go through a bucket;
  - `sky/utils/controller_utils.py`, to pick the controller's extra packages;
  - `sky/task.py`, for the preferred store.

**The fix** (`sky/data/storage.py`).
- The lookup moved into `_enabled_storage_cloud_names(workspace, config_fingerprint)`, cached with `annotations.ttl_cache(scope='request', maxsize=16, ttl=60, lock=...)`.
- **Empty answers are cached too.** They are the slow case.
- **Each request still looks again.** Request-scoped caches are cleared when a request ends, so newly added storage credentials are seen by the next request.
- **Workspaces and configs are kept apart.** The key is the active workspace and `check.current_config_fingerprint()` (renamed from `_config_fingerprint`). That matters in a jobs controller, which serves several and never clears request caches. There the 60 s TTL bounds how long a newly enabled storage cloud can go unseen.
- **The re-check is still seen.** `_is_storage_cloud_enabled` runs `sky check` for a missing cloud, then looks again; it now clears the cache in between.
- **Unchanged behaviour:** callers still get their own list, and `raise_if_no_cloud_access` still raises `NoCloudAccessError`. Failed lookups (e.g. an unreadable workspace) are not cached.
- `annotations.ttl_cache` takes an optional `lock`, since cachetools caches aren't thread-safe on their own.

**Tests.** 11 new tests (`tests/unit_tests/test_sky/data/test_enabled_storage_clouds_cache.py`) and 3 for `ttl_cache`. Full unit suite: 10,704 passed; the 20 failures also fail on master or pass when run alone.

**Correction (§13).** The table below compared two sessions, not an A/B, and overstates the gain. A probe of the lookups in an interleaved A/B shows that `jobs.launch` in consolidation mode looks up the storage clouds twice, not three times: 4.8 s, then 0.2 s on master; 4.8 s, then 0.001 s with the cache. The change saves about 0.2 s, which is within phase A's noise. The 7.3 → 6.5 s below was drift between sessions.

**First measurement on `ej-prj-3-job1`** (6 clean runs, jobs 73–78; medians without the warm-up run; superseded by §13):

| Phase | before (`ej-prj-3-job1` without `ej-prj-job1`) | **with `ej-prj-job1`** |
|---|---|---|
| **Client start → job row created** | 7.3 s (6.8–8.5) | **6.5 s (6.5–7.2)** |
| Row → STARTING | 3.1 s | 2.4 s |
| STARTING → RUNNING | 31.6 s | 31.4 s |
| RUNNING → SUCCEEDED | 3.4 s | 3.4 s |
| SUCCEEDED → client exits | 2.6 s | 2.2 s |
| **Client total** | 48.8 s | **46.9 s** |

- That session's request time dropped about 0.8 s, but §13 shows most of it was drift.

This was item 3 of the earlier remaining-work list (§9 now lists it as done). The first lookup (§9 item 3) is the bigger target.

## 13. A/B against master (all five changes)

**Method.**
- **Arms:** master `815e61a76` against `ej-prj-3-job1` `7aeec8ede` (0 + 1 + 3 + bonus + job0 + job1).
- **Order:** 4 alternating blocks (master, branch, master, branch). Each block switched the code, restarted the API server with `sky api start --deploy`, then ran 1 warm-up run (dropped) and 4 measured runs. That gives 8 measured runs per arm (jobs 79–98).
- **Runs:** `sky jobs launch -y -c ej-prj-3 ej/job.yaml`, one at a time, each verified as the only managed job (`trace_job2.py`). All 20 succeeded.
- **Phases:** from `spot.created_at`/`start_at`/`end_at`, `job_events`, the cluster's "Provisioning on" event, and the client's exit time.

**Result** (median, with the range of the 8 runs):

| Phase | master | **`ej-prj-3-job1`** | Δ | Changed by |
|---|---|---|---|---|
| A: client start → job row created | 6.8 (6.4–7.0) | 6.8 (6.5–7.2) | 0 | `ej-prj-job1` (≈0.2 s, see below) |
| B: row → STARTING | 2.7 (2.3–3.1) | 2.5 (2.1–4.5) | −0.2 | — |
| C: STARTING → provisioning | 3.0 (2.4–3.4) | 3.1 (2.4–3.4) | 0 | — |
| D: provisioning → job submitted | 24.9 (24.0–27.8) | **22.5** (19.1–25.4) | −2.4 | `ej-prj-0`, `-1`, `-3` |
| E: job runs | 7.6 (7.4–8.2) | 7.7 (7.3–8.2) | 0 | — |
| F: job ended → RUNNING | 3.2 (2.4–3.6) | **1.4** (1.0–1.9) | −1.8 | `ej-prj-job0` |
| G: RUNNING → SUCCEEDED | 11.1 (3.7–16.1) | **3.5** (3.4–3.6) | −7.6 | `ej-prj-job0` |
| H: SUCCEEDED → client exits | 2.8 (1.4–6.7) | **2.5** (1.3–2.9) | −0.3 | `ej-prj-job0` (client fix) |
| **Client start → SUCCEEDED** | 59.0 (51.4–64.4) | **48.4** (43.7–51.1) | −10.6 | |
| **Client total** | 61.5 (58.1–67.4) | **50.1** (46.1–54.0) | **−11.4** | |

**Findings.**
- **The controller changes give the most, and the steadiest, gain.** RUNNING → SUCCEEDED went from a random 3.7–16.1 s to 3.4–3.6 s in every run. Every branch run beat every master run on F and G.
- **The client exit no longer varies:** 1.3–2.9 s against 1.4–6.7 s.
- **Provisioning gains show in only half the runs today.**
  - The 4 fast branch runs (jobs 85, 95, 97, 98) submitted the job 19.1–20.1 s after provisioning started.
  - The other 4 (jobs 86, 87, 88, 96) took 24.9–25.4 s, like master.
  - In the slow runs, the step from "Setting up SkyPilot runtime" to "Cluster successfully provisioned" took 15–18 s, against about 11 s in the fast runs and 16 s on master. Root-caused in §15: runtime setup waits for the slowest pod's PyPI dry run (§9 item 1).
- **`ej-prj-job1` doesn't show in phase A.** A probe that logged each storage lookup (3 runs per arm, jobs 99–104; temporary, not committed) found:

  | | 1st lookup (`jobs/server/core.py`) | 2nd lookup (`controller_utils.py`) |
  |---|---|---|
  | master | 4.76–4.85 s | 0.18–0.25 s |
  | `ej-prj-3-job1` | 4.73–4.80 s | 0.001–0.002 s |

  - In consolidation mode, `task.py`'s preferred-store lookup isn't reached, so there are 2 lookups, not 3. The change saves about 0.2 s.
  - **The first lookup costs 4.8 s of phase A's 6.8 s on both arms,** because request caches are cleared after every request. That is the larger target (§9 item 3).
- **Totals against earlier sessions.** Master took 61.5 s here, against 62.9 s and 72.4 s in earlier sessions; G's randomness explains most of that spread. The branch took 50.1 s, against 46.9–49.0 s earlier; the slow provisioning runs explain the difference.

## 14. A/B against master on 6 nodes

Same method as §13, with `num_nodes: 6` in `ej/job.yaml`: 4 alternating blocks, 8 measured runs per arm (jobs 105–124). All 20 runs were clean and succeeded.

| Phase (median, range) | master | **`ej-prj-3-job1`** | Δ | Δ on 4 nodes |
|---|---|---|---|---|
| A: client start → job row created | 6.8 (6.4–7.2) | 7.1 (6.5–7.2) | +0.3 | 0 |
| B + C: hand-off to the controller | 5.6 | 5.4 | −0.2 | −0.1 |
| **D: provisioning → job submitted** | 32.7 (29.6–41.5) | **26.3** (22.3–28.3) | **−6.4** | −2.4 |
| E: job runs | 8.5 | 8.8 | +0.3 | 0 |
| F: job ended → RUNNING | 2.8 (2.2–3.3) | **1.2** (0.8–1.8) | −1.6 | −1.8 |
| **G: RUNNING → SUCCEEDED** | 8.4 (3.9–14.0) | **3.5** (3.4–3.6) | **−4.9** | −7.6 |
| H: SUCCEEDED → client exits | 3.0 (2.4–11.0) | 2.9 (2.6–3.3) | −0.1 | −0.3 |
| Client start → SUCCEEDED | 64.7 | **51.7** | −13.0 | −10.6 |
| **Client total** | **70.8** (61.1–77.5) | **54.8** (51.5–58.3) | **−16.0** | −11.4 |

- **Every branch run (51.5–58.3 s) beat every master run (61.1–77.5 s).**
- **Two more nodes cost master 9.3 s and the branch 4.7 s,** mostly in provisioning (D grew 7.8 s against 3.8 s). The Ray-side changes matter more as more workers wait on the head.
- **The controller and client gains don't depend on cluster size.** G was 3.4–3.6 s in every branch run. Two master runs exited 8.2 s and 11.0 s after SUCCEEDED (the missed 15 s check); no branch run did. G saved less than on 4 nodes only because master's random wait was shorter in this batch.

## 15. Where phase D goes on 6 nodes, and what to change next

**Breakdown** (`bench_jobs/breakdown_d.py`, from each run's `provision.log` and `spot.start_at`; median of 8 runs per arm, seconds):

| Stage of D | master | **branch** | Branch range |
|---|---|---|---|
| Before the provision log starts | 0.8 | 0.5 | 0.2–1.0 |
| **Create 6 pods, wait until Running** | 6.3 | **6.1** | 5.1–6.6 |
| SSH readiness | 0.3 | 0.3 | |
| `internal_file_mounts` (6 pods) | 1.4 | 1.6 | |
| **`setup_runtime_on_cluster`** | 2.3 | **10.2** | **2.3–12.8** |
| **Ray wait + skylet start** | 16.2 | **3.5** | 3.2–7.9 |
| **Cluster launched → job submitted** | 5.0 | **3.8** | 3.5–5.3 |
| **D** | 32.7 | **26.3** (mean 25.4) | 22.3–28.3 |

The branch cut the Ray wait from 16.2 s to 3.5 s, but runtime setup grew from 2.3 s to 10.2 s. A throwaway 6-node cluster (`sky launch`, torn down afterwards) gave the pod-side detail below.

**Runtime setup waits for the pod's PyPI dry run.**
- `setup_runtime_on_cluster` waits on every pod for `/tmp/ray_skypilot_installation_complete`. The pod writes it after `uv pip install --dry-run 'skypilot[kubernetes,remote]'` (§3.1).
- That dry run resolved 107 packages against PyPI in **1.42 s on the head, 2.30 s on worker1 and 12.39 s on worker2**. Runtime setup took 11.9 s, and worker2's setup log shows it waited 11 s for the marker. The wheel install itself took 0 s on every pod.
- **The dry run finds nothing to install.** All 106 dependencies are already in the image's `skypilot-runtime` venv. It "would install" only `skypilot==0.14.2` from PyPI, which the cluster replaces with its own wheel.
- **The wheel install doesn't need the network** (same pod and wheel, `--dry-run`):

  | How the wheel install resolves | Time |
  |---|---|
  | `--offline`, empty uv cache | **12 ms**; 107 packages resolved, rc 0 |
  | online, empty uv cache | 5.70 s |
  | online, cache warmed by the dry run (today) | 79 ms |

- **Proposal (§9 item 1):** install the wheel with `--offline` first, falling back to the online install if that fails, then drop the dry run and write the marker right after starting Ray.
- **Expected gain:** runtime setup goes back to about 2.4 s, as in the 2 fast runs. Some of that saving is then taken by the Ray wait (7.9 s in those runs), so D drops from 26.3 s to about 22.5 s.

**Pod start re-pulls the image.**
- The template sets `imagePullPolicy: Always` (since #6154, which gives no reason). On kind each pull took 0.4–0.8 s, but kubelet ran them one after another: 2.1–4.0 s including waiting.
- `ray_first_pod_bootstrap_design.md` kept `Always` because "the default image uses a `:latest` tag". It doesn't: the tag is date-stamped (`skypilot:202609010416-ray2.56.1`) and never changes.
- **Test:** 3 fresh 6-node launches with `imagePullPolicy: IfNotPresent` set through `pod_config`. The pods were up in **2.6, 1.6 and 3.1 s**, against 5.1–6.6 s (median 6.1 s).
- **Proposal (§9 item 2):** `IfNotPresent` for SkyPilot's default image; `Always` for user images and mutable tags.

**Skylet start compiles bytecode.**
- `start_skylet_on_head_node` runs `python -m sky.skylet.attempt_skylet`, which starts skylet with `nohup` and returns.
- Importing `sky.skylet.attempt_skylet` runs `sky/__init__.py`, which imports backends, `jobs.client.sdk`, `client.sdk`, `server.requests.payloads` and more. On the probe's head pod:

  | Import | Cold bytecode | Warm |
  |---|---|---|
  | `sky.skylet.attempt_skylet` | 4.5 s | 1.3–1.5 s |
  | `sky.skylet.skylet` | 4.4 s | 1.6 s |

- This explains skylet's 3.4 s on the branch against 1.6 s on master. It overlaps the Ray wait today, so it costs nothing in D yet (§9 item 6).

**Cluster launched → job submitted (3.8 s):** file sync, setup and job submission, each a separate `kubectl exec`. Not broken down further (§9 item 5).

**Taken together, items 1 and 2 would bring D from about 26 s to about 19 s on 6 nodes.** They overlap partly, because pods that start sooner also start Ray sooner, so that figure needs its own A/B.

