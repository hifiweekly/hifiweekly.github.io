# Launch latency report: `ej-prj-i3-2` vs. master

Consolidates `sky-launch/summary.md` and `jobs/report.md` from `bench_results/20261103-i3-2-vs-master-no-tips/`.

## Summary

**`ej-prj-i3-2` cuts `sky launch` by 41% and `sky jobs launch` by 54% against master, with no speedup settings on either side.** All 16 measured runs of each benchmark succeeded, and every branch run beat every master run.

| Benchmark (median, with range) | Master | `ej-prj-i3-2` | Change | p |
|---|---|---|---|---|
| **`sky launch` wall time** | 46.70 s (41.5–56.1) | **27.57 s** (24.8–33.2) | **−19.13 s (−41%)** | 0.0002 |
| **`sky jobs launch` client total** | 74.33 s (72.3–81.7) | **34.17 s** (31.8–36.0) | **−40.16 s (−54%)** | 0.0002 |

**These gaps include the bytecode image, which isn't published.** They measure the whole branch and that image together, so users wouldn't see them today.

## Setup

| | Master | `ej-prj-i3-2` |
|---|---|---|
| **Code** | `796c5bcc8` (the branch's merge-base) | `d771518f1` |
| **Task** | `ej/task_published_ifnotpresent.yaml` | `ej/task_bytecode.yaml` |
| **Image** | Published, `IfNotPresent` | Local bytecode image, `IfNotPresent` |

**Both benchmarks:** one kind node on `kind-skypilot`, a one-line `echo` on 6 nodes, 8 measured runs per side. No `allowed_clouds` or `aws.remote_identity: NO_UPLOAD`. The `aws` CLI was on `PATH`.

| | `sky launch` | `sky jobs launch` |
|---|---|---|
| **Run order** | Launches alternate between the builds, after 1 warm-up | 4 alternating blocks of 1 warm-up and 4 measured runs |
| **Servers** | An isolated API server, venv and worktree per build | The main API server, in consolidation mode, restarted per block |
| **Config** | `kubernetes.allowed_contexts: [kind-skypilot]` only | The user's `~/.sky/config.yaml` |

**p-values** here are exact two-sided permutation tests on means, recomputed from the raw runs. The source reports differ: `summary.md` is one-sided, and `report.md` rounds to 0.0000.

## `sky jobs launch`

### Phases

Medians in seconds, with ranges.

| Phase | Master | `ej-prj-i3-2` | Change | p |
|---|---|---|---|---|
| **A: client start → job row** | 6.97 (6.6–7.2) | **2.14** (1.8–2.3) | **−4.83** | 0.0002 |
| **B: row → STARTING** | 2.69 (2.3–4.8) | **2.14** (1.9–2.7) | **−0.55** | 0.0051 |
| C: STARTING → provisioning | 3.17 (2.9–4.0) | 3.21 (3.1–3.5) | +0.04 | 0.81 |
| **D: provisioning → job submitted** | 32.62 (28.9–39.0) | **14.41** (13.9–15.1) | **−18.21** | 0.0002 |
| **E: job runs** | 8.71 (8.2–9.5) | **6.71** (6.5–6.9) | **−2.00** | 0.0002 |
| **F: job ended → RUNNING** | 2.93 (2.3–3.6) | **2.25** (1.9–2.6) | **−0.68** | 0.0028 |
| **G: RUNNING → SUCCEEDED** | 13.29 (3.7–17.9) | **0.11** (0.1–0.2) | **−13.18** | 0.0002 |
| H: SUCCEEDED → client exits | 4.40 (2.6–11.9) | 2.77 (2.1–4.5) | −1.63 | 0.071 |
| **Client start → SUCCEEDED** | 69.82 (61.0–78.9) | **31.28** (29.7–32.1) | **−38.54** | 0.0002 |
| **Client total** | 74.33 (72.3–81.7) | **34.17** (31.8–36.0) | **−40.16** | 0.0002 |

Phase changes are differences of medians, so they don't add up exactly to the total.

### Phase D stages

Medians in seconds, with ranges.

| Stage | Master | `ej-prj-i3-2` |
|---|---|---|
| 'Provisioning on' event → provision log starts | 0.49 (0.0–0.9) | 0.47 (0.1–0.8) |
| Create pods, wait until Running | 2.90 (1.5–3.1) | 1.85 (1.5–2.2) |
| SSH readiness | 0.24 (0.2–0.4) | 0.32 (0.3–0.4) |
| `internal_file_mounts` | 1.05 (1.0–1.8) | 2.33 (1.4–3.1) |
| **`setup_runtime_on_cluster`** | 12.78 (2.8–14.4) | **1.75** (1.5–3.2) |
| **Ray wait + skylet start** | 14.96 (8.7–17.5) | **4.22** (3.2–4.8) |
| Cluster launched → job submitted | 3.71 (3.5–4.0) | 3.35 (3.2–3.5) |
| Phase D total | 32.62 (28.9–39.0) | 14.41 (13.9–15.1) |
| Skylet start on its own | 1.60 (1.5–1.7) | 2.68 (2.3–2.9) |

### Runs

All 20 launches had `rc` 0 and a clean trace. Warm-ups are excluded from the statistics.

| Block | Side | Warm-up | Run 1 | Run 2 | Run 3 | Run 4 |
|---|---|---|---|---|---|---|
| 1 | Master | 84.8 | 72.7 | 77.6 | 77.0 | 72.3 |
| 2 | `ej-prj-i3-2` | 46.3 | 34.2 | 34.0 | 31.8 | 35.4 |
| 3 | Master | 79.1 | 75.7 | 72.9 | 72.9 | 81.7 |
| 4 | `ej-prj-i3-2` | 46.4 | 34.2 | 34.3 | 36.0 | 33.9 |

Times are client totals in seconds.

## `sky launch`

Medians in seconds, with ranges.

| Metric | Master | `ej-prj-i3-2` | Change | p |
|---|---|---|---|---|
| **Wall time** | 46.70 (41.5–56.1) | **27.57** (24.8–33.2) | **−19.13 (−41%)** | 0.0002 |
| Provision total | 29.69 (23.6–40.3) | 12.99 (10.5–18.5) | −16.70 (−56%) | 0.0002 |
| Runtime installed → cluster launched | 16.24 (9.4–22.7) | 5.24 (2.3–6.5) | −11.00 (−68%) | 0.0002 |
| Runtime setup | 13.37 (5.6–17.2) | 4.83 (4.1–14.5) | −8.54 (−64%) | 0.011 |
| Pods ready | 2.73 (2.7–3.2) | 1.99 (1.7–2.3) | −0.74 (−27%) | 0.0002 |

The benchmark's own checks all passed, and its verdict is **VALID**:

- Each build ran its own commit, seen in the provision logs as `796c5bcc8041` and `d771518f11d2`.
- All launches succeeded and ran on every rank.
- No candidate launch fell back to restarting Ray.
- The candidate never ran the old polling loop.
- The primary metric, runtime installed → cluster launched, was lower with p < 0.05.

## How to read this

- **The storage check reuse shows up in phase A of `sky jobs launch`.** All 8 measured branch runs were 1.8–2.3 s, and none hit an expired record. Launches were about 40 s apart, which is the best case: launches over 10 minutes apart get no saving.
- **That reuse is only part of the gap.** A separate A/B of the patch alone measured 41.31 → 37.06 s (p = 0.013), with phase A at 6.85 → 2.20 s. The rest comes from the earlier `ej-prj-i2-*` branches and the bytecode image.
- **`sky launch` doesn't appear to benefit from the reuse.** From the code, it reaches that check only for tasks with storage mounts (`sky/task.py:1690`), and this task has none.
- **Phase C doesn't improve.** Its `aws configure list` call is a separate path from the storage check. `aws.remote_identity: NO_UPLOAD` removes it, or it costs less if `aws` isn't on the server's `PATH`.
- **The two benchmarks' environments differ.** The `sky launch` venvs have no AWS libraries, so their cloud checks stop earlier than on the main server. Don't compare runtime or wall time directly between them.

## Open questions

- **File mounts are slower on the branch, for a reason not yet found:** 1.05 s vs 2.33 s, with ranges 1.0–1.8 s and 1.4–3.1 s. The `ej-prj-i3-1` comparison showed the same direction (1.76 s vs 2.26 s). No significance test was run on this stage.
- **Skylet start on its own is also slower on the branch:** 1.60 s vs 2.68 s. It runs alongside the Ray wait, so it doesn't set phase D's length, and the cause hasn't been investigated.

## Not covered

- **`ej-prj-i3-1`'s rsync change:** this branch doesn't include it.
- **The patch's 10-minute limit at other launch rates:** only launches about 40 s apart were tested.
- **Current master:** `origin/master` was 2 commits ahead of `796c5bcc8` at last check.

## Files

All under `ej/bench_results/20261103-i3-2-vs-master-no-tips/`:

- **`sky launch`:** `sky-launch/summary.md`, `sky-launch/results.csv`, `sky-launch/logs/`
- **`sky jobs launch`:** `jobs/report.md`, `jobs/summary.json`, one trace per run in `jobs/`
- **How it was run:** `run.sh`, `sky_launch_no_tips.py`, `run.log`
