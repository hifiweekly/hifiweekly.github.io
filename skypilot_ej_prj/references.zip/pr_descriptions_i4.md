# PR descriptions: `ej-prj-i4-1` to `ej-prj-i4-5`

Continues `pr_description_i3.md`, in the same format. One section per branch on `fork` (https://github.com/siliconej/skypilot). Copy everything under a branch's heading into its PR.

**Stacking.** Every `ej-prj-i4-*` branch builds on `ej-prj-i3-2` (`d771518f1`):

```
ej-prj-i3-2 → ej-prj-i4-1 ─┬→ ej-prj-i4-2
                           └→ ej-prj-i4-3 → ej-prj-i4-4 → ej-prj-i4-5
```

- `ej-prj-i4-2` and `ej-prj-i4-3` split from `ej-prj-i4-1` separately.
- `ej-prj-i4-4` is `ej-prj-i4-3` plus `ej-prj-i4-2`'s commit, cherry-picked with a lint fix (`afd94a698` → `d6fa30e94`). **Open the lean launcher PR from `d6fa30e94`, not `afd94a698`.**
- `ej-prj-i4-5` has every change, and adds two commits, so it's two PRs.

Each section describes that branch's new commits, which are the PRs to open. The rest of the branch is covered by the earlier sections and by `pr_description_i3.md`.

| PR | Commit | Branch | Area |
|---|---|---|---|
| Poll for the head node every 0.2 s | `925abd467` | `ej-prj-i4-1` | Ray patches |
| Start skylet without importing `sky` | `d6fa30e94` | `ej-prj-i4-4` (first as `afd94a698` on `ej-prj-i4-2`) | Skylet |
| Install the wheel without the network | `8bfc6e4c6` | `ej-prj-i4-3` | Kubernetes runtime setup |
| Don't start the Ray dashboard | `1266cccd2` | `ej-prj-i4-5` | Ray patches, `ray start` |
| Retry Ray's local connects every 0.2 s | `fa974f21e` | `ej-prj-i4-5` | `ray start` |

**Test environment for every number below:**
- **Cluster:** `kind-skypilot`, one kind node with 12 cores.
- **Task:** a one-line `echo` on 6 nodes, `ej/task_bytecode.yaml` or `ej/task_published_ifnotpresent.yaml`.
- **Images:** the locally built bytecode image with `imagePullPolicy: IfNotPresent`, unless stated.
- **Managed jobs:** consolidation mode (`sky api start --deploy`).
- **A/Bs:** medians. p-values are exact or sampled two-sided permutation tests on means.

**Checks run on `ej-prj-i4-5` (`fa974f21e`), which has every file these PRs change:**
- `yapf --diff` and `isort --check` are clean on the changed Python files.
- Pylint on the changed files under `sky/` rates 10.00/10.
- **mypy has 3 errors beyond master's 2 in `fetch_nebius.py`,** all `Cannot determine type of "SKYPILOT_ENV_VAR_PREFIX"` in `sky/skypilot_config.py`. They come from the lean launcher PR (see its section). A one-line fix is in the working tree, not committed. With it, mypy is back to master's 2.
- `tests/unit_tests/test_sky/provision/`, `tests/unit_tests/test_sky/skylet/` and `test_kubernetes_ray_template_snapshot.py`: 749 passed.

**No smoke tests, backward compatibility tests or full unit suite run is recorded for any of these commits.** The boxes are left unchecked, with suggestions. Every test ran on Kubernetes (kind) only.

---

## `ej-prj-i4-1`: [Core] Poll for the head node every 0.2 s when a worker starts Ray

Commit: `925abd467`. Stacked on `ej-prj-i3-2`.

### Summary

- **Problem:** a worker's `ray start` waits for the head's node record in GCS, and Ray's `get_all_node_info_until_retrieved` sleeps 2 s between checks (`ray/_private/utils.py`). A worker that checks just before the head registers waits up to 2 s more than it needs to.
- **Fix:** a new Ray patch, `utils.py.patch`, sleeps 0.2 s and makes 10x as many attempts, so Ray still gives up after the same time.
  - It's registered in `apply_patches._PATCHES`, so it's applied with the other Ray patches when a pod starts.
  - `utils.py.diff` keeps the readable diff against Ray 2.56.1, as for the other patches.

Files: `sky/skylet/ray_patches/apply_patches.py`, `sky/skylet/ray_patches/utils.py.patch`, `sky/skylet/ray_patches/utils.py.diff`.

### Tested

- [x] Code formatting: `yapf --diff` and `isort --check` are clean on the changed files. Pylint on the changed `sky/` files rates 10.00/10. mypy has no errors beyond master's 2 in `fetch_nebius.py`.
- [x] Any manual or new tests for this PR (please specify below)
  - **Unit tests:** `test_ray_patches_payload.py` checks that every `.patch` file is registered and shipped. No new test file.
  - **A/B on kind** (against `d771518f1`, the commit before, 8 runs per arm, blocks ABCCBA):

    | Measure | Before | After | p |
    |---|---|---|---|
    | **`sky launch` wall time** | 26.81 s (25.5–27.8) | **25.88 s** (24.8–26.3) | 0.0048 |
    | Phase D | 14.68 s | 13.94 s | 0.023 |
    | `sky jobs launch` total | 35.67 s | 33.89 s | 0.18 (not significant) |

    Results: `ej/bench_results/20261104-lean-launcher-ab/`.
  - **Trace:** with the Ray API trace image, workers' `ray start` slept 0.2 s per check, and most found the head on the first or second check.
- [ ] All smoke tests: `/smoke-test` (CI) or `pytest tests/test_smoke.py` (local)
- [ ] Relevant individual tests: `/smoke-test -k test_name` (CI) or `pytest tests/test_smoke.py::test_name` (local)
  - Not run. Suggested: `test_cluster_job.py::test_multi_hostname` and a multi-node launch on a VM cloud.
- [ ] Backward compatibility: `/quicktest-core` (CI) or `pytest tests/smoke_tests/test_backward_compat.py` (local)
  - Not run. Only new pods get the patch.

---

## `ej-prj-i4-2` / `ej-prj-i4-4`: [Core] Start skylet without importing sky

Commit: `d6fa30e94` on `ej-prj-i4-4`, stacked on `ej-prj-i4-3`. The same change is `afd94a698` on `ej-prj-i4-2`, which has an 81-character comment line that `d6fa30e94` fixes.

**Before opening a PR:** commit the mypy fix. `constants.py` re-exports `SKYPILOT_ENV_VAR_PREFIX` from `launch_constants.py`, and mypy can't infer its type through the import cycle, which gives 3 errors in `sky/skypilot_config.py`. Annotating the re-export (`SKYPILOT_ENV_VAR_PREFIX: str = ...`) fixes it, and is in the working tree.

### Summary

- **Problem:**
  - `start_skylet_on_head_node` runs `python -m sky.skylet.attempt_skylet`.
  - `-m` runs `sky/__init__.py` first, which imports most of SkyPilot (about 2,170 modules), so a script that does a few milliseconds of work took 2–3 s.
- **Fix:**
  - **New `sky/skylet/launch_constants.py`** holds the constants `attempt_skylet.py` needs. It imports nothing from `sky`, and `constants.py` re-exports it, so other code is unchanged.
  - **`attempt_skylet.py`** loads `launch_constants.py` by path. It has its own small copies of `get_runtime_dir_path` and `find_free_port`.
  - **`MAYBE_SKYLET_RESTART_CMD`** runs the script by path with `runpy.run_path`, found through `importlib.util.find_spec('sky')`, which doesn't import the package.
  - A cluster with an older wheel runs its older `attempt_skylet.py` the same way.
- **Not a launch speedup by itself:** skylet starts alongside the Ray wait, which took longer, so the launch waited for Ray instead. It counts once Ray starts faster, as with the dashboard PR below.

Files: `sky/skylet/launch_constants.py` (new), `sky/skylet/attempt_skylet.py`, `sky/skylet/constants.py`, `sky/provision/instance_setup.py`, `sky/utils/debug_utils.py` (a docstring), and `tests/unit_tests/test_sky/skylet/test_attempt_skylet.py`.

### Tested

- [x] Code formatting: `yapf --diff` and `isort --check` are clean on the changed files. Pylint on the changed `sky/` files rates 10.00/10.
- [ ] mypy: 3 errors beyond master's 2, fixed by the uncommitted change above.
- [x] Any manual or new tests for this PR (please specify below)
  - **Unit tests:** `test_attempt_skylet.py`, 3 new tests and the existing ones updated, 26 in all, all passing. The new ones cover:
    - the script starts skylet without importing `sky`;
    - the restart command runs the script by path;
    - `launch_constants.py` and `constants.py` agree.
  - **A/B on kind** (`ej-prj-i4-3` against `ej-prj-i4-4`, 16 runs per side):

    | Measure | Before | After | p |
    |---|---|---|---|
    | **Skylet start on its own** | 3.06 s (2.7–3.2) | **0.35 s** (0.2–0.5) | < 0.0001 |
    | Ray wait + skylet start | 4.35 s | 4.31 s | 0.71 |
    | `sky jobs launch` total | 34.43 s | 34.24 s | 0.28 |
    | `sky launch` wall time | 24.60 s | 24.37 s | 0.27 |

    Results: `ej/bench_results/20261105-i4-3-vs-i4-4/`. An earlier A/B on `ej-prj-i4-1` measured 2.92 → 0.25 s (`20261104-lean-launcher-ab/`).
  - **Once the dashboard is gone,** Ray wait + skylet start is 1.06–1.49 s, well under the 3 s skylet took before this change.
- [ ] All smoke tests: `/smoke-test` (CI) or `pytest tests/test_smoke.py` (local)
- [ ] Relevant individual tests: `/smoke-test -k test_name` (CI) or `pytest tests/test_smoke.py::test_name` (local)
  - Not run. Suggested: `test_basic.py::test_minimal`, `test_autostop` (skylet runs autostop), and a skylet restart after a version change.
- [ ] Backward compatibility: `/quicktest-core` (CI) or `pytest tests/smoke_tests/test_backward_compat.py` (local)
  - Not run; recommended, as this changes how the skylet start command finds its script on existing clusters.

---

## `ej-prj-i4-3`: [Kubernetes] Install the SkyPilot wheel without the network when possible

Commit: `8bfc6e4c6`. Stacked on `ej-prj-i4-1`.

### Summary

- **Problem:**
  - Runtime setup waits for every pod. Each pod ran a `uv pip install --dry-run` that sends over 100 requests to PyPI, even when the image already has everything.
  - One request hanging on one pod (uv's connect timeout is 10 s) delayed the launch by about 5–10 s, in a third or more of launches in some sessions. DNS settings didn't fix it.
- **Fix:**
  - **`sky/skylet/constants.py`:** install the wheel with `uv pip install --offline` first. If what's installed and cached can't satisfy it, fall back to the normal install.
  - **`kubernetes-ray.yml.j2`:** skip the dry run, which only warms uv's cache, when the image already has a populated cache (`~/.cache/uv/archive-v0`). Images without a cache behave as before.
- **Shared with other clouds:** the wheel command is used on every cloud, but it has only run on kind, not on real VMs.

Files: `sky/skylet/constants.py`, `sky/templates/kubernetes-ray.yml.j2`, and a new test file.

### Tested

- [x] Code formatting: `yapf --diff` and `isort --check` are clean on the changed files. Pylint on the changed `sky/` files rates 10.00/10. mypy has no errors beyond master's 2 in `fetch_nebius.py`.
- [x] Any manual or new tests for this PR (please specify below)
  - **New unit tests:** `tests/unit_tests/test_sky/skylet/test_wheel_install_offline.py`, 4 tests, three of them against a fake `uv`. They cover:
    - an offline success never uses the network;
    - a failed offline install falls back to the normal install;
    - both failing fails the setup;
    - the template skips the dry run when the uv cache is populated.
  - **Manual:** with a dependency uninstalled in a pod, the offline install failed and the fallback installed it.
  - **A/B on kind** (`ej-prj-i4-1` with and without the change, 8 blocks ABBA, 16 `sky launch` and 8 `sky jobs launch` runs per side):

    | Measure | Without | With | p |
    |---|---|---|---|
    | **`sky launch` runtime setup** | 3.05 s (1.6–12.0) | **1.64 s** (1.5–2.3) | < 0.0001 |
    | **`sky launch` wall time** | 26.58 s | **25.95 s** | 0.0073 |
    | `sky jobs launch` runtime setup | 3.03 s (2.0–11.8) | 1.90 s (1.6–2.3) | 0.0009 |
    | `sky jobs launch` total | 34.00 s | 34.74 s | 0.92 (not significant) |

    Runs with setup over 5 s: 3 of 24 without, 0 of 24 with. Pods ran a dry run on every launch without the change and on none with it. `sky jobs launch` doesn't get faster here, because the launch then waits longer for Ray. Results: `ej/bench_results/20261105-uv-offline/`.
  - **Not tested:** an image without a uv cache, a published image, a VM cloud.
- [ ] All smoke tests: `/smoke-test` (CI) or `pytest tests/test_smoke.py` (local)
- [ ] Relevant individual tests: `/smoke-test -k test_name` (CI) or `pytest tests/test_smoke.py::test_name` (local)
  - Not run. Suggested: `test_basic.py::test_minimal` on Kubernetes and on one VM cloud, and a launch with a custom image that has no uv cache.
- [ ] Backward compatibility: `/quicktest-core` (CI) or `pytest tests/smoke_tests/test_backward_compat.py` (local)
  - Not run; recommended, as the wheel install runs on existing clusters when SkyPilot's version changes.

---

## `ej-prj-i4-5` (1 of 2): [Core] Don't start the Ray dashboard on SkyPilot clusters

Commit: `1266cccd2`. Stacked on `ej-prj-i4-4`.

**Before opening a PR, decide whether users need a way to keep the dashboard.** As written, every SkyPilot cluster loses it, and there's no opt-out. See "What users lose".

### Summary

- **Problem:**
  - SkyPilot doesn't use the Ray dashboard, but it delays every node's raylet.
  - On the head, `ray start` polls every 0.1 s until the dashboard publishes its address, which waits for the dashboard to load its modules. Only then does it start the raylet.
  - On every node, the raylet waits for the dashboard agent, which imports every module under `ray.dashboard.modules`.
  - `--include-dashboard=false` doesn't avoid this: Ray still starts a dashboard process for usage stats, and the wait remains. Tested alone, it saved about 1 s in Ray and nothing in the launch.
- **Fix:** `SKYPILOT_RAY_NO_DASHBOARD=1` on SkyPilot's head and worker `ray start` commands, read by two new Ray patches.
  - **`services.py.patch`:** `start_api_server` returns at once without starting the dashboard, and the dashboard agent starts with `--minimal`.
  - **`agent.py.patch`:** the agent loads no dashboard modules.

Files: `sky/provision/instance_setup.py`, `sky/skylet/ray_patches/apply_patches.py`, and `services.py` and `agent.py` patches (each `.patch` and `.diff`).

### What users lose

- Ray's dashboard UI. `docs/source/reference/architecture/internals.rst:63` lists its port, 8266, and needs updating.
- Ray's metrics export.
- Ray's job and state APIs: `ray job`, `ray list` and `ray summary` on a cluster. SkyPilot doesn't use them, as far as found.

### Tested

- [x] Code formatting: `yapf --diff` and `isort --check` are clean on the changed files. Pylint on the changed `sky/` files rates 10.00/10. mypy has no errors beyond master's 2 in `fetch_nebius.py`.
- [x] Any manual or new tests for this PR (please specify below)
  - **Unit tests:** `test_ray_patches_payload.py` checks that both new patches are registered and shipped. `test_ray_start_env.py`, added in the next PR, checks that both `ray start` commands set `SKYPILOT_RAY_NO_DASHBOARD=1`.
  - **A/B on kind** (`ej-prj-i4-4` with and without the change, 8 blocks ABBAABBA, 16 runs per side):

    | Measure | Dashboard on | Off | Change | p |
    |---|---|---|---|---|
    | **`sky jobs launch` total** | 34.33 s (32.9–39.4) | **30.76 s** (29.8–32.7) | −3.57 s | < 0.0001 |
    | **`sky launch` wall time** | 26.10 s (25.1–27.2) | **22.98 s** (22.1–23.8) | −3.12 s | < 0.0001 |
    | Ray wait + skylet start | 4.25 s | 1.49 s | −2.76 s | < 0.0001 |
    | GCS → head raylet | 2.91 s | 0.46 s | −2.45 s | < 0.0001 |
    | GCS → last worker registered | 5.99 s | 3.38 s | −2.60 s | < 0.0001 |

    Every run with the change beat every run without it, on both benchmarks. A dashboard process ran on every run without the change and on none with it. Results: `ej/bench_results/20261105-no-dashboard-ab/`.
  - **Manual, on kind:** port 8266 closed, and no dashboard process. `ray status`, `sky exec` on 6 nodes, `sky queue` and `sky logs` work, and a job that exits 3 is marked FAILED.
  - **Not tested:** managed job recovery after preemption, VM clouds, and clusters launched before the change.
- [ ] All smoke tests: `/smoke-test` (CI) or `pytest tests/test_smoke.py` (local)
- [ ] Relevant individual tests: `/smoke-test -k test_name` (CI) or `pytest tests/test_smoke.py::test_name` (local)
  - Not run. Suggested: `test_basic.py::test_minimal`, `test_managed_job.py::test_managed_jobs_basic`, `test_managed_jobs_recovery_kubernetes_multinode`, and any test that uses Ray's job API or dashboard.
- [ ] Backward compatibility: `/quicktest-core` (CI) or `pytest tests/smoke_tests/test_backward_compat.py` (local)
  - Not run; recommended. Only new pods get the patches. An existing cluster keeps its dashboard until Ray restarts.

---

## `ej-prj-i4-5` (2 of 2): [Core] Retry Ray's local socket connects every 0.2 s

Commit: `fa974f21e`. Stacked on `1266cccd2`.

### Summary

- **Problem:**
  - Each raylet starts its plasma store on a thread, gives it 500 µs, then connects to the store's socket (`object_manager.cc:57`, `:143`).
  - The store maps 500 MB of shared memory before it binds the socket, so the first connect often fails.
  - Ray then sleeps `raylet_client_connect_timeout_milliseconds`, 1000 ms by default, before retrying (`client_connection.cc:87`).
  - In 6 traced launches, this hit 13 of 36 raylets and was always the last worker to register. With the dashboard, it was hidden behind the agent wait.
- **Fix:** set `RAY_raylet_client_connect_timeout_milliseconds=200` and `RAY_raylet_client_num_connect_attempts=50` on SkyPilot's head and worker `ray start` commands, through one constant, `_RAY_CONNECT_RETRY_ENV`.
  - Ray reads every `RAY_CONFIG` value from `RAY_<name>` (`ray_config.h:74`), and the raylet's worker processes inherit both.
  - The same pair sets how long Ray workers retry connecting to the raylet. 50 attempts keeps Ray's default 10 s before giving up.
  - Ray's own Docker tests set the same pair, to 100 ms (`python/ray/tests/conftest_docker.py:156`).

Files: `sky/provision/instance_setup.py`, and a new test file.

### Tested

- [x] Code formatting: `yapf --diff` and `isort --check` are clean on the changed files. Pylint on the changed `sky/` files rates 10.00/10. mypy has no errors beyond master's 2 in `fetch_nebius.py`.
- [x] Any manual or new tests for this PR (please specify below)
  - **New unit tests:** `tests/unit_tests/test_sky/provision/test_ray_start_env.py`, 4 tests. For the head and worker commands, they check that `ray start` itself gets both settings and `SKYPILOT_RAY_NO_DASHBOARD=1`, and that the time before giving up stays 10 s.
  - **Manual, on kind:** 3 six-node `sky launch` runs.
    - Every raylet had both settings, and its Ray workers inherited them.
    - 6 of 18 raylets lost the race and recovered after 0.17–0.22 s instead of 1.00 s.
    - `sky exec` ran on all 6 ranks, and a job that exits 3 was marked FAILED.
  - **Trace on kind** (6 launches each, from separate sessions; `ej/bench_results/20261105-ray-timeline-v3/` and `-v4/`):

    | Median | 1 s retry | 0.2 s retry |
    |---|---|---|
    | GCS → last worker registered | 3.48 s | 3.02 s |
    | Alive-nodes wait | 1.83 s | 0.50 s |
    | Driver starts at | 16.08 s | 15.99 s |

  - **No launch speedup is measured yet.** Ray is now nearly ready when the provisioner starts waiting for it, so file mounts, runtime setup and SkyPilot's job setup now decide the launch length. Against the previous benchmark of `1266cccd2`, from another session, phase D was 0.66 s shorter (p = 0.032), and the totals didn't change significantly (`sky jobs launch` −0.36 s, p = 0.55). A same-session A/B hasn't been run.
  - **Not tested:** a slow node, where the 10 s limit matters most.
- [ ] All smoke tests: `/smoke-test` (CI) or `pytest tests/test_smoke.py` (local)
- [ ] Relevant individual tests: `/smoke-test -k test_name` (CI) or `pytest tests/test_smoke.py::test_name` (local)
  - Not run. Suggested: `test_basic.py::test_minimal`, `test_cluster_job.py::test_multi_hostname`, and a job that starts many Ray workers at once.
- [ ] Backward compatibility: `/quicktest-core` (CI) or `pytest tests/smoke_tests/test_backward_compat.py` (local)
  - Not run. It applies when Ray next starts, and there's no API change.

### Benchmark against master

`ej-prj-i4-5` (`fa974f21e`, bytecode image) against master `796c5bcc8`, the commit it's based on (published image). Both use `IfNotPresent`, 6 nodes and 8 measured runs per side, with no `allowed_clouds` or `NO_UPLOAD` on either side, and all runs succeeded. This measures every `ej-prj-i2-*`, `-i3-*` and `-i4-*` change and the image together, not one PR. p-values are exact two-sided permutation tests on means.

**`sky launch`:**

| Metric | master | `ej-prj-i4-5` | Change | p |
|---|---|---|---|---|
| **Launch wall time** | 45.67 s (43.3–55.3) | **22.44 s** (20.9–25.2) | **−23.23 s (−51%)** | 0.0002 |
| Provisioning total | 28.66 s (26.5–36.5) | 7.20 s (6.2–7.7) | −21.47 s (−75%) | 0.0002 |
| Runtime setup end → launched | 17.04 s (8.5–19.0) | 1.87 s (0.7–2.6) | −15.17 s (−89%) | 0.0002 |
| Runtime setup | 11.58 s (6.3–19.3) | 3.39 s (3.1–3.9) | −8.20 s (−71%) | 0.0002 |
| Pods ready | 2.74 s (2.5–3.0) | 1.83 s (1.7–2.3) | −0.92 s (−34%) | 0.0002 |

**`sky jobs launch`:**

| Phase | master | `ej-prj-i4-5` | Change | p |
|---|---|---|---|---|
| **A: client start → job row created** | 7.03 (6.4–7.2) | **2.31** (1.8–2.7) | **−4.72** | 0.0002 |
| B: row created → STARTING | 2.81 (2.3–5.5) | 2.37 (1.9–3.7) | −0.44 | 0.090 |
| C: STARTING → provisioning starts | 3.20 (2.5–3.6) | 3.21 (2.4–3.8) | +0.01 | 0.86 |
| **D: provisioning → job submitted** | 33.08 (30.8–42.9) | **10.43** (9.9–11.4) | **−22.64** | 0.0002 |
| E: job runs on the cluster | 8.75 (8.2–10.0) | 6.76 (6.5–6.9) | −1.99 | 0.0002 |
| F: job ended → RUNNING | 2.94 (1.6–3.4) | 2.45 (2.1–2.9) | −0.49 | 0.13 |
| **G: RUNNING → SUCCEEDED** | 12.58 (3.8–20.7) | **0.22** (0.1–1.1) | **−12.36** | 0.0002 |
| H: SUCCEEDED → client exits | 4.76 (2.6–6.0) | 2.78 (2.6–3.9) | −1.98 | 0.027 |
| **Client total** | **74.95** (70.8–83.4) | **30.84** (30.5–32.9) | **−44.11 (−59%)** | 0.0002 |

- **Every `ej-prj-i4-5` launch beat every master launch,** on both benchmarks.
- **Ray wait + skylet start falls from 16.84 s to 1.06 s,** and runtime setup from 7.98 s (2.5–24.3) to 2.00 s (1.8–2.3), with no stalls.
- **Phase C keeps its `aws configure list`.** Only `aws.remote_identity: NO_UPLOAD` removes it.
- **Users won't see all of this yet.** The bytecode image isn't published, and the template still sets `imagePullPolicy: Always`.

Results: `ej/bench_results/20261105-i4-5b-vs-master/` (`sky-launch/summary.md`, `jobs/report.md`, `stats_two_sided.txt`). Consolidated: `ej/report_i4_5b_vs_master.md`.
