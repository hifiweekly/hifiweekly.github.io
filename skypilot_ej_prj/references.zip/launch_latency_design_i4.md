# Design: launch latency changes in `ej-prj-i4-*`

This doc continues `launch_latency_design_after_job2.md` and `empty_storage_check_reuse_design.md`, which stop at `ej-prj-i3-2`. It covers the five changes in the `ej-prj-i4-*` branches, all of which act while a cluster is provisioned.

| # | Commit | Change | Layer | First in |
|---|---|---|---|---|
| 1 | `925abd467` | Poll for the head node every 0.2 s | Ray patch | `ej-prj-i4-1` |
| 2 | `d6fa30e94` | Start skylet without importing `sky` | Skylet | `ej-prj-i4-2` (`afd94a698`), `ej-prj-i4-4` |
| 3 | `8bfc6e4c6` | Install the SkyPilot wheel without the network | Pod setup | `ej-prj-i4-3` |
| 4 | `1266cccd2` | Don't start the Ray dashboard | Ray patches, `ray start` | `ej-prj-i4-5` |
| 5 | `fa974f21e` | Retry Ray's local socket connects every 0.2 s | `ray start` | `ej-prj-i4-5` |

**Branch state:**
- Every `ej-prj-i4-*` branch is pushed to `fork`. `ej-prj-i4-5` (`fa974f21e`) contains all five changes, on top of `ej-prj-i3-2` and master `796c5bcc8`.
- A one-line mypy fix for change 2 is in the working tree and not committed (§6).
- Nothing here is merged, and the bytecode image the benchmarks use isn't published.

Ray file and line references are to Ray 2.56.1, the version SkyPilot pins (`sky/skylet/constants.py:58`).

## 1. Summary

With all five changes, a 6-node launch on kind drops against master `796c5bcc8`:

```
┌──────────────────────────────────┬─────────────────────┬─────────────────────┬─────────────────┬────────┐
│ Median (range)                   │ Master              │ ej-prj-i4-5         │ Change          │ p      │
├──────────────────────────────────┼─────────────────────┼─────────────────────┼─────────────────┼────────┤
│ sky launch wall time             │ 45.67 s (43.3–55.3) │ 22.44 s (20.9–25.2) │ −23.23 s (−51%) │ 0.0002 │
│ sky jobs launch client total     │ 74.95 s (70.8–83.4) │ 30.84 s (30.5–32.9) │ −44.11 s (−59%) │ 0.0002 │
│ Phase D: provisioning → submit   │ 33.08 s             │ 10.43 s             │ −22.64 s        │ 0.0002 │
│   Ray wait + skylet start        │ 16.84 s             │  1.06 s             │ −15.78 s        │ 0.0002 │
│   Runtime setup                  │  7.98 s (2.5–24.3)  │  2.00 s (1.8–2.3)   │  −5.99 s        │ 0.0002 │
└──────────────────────────────────┴─────────────────────┴─────────────────────┴─────────────────┴────────┘
```

That comparison includes every change since master (the `ej-prj-i2-*` and `ej-prj-i3-*` work too) and the bytecode image. Against `ej-prj-i3-2`, the `ej-prj-i4-*` changes take `sky jobs launch` from about 34 s to about 31 s and `sky launch` from about 27 s to about 22.5 s.

- **The Ray wait is nearly gone.** Ray wait + skylet start was 4.2 s on `ej-prj-i3-2` and is 1.1 s now. Most of that comes from not starting the Ray dashboard (change 4), which every node's raylet waited for.
- **Runtime setup no longer stalls.** Pods install the wheel offline (change 3), so a slow PyPI request on one pod no longer delays the launch by 5–10 s.
- **Two changes only count together with others.** The lean skylet launcher (change 2) saves 2.7 s of skylet time, but the launch waited for Ray until change 4. The connect retry (change 5) makes Ray ready 0.46 s sooner, but Ray now finishes about when the provisioner starts waiting for it.
- **What sets the launch now is SkyPilot's own work** (§9): file mounts and runtime setup before the Ray wait, and job setup after it.
- **The cost:** Ray's dashboard, metrics export and Ray job and state APIs are gone on SkyPilot clusters (§7).

## 2. Starting point

On `ej-prj-i3-2`, phase D of a 6-node `sky jobs launch` was about 14.4 s, of which Ray wait + skylet start was 4.2 s. A trace of Ray's startup (`ray_api_trace_report.md`, `sky_ray_time_workflow_i4_1_v2.svg`) showed where that went:

| Where | What | Time |
|---|---|---|
| Head, `ray start` | Python start and imports of the Ray CLI, then GCS (about 30 ms) | about 1.1 s |
| Head, `ray start` | Polling every 0.1 s until the dashboard publishes its address | 2.4–2.6 s |
| Head and workers, raylet | Waiting for the dashboard agent, which imports every dashboard module | about 1 s |
| Workers, `ray start` | Sleeping 2 s between checks for the head's node record | 0–2 s |
| Provisioner, skylet start | `python -m sky.skylet.attempt_skylet`, which runs `sky/__init__.py` | 2.6–3.0 s |
| Provisioner, runtime setup | Each pod's `uv pip install --dry-run`, over 100 PyPI requests | 1.6–24 s |

Two things that looked like candidates weren't:
- **The raylet's wait for the agents has no sleep to shorten.** It polls the agents' port file every 50 ms in C++ (`port_persistence.h`). In 6 traced launches, no agent slept before writing its port. The time is the agents starting up.
- **The worker's read of the session name never blocked.** Workers don't wait for the dashboard's address either: they wait for the head's node record, which the head registers only after the dashboard wait.

## 3. Design

### 3.1 Change 1: poll for the head node every 0.2 s

**Mechanism.** A worker's `ray start` reads the head's node record from GCS before it starts its raylet (`ray/_private/node.py:270`). `get_all_node_info_until_retrieved` sleeps 2 s between attempts (`ray/_private/utils.py:1260`). A worker that checks just before the head registers waits up to 2 s longer than it needs to.

**Design.** A new Ray patch, `sky/skylet/ray_patches/utils.py.patch`, changes the sleep to 0.2 s and the attempts to `num_retries * 10`, so the time before Ray gives up is unchanged. It's registered in `apply_patches._PATCHES`, so it's applied with the other Ray patches when a pod starts.

**Why a patch.** The sleep and attempt count are literals in Python, not Ray settings.

### 3.2 Change 2: start skylet without importing `sky`

**Mechanism.** `start_skylet_on_head_node` runs `MAYBE_SKYLET_RESTART_CMD`, which was `python -m sky.skylet.attempt_skylet`. `-m` runs `sky/__init__.py` first, which imports about 2,170 modules and takes 2–3 s on a pod. `attempt_skylet.py` itself does a few milliseconds of work: it checks whether skylet is running at the right version and starts it if not.

**Design.**
- **`sky/skylet/launch_constants.py` (new)** holds the constants `attempt_skylet.py` needs: the runtime directory, the Python and Ray command paths, and the environment variable prefix. It imports nothing from `sky`. `constants.py` re-exports each one, so no other code changes.
- **`attempt_skylet.py`** loads `launch_constants.py` by file path, and has its own small copies of `get_runtime_dir_path` and `find_free_port`.
- **`MAYBE_SKYLET_RESTART_CMD`** runs the script by path with `runpy.run_path`, found through `importlib.util.find_spec('sky')`, which locates a top-level package without running it. A cluster with an older wheel runs its older script the same way.

**Rejected:** stubbing `sky/__init__.py` so that `-m` imports less. A test of this failed on a circular import through `sky/exceptions.py` → `sky.backends`, and any stub would have to track `__init__.py`.

### 3.3 Change 3: install the SkyPilot wheel without the network

**Mechanism.** Runtime setup waits for every pod. Each pod ran `uv pip install --dry-run 'skypilot[kubernetes,remote]'` to warm uv's cache, then installed the wheel. The dry run sent over 100 revalidation requests to PyPI, even when the image already had everything. One request hanging until uv's 10 s connect timeout, on any pod, delayed the launch. This happened in about a third of launches in some sessions. Changing DNS settings and resetting the DNS server didn't fix it.

**Design.**
- **`sky/skylet/constants.py`:** install the wheel with `uv pip install --offline` first, and fall back to the normal install if what's installed and cached can't satisfy it.
- **`kubernetes-ray.yml.j2`:** run the dry run only when the image has no uv cache (`~/.cache/uv/archive-v0` empty). Images without a cache behave as before.

**Scope.** The wheel command is shared by every cloud, but the dry run skip is Kubernetes only. Neither has run on a VM cloud.

### 3.4 Change 4: don't start the Ray dashboard

**Mechanism.** On the head, `ray start` starts the dashboard, then polls every 0.1 s (`ray/_private/services.py:1422`) until the dashboard publishes its address (`ray/dashboard/head.py:487`). That happens after the dashboard loads its modules and starts its subprocess modules. Only then does `ray start` start the raylet. On every node, the raylet's `NodeManager` blocks until the dashboard agent and the runtime env agent write their ports (`node_manager.cc:286-287`). The dashboard agent imports every module under `ray.dashboard.modules` first.

The worker raylets wait for the head too, indirectly: a worker's `ray start` waits for the head's node record (§3.1), which comes after the head's dashboard wait.

**Design.** SkyPilot's head and worker `ray start` commands set `SKYPILOT_RAY_NO_DASHBOARD=1`, which two new Ray patches read:
- **`services.py.patch`:** `start_api_server` returns `None, None` at once, without starting the dashboard. `start_raylet` starts the dashboard agent with `--minimal`.
- **`agent.py.patch`:** the agent loads no modules.

The raylet still starts both agents, so its wait is the agents' Python start and imports, about 0.6–0.7 s each.

**Rejected:**
- **`--include-dashboard=false`:** Ray still starts a dashboard process for usage stats (`--modules-to-load=UsageStatsHead --disable-frontend`), and the poll still runs. Tested alone, it saved about 1 s in Ray and nothing in the launch.
- **`--minimal` alone:** the agent still walks the dashboard modules.
- **Making the raylet not wait for the agents:** that's in C++, and the agents run in parallel, so it would save at most about 0.7 s.

**No opt-out.** The variable is set in SkyPilot's commands, so a user can't keep the dashboard. Adding a config option for it is open (§9).

### 3.5 Change 5: retry Ray's local socket connects every 0.2 s

**Mechanism.** Each raylet starts its plasma store on its own thread (`object_manager.cc:49`) and gives it 500 µs (`:57`). The main thread then builds the `ObjectManager`, which connects to the store's socket (`:143`). The store thread first maps 500 MB of shared memory (`store_runner.cc:109`) and only then binds the socket (`store.cc:80`), so the connect often comes first and fails. `ConnectSocketRetry` then sleeps `raylet_client_connect_timeout_milliseconds`, 1000 ms by default, before retrying (`client_connection.cc:87`). Ray logs nothing for the first failure, but `raylet.out` shows an exact 1.00 s gap between "Starting object store" and "ObjectManager server started".

In 6 traced launches, this hit 13 of 36 raylets, and the last worker to register was always one of them. With the dashboard on, the agent wait hid it (9 of 36 raylets in an earlier trace).

**Design.** One constant, `_RAY_CONNECT_RETRY_ENV` in `sky/provision/instance_setup.py`, added to the head and worker `ray start` commands:

```
RAY_raylet_client_connect_timeout_milliseconds=200 RAY_raylet_client_num_connect_attempts=50
```

- Ray reads every `RAY_CONFIG` value from the environment variable `RAY_<name>` when the process starts (`ray_config.h:74`). `ray start` passes its environment to the raylet, and the raylet to its Ray workers.
- **Why the attempt count too.** The plasma connect passes no attempt count (`client.cc:663` ignores the 300 that `Connect` receives), so it uses the default of 10. Ray workers connecting to the raylet use the same pair (`raylet_ipc_client.cc:83`, `core_worker_process.cc:929, 957`). With 200 ms alone, they'd give up after about 2 s instead of 10. 50 attempts keeps 10 s.
- Ray's own Docker tests set the same pair, to 100 ms (`python/ray/tests/conftest_docker.py:156`).

**Rejected:**
- **`--system-config` on the head:** it sends settings to all nodes through GCS, but it's head-only and it hasn't been checked whether a worker's raylet reads it before the plasma connect.
- **A C++ fix** (wait until the store listens): the right fix, but SkyPilot's patches only change Ray's Python files.

## 4. Which phase each change affects

All five act in phase D of `sky jobs launch` (provisioning → job submitted), and in the provisioning part of `sky launch`.

| Change | Stage of phase D | Head or workers |
|---|---|---|
| 1. Head-node poll | Ray wait | Workers |
| 2. Lean skylet launcher | Skylet start, alongside the Ray wait | Head |
| 3. Offline wheel install | `setup_runtime_on_cluster` | All pods |
| 4. No dashboard | Ray wait | Head and workers |
| 5. Connect retry | Ray wait | All raylets |

**The Ray wait and skylet start run together** (`_run_alongside` in `provisioner.py`), so the stage takes the longer of the two. That's why change 2 didn't help until change 4 made Ray's part shorter than skylet's old 3 s.

## 5. Failure handling

| Change | If it doesn't apply | Effect |
|---|---|---|
| 1 | The patch fails to apply | `apply_patches.py` fails the pod's setup, as for the other Ray patches |
| 2 | `find_spec('sky')` finds nothing | The skylet start command fails, as `-m` would on a missing package |
| 3 | The offline install can't resolve | Falls back to the normal install; if that fails too, setup fails as before |
| 3 | The image has no uv cache | Runs the dry run, as before |
| 4 | The variable isn't set (another tool's `ray start`) | Ray starts the dashboard as normal |
| 5 | The race is lost every time on a slow node | Ray retries for about 10 s, as before, then fails the raylet |

## 6. Compatibility

- **Existing clusters:** changes 1, 4 and 5 apply only when Ray starts on a pod with the new patches and commands. An existing cluster keeps its dashboard until Ray restarts.
- **Older wheels:** change 2's command runs whatever `attempt_skylet.py` the cluster's wheel has, by path, so an older wheel still works.
- **Other clouds:** changes 1, 2, 4 and 5 are in the shared `ray start` and skylet commands, and change 3's wheel command is shared too. None has run on a VM cloud.
- **API:** no API, schema or skylet version change.
- **mypy:** change 2 adds 3 errors, all `Cannot determine type of "SKYPILOT_ENV_VAR_PREFIX"` in `sky/skypilot_config.py`. mypy can't infer the re-export's type through the import cycle. Annotating it in `constants.py` (`SKYPILOT_ENV_VAR_PREFIX: str = ...`) fixes it, and is in the working tree.

## 7. Risks

- **Lost Ray features (change 4):** Ray's dashboard UI (port 8266, which `docs/source/reference/architecture/internals.rst:63` mentions), metrics export, and Ray's job and state APIs (`ray job`, `ray list`, `ray summary`). SkyPilot doesn't use them, as far as found. Users who port-forward to the dashboard lose it, with no opt-out.
- **Ray upgrades (changes 1 and 4):** the patches are diffs against Ray 2.56.1's files and need rechecking on each Ray upgrade.
- **Slow nodes (change 5):** the time before Ray gives up stays about 10 s, but the attempts are 5 times as frequent.
- **Offline install (change 3):** if the offline install succeeds with an older cached dependency than the network install would pick, the pod could get different versions. The fallback only covers an install that fails.
- **Lean launcher (change 2):** `launch_constants.py` must keep matching `constants.py`. A unit test checks this.

## 8. Results

All on one kind node with 12 cores, a one-line `echo` on 6 nodes, the bytecode image with `IfNotPresent`, and managed jobs in consolidation mode. p-values are two-sided permutation tests on means.

### 8.1 Each change

| Change | A/B | Measure | Before | After | p |
|---|---|---|---|---|---|
| 1 | `d771518f1` vs `925abd467`, 8 runs per arm | `sky launch` wall time | 26.81 s | 25.88 s | 0.0048 |
| | | `sky jobs launch` total | 35.67 s | 33.89 s | 0.18 |
| 2 | `ej-prj-i4-3` vs `-i4-4`, 16 per side | Skylet start on its own | 3.06 s | 0.35 s | < 0.0001 |
| | | `sky jobs launch` total | 34.43 s | 34.24 s | 0.28 |
| 3 | `925abd467` without vs with, 16 / 8 per side | `sky launch` runtime setup | 3.05 s (1.6–12.0) | 1.64 s (1.5–2.3) | < 0.0001 |
| | | `sky launch` wall time | 26.58 s | 25.95 s | 0.0073 |
| | | Setup over 5 s | 3 of 24 runs | 0 of 24 | |
| 4 | `d6fa30e94` without vs with, 16 per side | `sky jobs launch` total | 34.33 s | 30.76 s | < 0.0001 |
| | | `sky launch` wall time | 26.10 s | 22.98 s | < 0.0001 |
| | | GCS → last worker registered | 5.99 s | 3.38 s | < 0.0001 |
| 5 | Traces, 6 launches each, separate sessions | GCS → last worker registered | 3.48 s | 3.02 s | not tested |
| | | Alive-nodes wait | 1.83 s | 0.50 s | not tested |
| | Master benchmarks, branch sides, separate sessions | Phase D | 11.10 s | 10.43 s | 0.032 |
| | | `sky jobs launch` total | 31.20 s | 30.84 s | 0.55 |

Results: `bench_results/20261104-lean-launcher-ab/`, `20261105-i4-3-vs-i4-4/`, `20261105-uv-offline/`, `20261105-no-dashboard-ab/`, `20261105-ray-timeline-v3/` and `-v4/`, `20261105-i4-5-vs-master/` and `20261105-i4-5b-vs-master/`.

**Change 5 has no same-session A/B.** Its mechanism is confirmed (6 of 18 raylets lost the race and recovered after 0.17–0.22 s instead of 1.00 s, in `20261105-plasma-retry-check/`), but its effect on launch totals isn't measured.

### 8.2 All changes against master

The table in §1. Full report: `report_i4_5b_vs_master.md`. Every branch run beat every master run, on both benchmarks.

### 8.3 Where the time goes now

From the v4 trace (`sky_ray_time_workflow_i4_5_v4.svg`), one `sky launch` of 23.5 s:

| Seconds | What |
|---|---|
| 0 – 8 | Client, optimizer, pod creation, SSH (not covered by these changes) |
| 8.1 – 11.6 | File mounts (1.2 s) and runtime setup (2.4 s) |
| 9.1 – 12.0 | Ray: head GCS at 9.1 s, last worker registered at 12.0 s |
| 11.9 – 12.4 | Alive-nodes wait (0.5 s) |
| 12.4 – 15.9 | SkyPilot's job setup on the head (3.5 s) |
| 15.9 – 21.3 | Driver: imports (1.35 s), placement group and Ray workers (1.1 s), tasks (1.9 s), exit (1.1 s) |

Ray now finishes starting at about the time the provisioner starts waiting for it.

### 8.4 Tests

- **New unit tests:** `test_wheel_install_offline.py` (4), `test_ray_start_env.py` (4), and 3 new tests in `test_attempt_skylet.py`. `test_ray_patches_payload.py` checks that every patch is registered and shipped.
- **On `fa974f21e`:** `tests/unit_tests/test_sky/provision/`, `tests/unit_tests/test_sky/skylet/` and `test_kubernetes_ray_template_snapshot.py`, 749 passed. yapf and isort are clean, pylint rates the changed files 10/10, and mypy has the 3 errors in §6.
- **Manual, on kind:** with changes 4 and 5, no dashboard ran and port 8266 was closed. `ray status`, `sky exec` on 6 nodes, `sky queue` and `sky logs` worked, and a job that exits 3 was marked FAILED.
- **Not run:** smoke tests, backward compatibility tests, the full unit suite, VM clouds, managed job recovery after preemption.

## 9. Remaining work, by expected gain

| Item | Where | Expected gain | Notes |
|---|---|---|---|
| SkyPilot's job setup on the head | `_add_job` and the queue-job command, `cloud_vm_ray_backend.py` | Up to about 2.5 s | Two `python -c` commands on the head, each about 1.2 s, mostly `import sky`. The lean launcher approach (change 2) could apply. |
| Driver imports | `task_codegen.py`, `from sky.skylet import job_lib` | Up to about 1 s | The driver uses five SkyPilot modules but imports the whole backend through `sky/__init__.py`. |
| File mounts and runtime setup | `provisioner.py` | Unknown | Now ahead of the Ray wait. File mounts 1.2 s, runtime setup 1.6–2.4 s. |
| A same-session A/B of change 5 | | Measures 0–0.8 s | Settles whether it reaches the totals. |
| Dashboard opt-out | `instance_setup.py` | None | A config option for users who need Ray's dashboard. |
| Runtime env agent start | Ray | Up to about 0.7 s | The raylet waits for it; it's Python start and imports. |
| Phase C's `aws configure list` | | About 2.4 s with `aws` on `PATH` | Separate from these changes. `aws.remote_identity: NO_UPLOAD` removes it. |
| Publish the bytecode image | `Dockerfile_k8s` | Needed for users to see any of this | The benchmarks use a local image. |

## 10. Reproducing

See `README_i4.md`. In short: build and load the bytecode image, then run `bench_results/20261105-i4-5b-vs-master/run.sh` for both benchmarks against master. For one change, compare it with the commit before it, using the bytecode image in both arms. To trace Ray's startup, use the trace image and `bench_results/20261105-ray-timeline-v4/collect.sh`.

**Other docs:**
- `pr_description_i4.md`: PR text for each change.
- `report_i4_5b_vs_master.md`: the latest full benchmark against master.
- `ray_api_trace_report.md`: how Ray starts up, traced.
- `sky_ray_time_workflow_i4_5_v3.svg` and `_v4.svg`: Ray's startup timeline before and after change 5.
