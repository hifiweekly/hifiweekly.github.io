# Design: launch latency changes after `ej-prj-3-job2`

This doc continues `launch_latency_consolidated_design.md`, which stops at `ej-prj-3-job1`. It covers the changes made since, and §11 lists what that doc now gets wrong.

| # | Commit on `ej-prj-i2-6` | Change | Layer | Introduced in |
|---|---|---|---|---|
| 1 | `0c576e860` | Precompile runtime bytecode in the k8s images | Image | `ej-prj-i2-1` |
| 2 | `1ddcc3240` | Don't import Ray Serve in `ray start` | Ray patches | `ej-prj-i2-3` |
| 3 | `71b3c9213` | Watch pods between polls while waiting for them to run | Provisioner | `ej-prj-i2-3` |
| 4 | `30890119e` | Keep job timestamps exact over gRPC (a bug fix, not a speedup) | Skylet, controller | `ej-prj-i2-2` |
| 5 | `7db718aa0` | Get a finished job's end time with its status | Controller, client follower | `ej-prj-i2-4` |
| 6 | `680e03581` | Check for a finished job's saved logs every 0.2 s | Client follower | `ej-prj-i2-6` |
| 7 | `d080ff076` | Get a finished job's log directory with its status | Controller, backend | `ej-prj-i2-6` |

`7e488f558` also adds `--candidate-task` to the launch benchmark, so a candidate can use its own image.

**Branch state:**
- `ej-prj-i2-5` is pushed to the fork at `7e488f558` and contains changes 1–5.
- `ej-prj-i2-6` is pushed to the fork at `d080ff076` and adds changes 6 and 7. It's based on `origin/master` at `796c5bcc8`.
- Nothing here is merged, and no published image has changed.

**`ej-prj-3-job2` itself is not in this line.** Its one latency change (`b6c41f82e`, offline wheel install first, with the uv dry run moved to the background) showed no gain, so `ej-prj-i2-1` was built on `ej-prj-3-job1` instead (§8.1). The current template still runs the dry run before writing the install marker.

## 1. Summary

With all the changes through `ej-prj-i2-5`, a 6-node `sky jobs launch` on kind drops **from 69.9 s to 41.1 s (−28.8 s)** against the fork point `5ef55efa4`, and every candidate run beat every base run. Changes 6 and 7 then cut the wait after SUCCEEDED **from 4.3 s to 2.6 s** (p = 0.0002). Client total went from 41.3 s to 40.0 s, which isn't significant (p = 0.19).

- **Provisioning is where most of it comes from.** Phase D halves, from 29.6 s to 14.7 s. It's mainly the bytecode image and the fixes before it.
- **The controller no longer sits on a finished job.** RUNNING → SUCCEEDED falls from a random 8–15 s to about 0.1 s.
- **Users don't get the full gain yet.** These runs use a locally built bytecode image and `imagePullPolicy: IfNotPresent` set in the task. The template still sets `Always`, and the image isn't published.
- **Phase A swings between about 3 s and about 7 s for a reason not yet found** (§8.4). Compare arms within one run, not across runs.

## 2. Starting point

These were the next steps in the consolidated doc's §9 and §15, and what happened to each:

| Item in that doc | Outcome |
|---|---|
| Item 1: offline wheel, drop the dry run | Tried in `ej-prj-3-job2`: no gain (§8.1). Not in the current line. |
| Item 2: `IfNotPresent` for the default image | Not in the template. Benchmarks set it in the task. |
| Item 3: cache the first storage check | Not done. |
| Item 4: steady RUNNING → SUCCEEDED | **Done** by change 5. |
| Item 5: launched → job submitted | Not done. Still about 3.3 s. |
| Item 6: skylet start imports less | Not done. |
| Item 7: Ray patches in the image | Not done. |
| Item 8: publish the rebuilt image | Not done. |

The bytecode and Ray Serve work came from a new finding: a timestamped trace showed that importing Ray took most of the time before GCS started, so it delayed every worker (`precompile_runtime_bytecode_design.md` §2).

## 3. Design

### 3.1 Change 1: precompile bytecode in the image

Full design: `precompile_runtime_bytecode_design.md`.

**Problem.** `uv` doesn't compile bytecode by default, so every pod compiled Ray and its dependencies on first import.

**Fix.** Add `--compile-bytecode` to the runtime install in `Dockerfile_k8s` and `Dockerfile_k8s_gpu`.

**Cost.** The image grows from 1.67 GB to 1.83 GB. The build compiles 10,736 files in 2.60 s.

**What stays uncompiled:** the Ray files that `apply_patches.py` changes, and the SkyPilot wheel installed at pod start.

### 3.2 Change 2: lazy Ray Serve import

**Where:** `sky/skylet/ray_patches/scripts.py.diff` and `scripts.py.patch`, `apply_patches.py`.

**Problem.** `ray start` imported `ray.serve.scripts` only to register the `ray serve` command, which pulled in pandas and FastAPI on every pod, before GCS started.

**Fix.**
- A patch to Ray's `scripts.py` registers a `_LazyServeCli` group, which imports Serve only when `ray serve` is used.
- `apply_patches.py` used to import each module to find its file, which would have imported Serve just to patch the file that avoids it. It now uses `importlib.util.find_spec`, which doesn't run the module.

### 3.3 Change 3: watch pods between polls

**Where:** `_wait_for_pods_to_run` in `sky/provision/kubernetes/instance.py`.

**Problem.** The wait slept 1 s between polls, so a launch noticed its last pod about 0.5 s late on average.

**Fix.** The sleep is replaced by a wait that ends early when every waiting pod is running or a pod is going away.
- **The poll still decides.** The watch only ends the wait; the poll that follows makes every decision, so failure handling is unchanged.
- **A watch failure falls back** to sleeping out the rest of the interval.

### 3.4 Change 4: exact job timestamps over gRPC

**Where:** `sky/schemas/proto/jobsv1.proto`, `sky/skylet/services.py`, `sky/jobs/utils.py`, `SKYLET_VERSION` 44.

**Problem.** `GetJobSubmittedTimestamp` and `GetJobEndedTimestamp` returned a protobuf float, which holds a current Unix time only to the nearest 128 s. With `SKYPILOT_ENABLE_GRPC` on, a managed job's times were off by up to about a minute, and a short job's duration was recorded as 0 s.

**Fix.** Add an optional `timestamp_double` to both responses, and keep setting the float for older clients. When a skylet doesn't set the new field, the client reads the exact value through the existing head command.

gRPC is off by default, so this doesn't affect any benchmark in this doc.

### 3.5 Change 5: end time with the status

**Where:** `sky/jobs/controller.py`, `recovery_strategy.py`, `utils.py`, `sky/skylet/job_lib.py`.

**Problem.** After a job ended, the controller ran two head commands (status, then end time), and the log follower ran its own status check. Without gRPC, each is a `kubectl exec` of about 1.6 s.

**Fix.**
- The combined head command (`get_job_status_and_timestamps`) also returns the end time.
- A launch that saw the job succeed hands its status and end time to the monitor loop, which then needs no head command.
- The monitor loop's status check also returns the end time, so a finished job doesn't fetch it separately.
- The follower trusts a tail exit code of SUCCEEDED, and reads the recorded status every 0.2 s until the controller writes it.

**Side effect.** Phase H grew from 2.48 s to 3.84 s, because the controller saves the logs after SUCCEEDED, and the client now reaches that wait sooner. Changes 6 and 7 address this.

### 3.6 Changes 6 and 7: shorten the wait for saved logs

A wait trace of `ej-prj-i2-5` showed where phase H's 3.9 s went:

| Step in H | Time | Source |
|---|---|---|
| Client polling for the saved logs (1 s sleeps) | 2.00 s | Traced; overlaps the two rows below |
| Controller's head command to find the log directory | 1.54 s | Traced |
| Copying the logs | about 0.71 s | Inferred, not traced directly |

**Change 6: poll every 0.2 s.** `_wait_for_persisted_task_logs` used `time.sleep(1)`, and now uses `_PERSISTED_LOG_POLL_SECONDS = 0.2`. It still gives up after 30 s.

The cost is more reads of the jobs database, bounded by that 30 s limit, and only for a client following a job that finished without it seeing RUNNING, or for `sky jobs logs` on a task whose logs aren't saved yet.

**Change 7: no separate lookup.**
- The combined head command prints the job's log directory as a fourth payload. It resolves the job ID once, so all the payloads describe the same job.
- A new `EndedJob(ended_at, log_dirs)` tuple carries the end time and directory from the status check to the controller. It replaces the plain end time, and it's `None` until the job is terminal.
- `download_log_and_stream`, `download_and_stream_job_log` and `sync_down_logs` gain an optional `job_log_dirs`. When it's set, `sync_down_logs` skips the lookup.
- Renamed: `get_job_status_and_ended_at` → `get_job_status_and_ended_job`; `pop_job_ended_at_seen_at_launch` → `pop_ended_job_seen_at_launch`.

**The lookup stays** over gRPC (a cheap call), with a registered runtime, when the status check returned no directory, and on the cancelled-job and job-group download paths.

## 4. Which phase each change affects

| Phase | Changed by |
|---|---|
| Pod start → GCS, and workers joining | 1, 2 |
| Pods running → noticed | 3 |
| Job ended → SUCCEEDED (G) | 5 |
| SUCCEEDED → client exits (H) | 5 (worse), 6, 7 |
| Recorded job times with gRPC on | 4 |

**Interactions:**
- **Changes 1 and 2 both shrink the time before GCS,** so their gains overlap and shouldn't be added.
- **Change 5 moved time rather than removing all of it.** G fell by 3.2 s while H rose by 1.4 s, because the client was already waiting on the same log save.
- **Changes 6 and 7 were measured together.** I can't split the 1.7 s between them.

## 5. Failure handling

| Situation | Behaviour |
|---|---|
| The pod watch fails | Sleeps out the interval; the next poll decides. |
| A pod is deleted during the wait | The watch ends early, and the poll handles it. |
| `ray serve` is used on a patched cluster | Serve is imported on demand. `--help`, subcommands, an unknown subcommand's error and `ray serve status` were checked on Ray 2.56.1. |
| A skylet doesn't return `timestamp_double` | The exact value is read through the head command. |
| A cluster has no jobs | The log directory payload is empty, and the status check still succeeds. |
| The status check returns no end time or directory | The controller falls back to `try_to_get_job_end_time` and the lookup in `sync_down_logs`. |
| The job ends just after its status is read | The status isn't terminal, so the rest is dropped and the next check gets it. |
| The logs are never saved | The client's wait gives up after 30 s and the tail ends with no warning, as before. |
| A launch is recovered | What the earlier launch saw is cleared at the start of each wait, so it can't reach the new one. |

## 6. Compatibility

- **API, client and server:** no `API_VERSION` bump.
- **Skylet:** change 4 adds optional proto fields and bumps `SKYLET_VERSION` to 44, so existing clusters restart skylet to pick it up. Older clients keep reading the float. The consolidated doc's "everything is server-side or in the startup script" no longer holds.
- **Older cluster runtimes:** the combined head command calls only functions the earlier commands call, and uses the same `hasattr` fallback as `get_log_dirs_for_jobs`. This wasn't run against an actual older runtime.
- **Custom images:** they don't get the bytecode, as change 1 is in SkyPilot's Dockerfiles. Change 2 applies wherever the Ray patch applies.
- **`sync_down_logs`:** the new argument is optional, so other callers are unaffected.

## 7. Risks

- **Image size.** The image is 160 MB larger, and no run paid for a cold pull of it.
- **The Ray patch needs maintaining** with each Ray version, like the other patches.
- **More database reads while waiting for logs.** On a server with many clients following short jobs at once, this could matter. It wasn't load tested.
- **A longer head command on every status check.** The log directory lookup adds one small query to every monitor-loop check, not only the final one.
- **Trusting the tail's exit code.** Change 5 treats it as SUCCEEDED before the controller records that. This is a critical code path (`sky/jobs/`) and should get close review.

## 8. Results

All runs are on `kind-skypilot`, one kind node on 12 host cores, 6 nodes, consolidation mode. Each A/B has 8 measured runs per arm. Medians.

### 8.1 `ej-prj-3-job2`, why it was dropped

`ej-prj-3-job1` → `ej-prj-3-job2`, `sky jobs launch`, published image: client total 49.1 → 49.6 s (p = 0.93). The likely reason is a uv lock: the dry run holds the venv's lock while waiting on PyPI, so the wheel install still waits for it. This was reproduced in a throwaway container, but not observed inside a slow launch (`precompile_runtime_bytecode_design.md`).

**Setup stalls remain.** `setup_runtime_on_cluster` still reached 8.3 s and 11.6 s in the latest A/B.

### 8.2 Each change

| Change | Compared | Measure | Before | After | p |
|---|---|---|---|---|---|
| 1 | Pins vs pins + flag, `sky launch` | Launch wall time | 34.90 s | **26.25 s** | 0.0002 |
| 1 | | Provisioning total | 19.34 s | 12.66 s | 0.0005 |
| 2 + 3 | Together, `sky launch` | Head container → GCS first log | 5.82 s | **3.37 s** | 0.0002 |
| 2 + 3 | | Head container → last raylet | 14.22 s | 11.77 s | 0.0005 |
| 2 + 3 | | Last container started → noticed | 0.70 s | **0.16 s** | 0.0061 |
| 2 + 3 | | Create pods, wait until Running | 6.04 s | 5.15 s | 0.026 |
| 4 | gRPC on, 4 launches, no A/B | Recorded job duration | 0.00 s | 6.32–6.82 s | |
| 5 | `ej-prj-i2-3` vs `ej-prj-i2-4` | RUNNING → SUCCEEDED | 3.35 s | **0.12 s** | 0.0001 |
| 5 | | SUCCEEDED → client exits | 2.48 s | 3.84 s (worse) | 0.0001 |
| 5 | | Client total | 36.07 s | 34.31 s | see below |
| 6 + 7 | `ej-prj-i2-5` vs `ej-prj-i2-6` | SUCCEEDED → client exits | 4.3 s | **2.6 s** | 0.0002 |
| 6 + 7 | | Client total | 41.3 s | 40.0 s | 0.19 |

For change 5's client total, the rank test gives p = 0.038 and the permutation test on means gives p = 0.38, because of one 41.6 s candidate run.

### 8.3 All changes through `ej-prj-i2-5` (`20261102-162102-jobs-ab`)

Base is `5ef55efa4` with the published image. Candidate is `ej-prj-i2-5` at `1ffd36f8f` (since reworded to `7db718aa0`) with the bytecode image. Both use `IfNotPresent`.

| Phase | `5ef55efa4` | `ej-prj-i2-5` | Δ |
|---|---|---|---|
| A: client start → job row | 7.0 (6.5–7.6) | 6.9 (6.6–7.2) | −0.1 |
| B: row → STARTING | 2.7 (2.4–5.0) | 2.3 (2.2–2.6) | −0.4 |
| C: STARTING → provisioning | 3.1 (2.7–3.8) | 3.2 (2.5–3.9) | +0.1 |
| **D: provisioning → submitted** | 29.6 (28.8–31.4) | **14.7** (14.3–18.9) | **−14.9** |
| E: job runs | 8.6 (8.3–9.2) | 6.7 (6.5–6.8) | −1.9 |
| F: job ended → RUNNING | 2.9 (2.4–3.4) | 2.8 (2.2–3.3) | −0.1 |
| **G: RUNNING → SUCCEEDED** | 11.0 (8.0–15.1) | **0.1** (0.1–0.2) | **−10.9** |
| H: SUCCEEDED → client exits | 3.1 (2.5–6.1) | 4.3 (4.1–4.5) | +1.2 |
| **Client total** | 69.9 (64.3–73.5) | **41.1** (40.7–45.3) | **−28.8** |

This base and candidate also differ by the earlier `ej-prj-*` changes and by 14 newer `master` commits, so it isn't a measure of this doc's changes alone. There's no A/B of the fork point against `ej-prj-i2-6`.

### 8.4 `ej-prj-i2-5` vs `ej-prj-i2-6` (`20261102-i2-6-ab`)

Both arms use the bytecode image.

| Phase | `ej-prj-i2-5` | `ej-prj-i2-6` | Δ |
|---|---|---|---|
| A: client start → job row | 7.0 (6.3–7.4) | 6.9 (6.5–7.7) | −0.1 |
| B: row → STARTING | 2.4 (2.1–3.1) | 2.5 (2.3–4.2) | +0.1 |
| C: STARTING → provisioning | 3.1 (2.5–3.6) | 3.1 (2.8–3.8) | +0.1 |
| D: provisioning → submitted | 15.3 (14.0–19.8) | 14.9 (14.1–22.2) | −0.3 |
| E: job runs | 6.7 (6.6–6.8) | 6.7 (6.6–6.9) | 0.0 |
| F: job ended → RUNNING | 2.5 (2.0–4.1) | 2.5 (1.4–3.0) | 0.0 |
| G: RUNNING → SUCCEEDED | 0.2 (0.1–0.2) | 0.1 (0.1–0.1) | −0.1 |
| **H: SUCCEEDED → client exits** | 4.3 (3.7–4.8) | **2.6** (1.9–3.3) | **−1.7** |
| Client total | 41.3 (40.5–44.9) | 40.0 (38.0–46.2) | −1.3 |

- **Phase H:** the p-value comes from each run's trace, which gives medians of 4.29 s and 2.54 s. Every `ej-prj-i2-6` run beat every `ej-prj-i2-5` run.
- **The pause you see:** the gap between SUCCEEDED and "Managed job finished" fell from 2.8 s to 1.1 s.
- **Client total:** it isn't significant (p = 0.19 on means, 0.065 on ranks). The gain is small next to setup-time swings, and one 46.2 s run raises the `ej-prj-i2-6` average.

**Phases A and C are bimodal, and the cause is unknown.** They move together, across both arms and across code versions:

| Run | Phase A | Phase C |
|---|---|---|
| 10-31 19:01, 11-01 13:14 | about 7 s | about 3.3 s |
| 11-01 22:08 (`job2-jobs-ab`) | 3.0–3.3 s | 1.1–1.3 s |
| 11-02 00:52 | 7.0–7.2 s | 2.9–3.5 s |
| 11-02 14:00 (`i2-4-ab`) | 3.2–3.3 s | 0.9–1.1 s |
| 11-02 about 16:00 (wait trace, untraced arm) | 3.35 s | 0.70 s |
| 11-02 16:21, 18:51 | about 7 s | about 3.1 s |

The difference between the modes (about 4 s + 2.4 s) accounts for most of the gap between "about 34 s" and "about 41 s" client totals. The same benchmark script produced both modes, so the script isn't the cause. Most of phase A's measured wait in the fast mode is the GCP credential check, so credentials or `gcloud` state are the first thing to test. That's unconfirmed.

### 8.5 Tests

- **Unit tests on `ej-prj-i2-6`:** 11,011 passed and 5 failed, excluding `test_adaptor.py`, which hangs here and on `master`. The 5 failures are in code these changes don't touch and pass when run alone.
- **Intermittent:** `test_checks_status_every_gap_otherwise` failed twice during development (9213 sleeps instead of 15), then 0 of 25 on both `ej-prj-i2-5` and `ej-prj-i2-6`. Cause not found.
- **mypy:** only the 2 `fetch_nebius.py` errors, which also appear on `master`, so `format.sh` exits 1.
- **Real launches:** change 5 had one launch each for a job that succeeds, fails (exit 3), is still running when its launch returns, and runs with gRPC on. The `ej-prj-i2-6` code had 10 benchmark launches (warm-ups included) and 1 consolidation-mode check, all succeeding, plus 1 launch through a separate controller pod.

**Not tested:**
- No smoke tests are recorded for any change in this doc. The consolidated doc's §7.5 ran against `ej-prj-3-job1`.
- Change 7's failed-job path has no unit test and no launch.
- Change 7 hasn't run with pool jobs or against an older cluster runtime.
- Change 3's pod deletion during the wait is covered only by unit tests.
- Change 4's new client with an older skylet is covered only by mocks.
- The GPU image hasn't been built.

## 9. Remaining work, by expected gain

Gains are for a 6-node `sky jobs launch` on kind. Times come from the `ej-prj-i2-5` wait trace, so they're upper limits, and estimates where marked.

1. **Explain the bimodal phases A and C** (about 6 s, §8.4). It's the largest unexplained time left.
2. **Publish the bytecode image and use `IfNotPresent` for the default image.** Without these, users don't get the numbers here.
3. **Run the scheduler without a new Python process** (1.55 s in phase B).
4. **Skip `is_definitely_autostopping` after the controller's own launch** (about 2.0 s across E and F).
5. **Merge the head commands around submission:** `set_autostop` 1.56 s, `_add_job` 1.56 s, queue job 1.58 s. gRPC by default would address the same cost.
6. **Fix the setup stalls:** run the dry run only if the offline install fails, so a pod on SkyPilot's images never contacts PyPI (`precompile_runtime_bytecode_design.md`). Stalls add up to about 10 s.
7. **Shrink the client's own time.** About 1.4 s remains between "Managed job finished" and exit.

**A separate UX issue:** in 10 of 11 traced runs the client never tailed the job, so a short job's logs appear in one burst after SUCCEEDED, not as they're written. Tailing the cluster directly when the logs aren't saved yet would fix that.

## 10. Reproducing

`sky jobs launch` A/B, from the repo root with no other launches on the context. It restarts the API server with `--deploy` and switches the checkout, then restores both. It refuses uncommitted changes to tracked files.

```bash
python ej/reproduce_benchmarks.py jobs-ab --nodes 6 \
    --base ej-prj-i2-5 --candidate ej-prj-i2-6 \
    --base-task ej/task_bytecode.yaml \
    --candidate-task ej/task_bytecode.yaml \
    --blocks 4 --runs 4 --warmup 1
```

`sky launch` A/B, which needs no restart of your server:

```bash
python tests/kubernetes/launching_benchmarks/bench_launch_latency.py run \
    --baseline-ref <ref> --candidate-ref <ref> --context kind-skypilot \
    --task ej/task_published_ifnotpresent.yaml \
    --candidate-task ej/task_bytecode.yaml --runs 8 --warmup 1
```

If you start the server by hand, use `sky api start --deploy`. Plain `sky api start` turns consolidation mode off, and the next `sky jobs launch` creates a separate controller pod.

**Results:**
- `bench_results/20261102-i2-6-ab/`: changes 6 + 7.
- `bench_results/20261102-162102-jobs-ab/`, also `report_11021730.md`: §8.3.
- `bench_results/20261102-i2-4-ab/`: change 5.
- `bench_results/20261102-wait-trace/`: the wait trace.
- `bench_results/20261101-234729-lazy-watch-ab/`: changes 2 + 3.
- `bench_results/20261101-223248-bytecode-image-ab/`: change 1.
- `bench_results/20261101-232932-timestamp-verify/`: change 4.
- `bench_results/20261101-220833-job2-jobs-ab/`: `ej-prj-3-job2`.

**Diagrams:** `sky_jobs_launch_sequence_i2.svg` predates changes 6 and 7. `sky_jobs_launch_workflow_i2_6.svg` includes them.

## 11. Review of `launch_latency_consolidated_design.md`

That doc is accurate for the `ej-prj-3-job1` work it describes, and I haven't edited it. These parts are now out of date:

| Section | What it says | Now |
|---|---|---|
| Header | `ej-prj-3-job1` is pushed at `8786d20be` | The branch head is `5cb8dace3`, and `8786d20be` isn't on it. |
| Header | Five changes, stops at `ej-prj-3-job1` | Doesn't mention `ej-prj-3-job2` or the `ej-prj-i2-*` line. |
| §1, §9 item 3, §13 | The first storage check costs 4.8 s of phase A | True only in the slow mode. Later profiling measured 1.1–1.6 s in the fast mode (§8.4). |
| §3.4 | `get_job_status_and_submitted_at`, `_job_status_and_submitted_at_on_head`, `get_job_status_and_submitted_timestamp` | Now `get_job_status_and_times`, `_job_status_and_times_on_head`, `get_job_status_and_timestamps`. |
| §6 | Everything is server-side or in the startup script | Change 4 alters the skylet proto and `SKYLET_VERSION`. |
| §9 | Items 1 and 4 listed as open | Item 1 was tried without gain; item 4 is done (§2). |
| §11 | Client exits 2.4–3.0 s after SUCCEEDED | Changed by change 5, then by changes 6 and 7 (§8.4). |
| §14 | 6-node client total 54.8 s | Superseded by about 40 s, with the bytecode image and `IfNotPresent`. |
| §15 | Offline wheel and D of about 19 s proposed | D is now about 15 s, reached by other means. |
