# Design: hide urllib3's "Connection pool is full" warning for SkyPilot's Kubernetes clients

- **Branch:** `ej-k8s-pool-warning`, cut from `origin/master` at `5ef55efa4`
- **Commit:** `5bb46b39a` "[Kubernetes] Hide urllib3 pool-full warning from capped API clients"
- **Pushed to:** https://github.com/siliconej/skypilot/tree/ej-k8s-pool-warning
- **Not in the combined branch** `ej-prj-3-job1`. It is independent of the launch-latency work.
- **PR text:** `pr_descriptions.md`

## 1. Background

`sky/adaptors/kubernetes.py` builds the Kubernetes API clients SkyPilot uses. Since #11136 (`ecc8eb527`, "Cap the connections each Kubernetes API client keeps open"), each client's urllib3 pool keeps at most `CONNECTION_POOL_MAXSIZE = 4` connections:

```python
config.connection_pool_maxsize = CONNECTION_POOL_MAXSIZE
```

The cap is deliberate. If something between SkyPilot and the API server doesn't pass on the server's close of an idle connection, every connection opened at peak concurrency would otherwise stay open for the life of the client. That can be the whole process, such as a jobs controller. Requests beyond 4 in parallel still work: they use a connection that is closed afterwards.

When urllib3 closes one of those extra connections, it logs a warning (urllib3 2.8.0, `HTTPConnectionPool._put_conn`):

```python
log.warning(
    "Connection pool is full, discarding connection: %s. Connection pool size: %s",
    self.host,
    self.pool.qsize(),
)
```

## 2. The problem

**Users see warnings about intended behaviour.** Any operation with more than 4 Kubernetes API calls in parallel prints them, for example creating or inspecting the pods of a cluster with more than 4 nodes:

```
WARNING:urllib3.connectionpool:Connection pool is full, discarding connection: 127.0.0.1. Connection pool size: 4
```

**Observed:** every 6-node managed job in the 2026-10-31 benchmark (jobs 105–124, `launch_latency_consolidated_design.md` §14) has 6–7 of these lines in its controller log, right after "Launching on Kubernetes".

**Why the existing guard doesn't stop them.** The API getters are wrapped in `_api_logging_decorator('urllib3', logging.ERROR)`, which keeps the `urllib3` logger at ERROR:

- **The decorator reasserts the level only after a getter returns.** It does that once per client construction, not per API call, to keep `Logger.setLevel()` calls rare. `setLevel()` takes logging's process-wide lock, and on Python < 3.13 a `fork()` while another thread holds that lock deadlocks the child.
- **`kubernetes.client.Configuration` resets the logger.** Every `Configuration.__init__` runs its `debug` setter. With `debug=False`, that sets every logger in `self.logger` to WARNING, including `logging.getLogger("urllib3")` (kubernetes 35.0.0).
- **So the level is often WARNING when the pool overflows.** A `Configuration` built anywhere (another code path, or another thread in the middle of a call) puts `urllib3` back to WARNING. `urllib3.connectionpool` has no level of its own and inherits it, so the pool-full warning gets through until the next decorated call.

## 3. Goals and non-goals

### Goals
- Stop showing the pool-full warning for SkyPilot's own capped Kubernetes clients.
- Keep every other urllib3 warning, such as retries after a broken connection, and pool-full warnings from pools of other sizes.
- Add no `setLevel()` calls and no per-record locking, for the fork-safety reasons in §2.

### Non-goals
- Changing the pool cap or its behaviour (#11136).
- Changing `_api_logging_decorator`.
- Silencing urllib3 for other libraries.

## 4. Design

A `logging.Filter` on the `urllib3.connectionpool` logger, installed once when `sky/adaptors/kubernetes.py` is imported:

```python
class _PoolFullFilter(logging.Filter):

    def filter(self, record: logging.LogRecord) -> bool:
        return not (isinstance(record.msg, str) and
                    record.msg.startswith('Connection pool is full') and
                    isinstance(record.args, tuple) and len(record.args) == 2 and
                    record.args[1] == CONNECTION_POOL_MAXSIZE)


logging.getLogger('urllib3.connectionpool').addFilter(_PoolFullFilter())
```

- **It matches the unformatted record.** It checks the message template and its arguments, not the formatted string, so it doesn't depend on the host or on formatting.
- **It matches only SkyPilot's pool size.** The second argument is `self.pool.qsize()`. When the pool is full, that equals its maximum size, so it equals `CONNECTION_POOL_MAXSIZE` only for pools capped at 4.
- **A level reset can't undo it.** Filters live on the logger object, and `Configuration`'s `setLevel()` doesn't touch them.
- **It costs almost nothing.** A filter runs only for records that pass the level check, takes no lock, and is installed once. Nothing runs per API call.
- **It sits on the logger that emits the record,** `urllib3.connectionpool`. Logger filters run only on the logger where a record is created, not on parents it propagates to, so a filter on `urllib3` would never see it.

## 5. Alternatives considered

| Alternative | Why not |
|---|---|
| Raise `CONNECTION_POOL_MAXSIZE` | Undoes the point of #11136: more idle connections held open for the life of the client. A burst above the new cap would still warn. |
| Set `urllib3.connectionpool` to ERROR | `Configuration` resets only the parent `urllib3`, so this would stick. But it also hides that logger's other warnings, such as "Retrying (...) after connection broken", which are useful. And `setLevel()` takes the global lock (§2). |
| Reassert the level more often in `_api_logging_decorator` | More `setLevel()` calls, which is what that decorator was rewritten to avoid. It would still race with a `Configuration` built in another thread. |
| `pool_block=True`, so parallel requests wait for a pooled connection | Adds latency to the parallel pod operations the cap is meant to allow. |
| Filter on the `urllib3` parent logger | Logger filters don't run for records propagated from children, so it would never see the warning (§4). |

## 6. Compatibility and risks

- **No behaviour change** beyond logging. No API, config or wire-format change.
- **A third-party urllib3 pool of size exactly 4 would also be filtered.** Common defaults are 10 (requests, botocore), and only this one message is filtered, so the risk is small. Matching on the host would make the filter depend on the cluster's address.
- **The filter depends on urllib3's message text.** If urllib3 rewords it, the warning comes back; nothing breaks. The unit test fixes the format the filter expects.
- **Hidden at every level, including debug.** Under `SKYPILOT_DEBUG=1` the message is hidden too, for SkyPilot's capped pools only. Debugging pool exhaustion would need the filter removed.

## 7. Testing

- **Unit test:** `test_pool_full_warning_hidden_for_capped_clients` in `tests/unit_tests/test_sky/adaptors/test_kubernetes_adaptor.py`, parametrized on the pool size.
  - The `urllib3.connectionpool` logger is left at WARNING, as a `Configuration` built elsewhere would leave it, so the filter alone has to hide the message.
  - It emits urllib3's exact call: hidden at `CONNECTION_POOL_MAXSIZE`, shown at `CONNECTION_POOL_MAXSIZE + 6`.
  - An unrelated urllib3 warning ("Retrying after connection broken") still gets through.
- **Results:** the adaptor test file passes (28 passed) on the branch, run against the branch's own code. yapf and isort are clean, pylint on `sky/` adds no messages, and mypy has only master's 2 errors.
- **Not yet done:** an end-to-end check. Launch a cluster with more than 4 nodes (for example `ej/job.yaml` with `num_nodes: 6`) and confirm that no "Connection pool is full" line appears in the launch output or the managed job's controller log. Before the fix, each such job logged 6–7.

## 8. Follow-up

1. Run the end-to-end check in §7, and add it to the PR's Tested section.
2. If urllib3's message ever changes, update the filter and the test together.
