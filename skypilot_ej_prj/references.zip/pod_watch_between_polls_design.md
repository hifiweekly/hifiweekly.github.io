# Design: Watch pods between polls while waiting for them to run

- **Commit:** `71b3c9213` on `ej-prj-i2-5` and `ej-prj-i2-6`; `16738238e` on `ej-prj-i2-3` and `ej-prj-i2-4`.
- **Status:** pushed to the fork, not merged. It merges onto `origin/master` (`8ec83b9d8`) without conflicts, so it can be its own PR.
- **Code:** `sky/provision/kubernetes/instance.py`.
- **Tests:** `tests/unit_tests/kubernetes/test_pod_run_wait.py`.
- **Results:** `bench_results/20261101-234729-lazy-watch-ab/`.
- **Related:** `launch_latency_design_after_job2.md` §3.3.

## TL;DR (PR description)

### `[Kubernetes] Watch pods between polls while waiting for them to run`

#### Summary

- **Problem:** `_wait_for_pods_to_run` slept 1 s between polls, so a launch noticed its last pod about 0.5 s late on average, and up to a full second.
- **Fix:** replace the sleep with a Kubernetes watch that ends the wait early when every waiting pod is running or a pod is going away.
- **Unchanged:**
  - The poll that follows still makes every decision, so failure handling and timeouts are the same.
  - Polling stays about once a second when nothing is ready.
  - Any watch failure, including missing `watch` permission, falls back to sleeping out the rest of the interval.
- **Cost:** one extra watch request per poll interval, per launching cluster, while pods start.

Files: `sky/provision/kubernetes/instance.py` and a new unit test file.

#### Tested

- [x] Code formatting: `yapf --diff` and `isort --check` are clean on the changed files. Pylint on the changed `sky/` files rates 10.00/10. mypy has no errors beyond master's 2 in `fetch_nebius.py`.
- [x] Any manual or new tests for this PR (please specify below)
  - **New unit tests:** `tests/unit_tests/kubernetes/test_pod_run_wait.py`, 12 passed.
  - **A/B on kind** (`sky launch`, 6 nodes, 8 runs per arm, medians, together with a lazy Ray Serve import that runs after this wait):
    - last container started → SkyPilot notices: 0.70 → **0.16 s** (p = 0.0061);
    - create pods, wait until Running: 6.04 → **5.15 s** (p = 0.026).
  - **Manual, on kind:** an image that can't be pulled still fails in 8 s with `ErrImagePull`.
- [ ] All smoke tests: `/smoke-test` (CI) or `pytest tests/test_smoke.py` (local)
- [ ] Relevant individual tests: `/smoke-test -k test_name` (CI) or `pytest tests/test_smoke.py::test_name` (local)
  - Not run. Suggested: `test_cluster_job.py::test_multi_hostname`, `test_kubernetes_pod_failure_detection`, and `test_kubernetes_pod_loss.py::test_launch_fails_fast_when_pod_deleted`.
- [ ] Backward compatibility: `/quicktest-core` (CI) or `pytest tests/smoke_tests/test_backward_compat.py` (local)
  - Not run. This is server-side only, with no API change.

---

## 1. Problem

After creating pods, the provisioner waits in `_wait_for_pods_to_run` until every pod is Running with all its containers running. Each round lists the cluster's pods, checks them, then sleeps 1 s.

So the launch learns that its last pod is up only at the next poll. On a 6-node launch on kind, that gap had a median of **0.70 s** (0.25–1.2 s). Every step after this, including file mounts and runtime setup, starts that much later.

This is a small part of a launch. It's worth fixing because the fix is small and removes the delay on every launch, whatever the cluster size.

## 2. Goals

- **Notice the last running pod within a fraction of a second.**
- **Change no decision.** Timeouts, stall detection, error messages and status messages must behave as they do today.
- **Never make a launch worse.** If the watch can't work on some cluster, the launch should behave as if it weren't there.

**Not a goal:** rewriting the wait around watch events. The poll logic handles many failure cases (see §6), and duplicating it isn't worth about 0.5 s.

## 3. Design

### 3.1 The change

The `time.sleep(1)` at the end of each round becomes `_wait_for_next_pod_run_poll`:

```
round:
  list pods                     (keeps the list's resource_version)
  check each pod, make decisions, update status
  all running? → return
  wait for next poll:
    watch this cluster's pods, starting at that resource_version, for up to 1 s
      DELETED, deletion_timestamp set, or phase Failed → end the wait
      pod running with all containers running          → cross it off
      nothing left to wait for                         → end the wait
    watch ended or failed → sleep the rest of the 1 s
```

The list call keeps its label selector, which now goes in a variable that the watch shares. The poll's "pod is running" check moves into `_pod_containers_running`, so the poll and the watch can't disagree on what running means.

### 3.2 Key decisions

**The watch only ends the wait; the poll decides.** The watch never returns a result. When it ends early, the next round lists the pods again and applies all its usual logic. That's what keeps §6's behaviour unchanged, and it leaves only a little new code to get right.

**End early only when the next poll would matter.** A poll costs several API calls per pending pod, so waking on every event would add load for no gain. The wait ends only if:
- every pod that was waiting is now running, so the wait can finish; or
- a pod is going away, so the poll should report it sooner.

A pod that merely changes state, such as one becoming Running while others wait, doesn't end the wait.

**Start from the list's `resource_version`.** The watch then sees every change after the poll's list, so a pod that starts between the list and the watch can't be missed.

**Best effort.** Everything is inside `try/except Exception`, and any failure logs at debug level and sleeps the remaining time. A broad except is deliberate here: the worst outcome of a failed watch is today's behaviour.

### 3.3 Timeouts

| Setting | Value | Why |
|---|---|---|
| `timeout_seconds` (server-side) | 1 s | The poll interval, so the poll keeps its rhythm. |
| `_request_timeout` (connect, read) | (5, 2) s | The read timeout only catches a server that ignores `timeout_seconds`. |

A watch that hangs therefore delays the next poll to at most about 2 s after connecting. The rest of the interval is computed from elapsed time, so a watch that ends early with nothing to report doesn't shorten the interval or add a full extra second.

## 4. Alternatives considered

| Alternative | Why not |
|---|---|
| Poll faster (for example, every 0.2 s) | Each poll makes several API calls per pending pod, so it adds load on every launch to gain about 0.4 s. |
| Replace polling with a watch | It has to reproduce the poll's failure handling (§6), and needs a fallback for clusters where watching fails anyway. |
| Wake the poll on every event | A multi-node launch produces many pod updates, and each would trigger a full poll. |
| Keep the 1 s sleep | Costs about 0.5 s on every launch, and the fix is about 50 lines. |

## 5. Failure handling

| Situation | Behaviour |
|---|---|
| The watch can't start (network, no permission) | Sleeps the rest of the interval. |
| The watch fails midway | Same. |
| `resource_version` is too old (HTTP 410) | The client raises `ApiException`, since it doesn't retry when `timeout_seconds` is set. Sleeps the rest of the interval, and the next round has a fresh version. |
| The server ignores `timeout_seconds` | The 2 s read timeout ends it, and the next poll runs at once. |
| The list has no `resource_version` | Caught the same way, then a plain sleep. |
| A pod is deleted or fails | The wait ends early, and the poll reports it as before. |
| A container waits on an image pull error | No early end. The next poll sees it within about 1 s, as before. |
| Nothing changes | A full 1 s wait, as before. |

## 6. What stays the same

All of this lives in the poll, which isn't changed apart from sharing `_pod_containers_running` and the label selector:

- the transport-error grace period (`_POD_POLL_TRANSPORT_ERROR_GRACE_SECONDS`);
- stall timeouts and missing-pod handling;
- init container checks;
- image pull and container failure errors;
- status messages.

`_wait_for_pods_to_schedule` still polls and isn't touched.

## 7. Compatibility

- **API, client and server:** no change. It runs in the provisioner, on the API server or jobs controller.
- **Permissions:** the watch needs the `watch` verb on pods.
  - The role in the docs (`sky-sa-role`) grants `*` on pods, so the default setup has it.
  - A stricter custom role gets a 403, which falls back to sleeping, so launches still work without the gain.
- **Kubernetes client:** tested with `kubernetes` 35.0.0.

## 8. Results

Run on `kind-skypilot`, one kind node with 12 cores: `sky launch`, 6 nodes, the template's default image and pull policy, 8 measured runs per arm, medians.

| Measure | Before | After | p |
|---|---|---|---|
| **Last container started → SkyPilot notices** | 0.70 s (0.25–1.2) | **0.16 s** (0.13–0.94) | 0.0061 |
| **Create pods, wait until Running** | 6.04 s (4.9–6.6) | **5.15 s** (4.6–6.3) | 0.026 |

- **This A/B also included the lazy Ray Serve import** (`1ddcc3240`), and the two weren't measured apart. That import runs after containers start, so it shouldn't affect these two measures, but that's reasoning rather than a separate test.
- **The stage improved by more than the detection did** (0.89 s against 0.54 s). The other 0.35 s isn't explained, and may be noise.
- **The worst case is still 0.94 s.** In at least one run the watch didn't catch the last pod promptly. I didn't investigate which path that run took.
- **Consistent later result:** in the `ej-prj-i2-5` A/B against master with `IfNotPresent`, pods ready went from 2.77 s to 1.92 s (p = 0.0002). That A/B has many other changes and different images, so it isn't a measure of this change alone.

**Negative test:** a launch with an image that can't be pulled still failed in 8 s with `ErrImagePull`.

## 9. Tests

`tests/unit_tests/kubernetes/test_pod_run_wait.py`, 12 passed. It covers:

- the wait ends when the last waiting pod is running;
- the watch starts from the poll's own list;
- some pods still waiting, or a pod that isn't ready, doesn't end it;
- a pod going away ends it, for the poll to report;
- a watch error, a failure to start the watch, and a list without a version all fall back to sleeping;
- only the rest of the interval is slept.

**Not tested:**

- Deleting a pod during the wait, on a real cluster. Only unit tests cover it.
- A role without the `watch` verb, on a real cluster. The fallback is covered only by the generic watch failure tests.
- Any cluster other than kind, including ones with a proxy in front of the API server.
- Load from many launches at once.
- Smoke tests. None are recorded for this commit.

## 10. Risks

- **More API requests.** Each launching cluster makes one more request per second while its pods start. That's small next to the poll's own calls and lasts seconds, but on a slow start or a long autoscale it could last much longer. It wasn't load tested.
- **Long-held waits.** During a long wait for pods, this repeats the watch once a second rather than holding one open. That's simple, but more requests than a long-lived watch would make.
- **Repeated early wake-ups.** A terminating pod that keeps receiving updates ends the wait on each update, so polls follow the rate of those updates until the pod is gone. It should be brief, and I didn't measure it.
- **Proxies.** A proxy that buffers streams could delay events, or end the watch. Either way it falls back to today's timing.

## 11. Open questions

1. Should a smoke test assert the launch still fails fast when a pod is deleted during this wait? `test_kubernetes_pod_loss.py` deletes pods during setup, which is later.
2. Should a repeated watch failure stop trying for that launch? Today, a role without `watch` makes one failed request per second for the whole wait.

## 12. Reproducing

```bash
# Unit tests
pytest tests/unit_tests/kubernetes/test_pod_run_wait.py

# The A/B's harness, its analysis and the negative test's output
ls ej/bench_results/20261101-234729-lazy-watch-ab/harness/
cat ej/bench_results/20261101-234729-lazy-watch-ab/negative.log
```

To isolate this change from the Serve patch, run `sky-launch-ab` (see `README_i2.md`) with `--baseline-ref 71b3c9213~1 --candidate-ref 71b3c9213` and the same task for both arms. `71b3c9213~1` is the commit that adds the lazy Serve import, so that's the only difference. That A/B hasn't been run.
