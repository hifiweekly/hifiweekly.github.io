# Design: Get a finished job's end time with its status

- **Commit:** `b848c9c1e` on `ej-prj-i2-4`, the only commit that branch adds to `ej-prj-i2-3`. The same code is `7db718aa0` on `ej-prj-i2-5` and `ej-prj-i2-6`.
- **Status:** pushed to the fork, not merged.
- **Code:** `sky/jobs/controller.py`, `sky/jobs/recovery_strategy.py`, `sky/jobs/utils.py`, `sky/skylet/job_lib.py`.
- **Results:** `bench_results/20261102-i2-4-ab/`.
- **Related:** `launch_latency_design_after_job2.md` §3.5.

Names in this doc are as of `ej-prj-i2-4`. `ej-prj-i2-6` later changes some of them (§10).

**Fix before opening a PR from `ej-prj-i2-4`:** `b848c9c1e`'s message says the client "still waits for its own log tail", which is wrong. `7db718aa0` has the correct explanation, given in §7.

## 1. Summary

After a managed job ended, the controller ran two commands on the head node, a status check and then an end-time fetch. The client's log follower ran its own status check too. Without gRPC, each is a `kubectl exec` or SSH round trip of about 1.6 s.

This change gets the end time in the same command as the status, and removes the follower's check when the tail already says the job succeeded.

On a 6-node `sky jobs launch`, **RUNNING → SUCCEEDED drops from 3.35 s to 0.12 s** (p = 0.0001). The client total gains less, 36.07 s → 34.31 s, because the wait after SUCCEEDED grows by 1.4 s (§7). Only the rank test finds the total's drop significant (p = 0.038; p = 0.38 on means).

## 2. Problem

For a short job, the end of a launch looked like this:

```
launch returns; controller checks status (and submitted-at)    one head command
  → job has already finished; controller marks it RUNNING
monitor loop: status check                                     one head command
monitor loop: end time                                         one head command
controller marks it SUCCEEDED
```

- **The launch's check had already seen the job finish,** and the earlier `ej-prj-job0` change kept that status. It was used only to skip the first sleep, so the loop still asked the head again.
- **The two monitor-loop commands explain the 3.35 s** in RUNNING → SUCCEEDED, at about 1.6 s each.
- **The same applied after a longer job.** Once a job had ended, the loop needed the status and the end time, and ran a command for each.

The follower had a similar repeat. When its tail exited with a known code, it asked the head for the job's status, even when the code already said SUCCEEDED.

## 3. Goals

- **Mark a finished job SUCCEEDED without another head command** when the launch already knows the outcome.
- **Fetch status and end time together** in the monitor loop.
- **Keep the same recorded times and the same error handling.**
- **Keep older cluster runtimes working.**

**Not a goal:** shortening the wait for saved logs after SUCCEEDED. This change makes that wait longer, and `ej-prj-i2-6` addresses it (§10).

## 4. Design

### 4.1 One head command for status and times

`JobLibCodeGen.get_job_status_and_submitted_timestamp` becomes `get_job_status_and_timestamps`. It prints three payloads in order: statuses, submitted-at and ended-at.

```python
print(job_lib.get_statuses_payload([job_id]), flush=True)
print(job_lib.get_job_submitted_or_ended_timestamp_payload(job_id, False), flush=True)
print(job_lib.get_job_submitted_or_ended_timestamp_payload(job_id, True), flush=True)
```

`_job_status_and_times_on_head` parses them and returns `(status, submitted_at, ended_at)`.

**`ended_at` is only set for a terminal status.** The status is read first, so a job that ends just after that read isn't terminal here, and its end time waits for the next check. That way, the controller never pairs a RUNNING status with an end time.

### 4.2 Hand over what the launch saw

```
_wait_until_job_starts_on_cluster
  get_job_status_and_times → status, submitted_at, ended_at, reason
  remember status and ended_at on the executor
        │
        ▼
monitor loop
  pop_job_status_seen_at_launch()
  pop_job_ended_at_seen_at_launch()
  SUCCEEDED with an end time → use them; no head command
  otherwise                  → status check as before
```

- **Only SUCCEEDED with an end time skips the check.** Any other terminal status still gets a fresh check, because failures go through recovery logic that should see current state. It skips the first sleep, as before.
- **Each value is used once.** The pop clears it, so a later loop iteration can't reuse it.
- **A new wait clears them.** `_wait_until_job_starts_on_cluster` resets both at its start, and when the timestamp fetch fails, so a recovery can't inherit an earlier launch's result.
- **Class-level defaults.** As with the existing status field, executors built without `__init__` still work.

### 4.3 The monitor loop's own check

`get_job_status` keeps its signature and behaviour for other callers. Both it and a new `get_job_status_and_ended_at` wrap a shared `_get_job_status`.

- The monitor loop calls `get_job_status_and_ended_at`.
- On SUCCEEDED or a user-code failure, the controller uses the returned `job_ended_at`.
- If it's `None`, the controller falls back to `try_to_get_job_end_time`, as before.

### 4.4 The log follower

Two small changes in `_stream_logs_by_id`:

- **Trust a tail exit code of SUCCEEDED.** The follower sets `job_status` to SUCCEEDED rather than asking the head. A registered runtime is still asked first, and any other exit code still queries the head.
- **Poll faster for the final status.** `_FINAL_JOB_STATUS_POLL_SECONDS = 0.2` replaces a 1 s sleep while waiting for the controller to record the terminal status. The wait is short, happens only after the job finished, and decides when the client can exit. The 120 s limit stays.

The follower's final answer still comes from the status the controller records, so the skipped check doesn't decide what the user is told.

## 5. Alternatives considered

| Alternative | Why not |
|---|---|
| Skip the status check for every terminal status seen at launch | Failures can lead to recovery, so they should see current state. It saves one command only on a path that's already rare and slow. |
| Skip the check when the end time is missing | Then the end time needs its own command, so nothing is saved. |
| Use the time the controller noticed as the end time | It would record the wrong time, by up to the check interval. |
| Turn gRPC on by default | It addresses all head commands, but is a much larger change. |

## 6. Failure handling

| Situation | Behaviour |
|---|---|
| gRPC is on | The status check returns no end time, so `try_to_get_job_end_time` runs. Each gRPC call is cheap. |
| A managed job runtime is registered | Its status is used, with no end time, and the fallback runs. |
| The end time is missing from the payload | `ended_at` is `None`, and the fallback runs. |
| The job ends just after its status is read | The end time is dropped, and the next check gets it. |
| The combined command fails | Same transient/fatal classification as before, through the shared `_fetch_job_status_on_head`. |
| The launch saw FAILED | A fresh status check runs at once. Its end time is reused. |
| The launch saw RUNNING | Normal monitoring, with the jittered first check. |
| A recovery follows a launch that saw SUCCEEDED | Its wait clears the old values. |
| The tail exits with a non-SUCCEEDED known code | The follower queries the head, as before. |
| The controller doesn't record a terminal status | The follower's wait still ends after 120 s. |

## 7. Why the wait after SUCCEEDED grows

SUCCEEDED → client exits goes from 2.48 s to 3.84 s.

The controller marks a job SUCCEEDED before it downloads the logs, so that the status is responsive. The client then waits for those logs to be saved. Before this change, the client tended to reach that wait later. Now SUCCEEDED arrives about 3.2 s sooner, so more of the log download falls after it.

A wait trace of `ej-prj-i2-5` shows what fills that time: polling for the saved logs (2.00 s, at 1 s per poll), the head command that finds the log directory (1.54 s), and an inferred 0.71 s of copying. The polling overlaps the other two.

## 8. Compatibility

- **API, client and server:** no change.
- **Older cluster runtimes:** the generated code calls only `job_lib` functions those commands already call. This wasn't run against an actual older runtime.
- **Payload parsing:** the parser reads by position and treats a missing payload as `None`.
- **Rename:** `get_job_status_and_submitted_at` becomes `get_job_status_and_times`, and now returns 4 values. Both are private to the jobs code, and all callers are updated.

## 9. Results

`sky jobs launch`, `kind-skypilot`, 6 nodes, bytecode image in both arms, 8 measured runs per arm, medians and ranges. `ej-prj-i2-3` against this commit (the A/B ran on `581af90f7`, which has the same code as `b848c9c1e`).

| Phase | Before | After | Change | p |
|---|---|---|---|---|
| A: client start → job row | 3.2 (2.9–3.8) | 3.3 (2.7–3.4) | +0.1 | |
| B: row → STARTING | 2.1 (2.1–3.5) | 2.4 (2.1–3.9) | +0.3 | |
| C: STARTING → provisioning | 1.1 (0.1–1.6) | 0.9 (0.8–1.4) | −0.2 | |
| D: provisioning → submitted | 14.6 (14.1–14.9) | 14.4 (13.9–22.0) | −0.1 | |
| E: job runs | 6.5 (6.2–6.8) | 6.7 (6.3–6.8) | +0.1 | |
| F: job ended → RUNNING | 2.6 (2.0–3.2) | 2.4 (1.9–2.9) | −0.2 | |
| **G: RUNNING → SUCCEEDED** | 3.3 (3.2–3.4) | **0.1** (0.1–0.2) | **−3.2** | 0.0001 |
| H: SUCCEEDED → client exits | 2.5 (2.3–3.0) | 3.8 (3.3–4.6) | +1.4 | 0.0001 |
| Client start → SUCCEEDED | 33.3 (31.9–35.6) | 30.4 (29.3–38.3) | −2.9 | |
| **Client total** | 36.1 (34.2–38.0) | 34.3 (33.4–41.6) | −1.8 | see below |

- **Client total:** rank test p = 0.038; permutation test on means p = 0.38, because of one 41.6 s run. The improvement is likely real, but not firmly proven.
- **G is steady:** 0.1–0.2 s in every run.
- **SUCCEEDED arrives 2.9 s sooner,** which matters to anyone reading job status, such as the dashboard, even though the client gains less.

**Manual launches** (`bench_results/20261102-i2-4-ab/e2e/`, one each):

| Case | Job | Result |
|---|---|---|
| Succeeds | 349 | SUCCEEDED, rc 0 |
| Fails with exit 3 | 350 | FAILED, rc 100 |
| Still running when its launch returned (`sleep 40`) | 351 | SUCCEEDED, rc 0 |
| `SKYPILOT_ENABLE_GRPC=1` | 352 | SUCCEEDED, rc 0 |

Recorded end times are within 6–60 ms of the job's last output.

**Unit tests:** 15 new ones, covering the status fetch, the handover from the launch and the follower. `tests/unit_tests/test_sky/jobs` has 1390 passed, 1 failed. The failure, `test_storage_teardown_retries_a_transient_error`, passes alone and also fails intermittently on master.

**Not tested:**
- No smoke tests are recorded for this commit, including recovery.
- It hasn't run against an older cluster runtime.
- The controller-cluster (non-consolidation) path wasn't tested.
- Multi-task pipelines and pools weren't launched with this change.
- A follower whose tail returns 0 while the job is being recovered is only reasoned about.

## 10. Risks and follow-ups

- **Critical code path.** `sky/jobs/controller.py` and `recovery_strategy.py` handle recovery and state transitions. The new branch runs only when SUCCEEDED and an end time were both seen, but it skips the checks that usually run before marking success, so it needs close review.
- **Short jobs barely reach RUNNING.** RUNNING now lasts about 0.1 s, so a follower that isn't already tailing rarely sees it. On `ej-prj-i2-5`, `tail_logs` ran in 1 of 11 traced launches, so a short job's logs usually appear in one burst after SUCCEEDED, once they're saved. Tailing the cluster directly when the logs aren't saved yet would fix this. I don't have the same count from before this change.
- **More database reads.** The follower's final wait polls at 0.2 s instead of 1 s. It's bounded by 120 s, and usually lasts well under a second.
- **More work in each status check.** Every monitor-loop check now also fetches both times, though only a terminal status uses the end time. They're small queries in a command that already runs.

**What `ej-prj-i2-6` changes next:**
- `680e03581` polls for saved logs every 0.2 s.
- `d080ff076` returns the log directory with the status too, and replaces the plain end time with an `EndedJob(ended_at, log_dirs)` tuple. It renames `get_job_status_and_ended_at` to `get_job_status_and_ended_job`, and `pop_job_ended_at_seen_at_launch` to `pop_ended_job_seen_at_launch`.
- Together, they take SUCCEEDED → client exits from 4.3 s to 2.6 s (p = 0.0002).

## 11. Reproducing

```bash
# Unit tests
pytest tests/unit_tests/test_sky/jobs

# A/B on 6 nodes; about 20-25 minutes. See README_i2.md for setup.
python ej/reproduce_benchmarks.py jobs-ab --nodes 6 \
    --base ej-prj-i2-3 --candidate ej-prj-i2-4 \
    --base-task ej/task_bytecode.yaml \
    --candidate-task ej/task_bytecode.yaml \
    --blocks 4 --runs 4 --warmup 1
```

Phases A and C swing between two levels across sessions, so compare the arms within one run.
