# Which launch phases gRPC could shorten

**Short answer:** mostly phases D, E and F. For a 6-node `sky jobs launch` on kind, those phases spend up to about 8.4 s on head commands that `SKYPILOT_ENABLE_GRPC=1` would replace, out of a 35–41 s launch. A realistic gain is about 5–7 s, but that is an estimate: no `sky jobs launch` latency has been measured with gRPC on.

**Sources:**
- **Timings:** the `ej-prj-i2-5` wait trace, `bench_results/20261102-wait-trace/full/analysis.txt` (11 traced launches, commit `1ffd36f8f`). The phase letters are the ones in `launch_latency_consolidated_design.md`.
- **gRPC paths:** the `is_grpc_enabled_with_flag` checks in the code on `ej-prj-i2-6`.
- **Earlier measurement:** `launch_latency_analysis_4_nodes.md` §6.

## Phases gRPC would shorten

Without gRPC, each head command is a `kubectl exec` plus a Python start, about 1.6 s. Times are the average per launch across the traced launches. A command can span two phases, so it can appear in more than one row.

| Phase | Head commands gRPC would replace | Time spent |
|---|---|---|
| **D:** provisioning → submitted | `set_autostop` 1.58 s, `_add_job` 1.32 s | **~2.9 s** |
| **E:** job runs | queue job (`_exec_code_on_head`) 1.59 s, `is_definitely_autostopping` 1.19 s, the rest of `_add_job` 0.26 s | **~3.0 s** |
| **F:** job ended → RUNNING | status and times check (`_job_status_and_times_on_head`) 1.62 s, `is_definitely_autostopping` 0.81 s | **~2.4 s** |

## Phases gRPC wouldn't help

- **A, B and C:** the job's cluster doesn't exist yet. The `run_on_head` call in B is the scheduler starting locally (`_consolidated_launch`), not a call to the cluster.
- **G:** already about 0.1 s.
- **H:** its one regular head command, the log directory lookup in `sync_down_logs` (1.55 s in the trace), was removed by change 7 on `ej-prj-i2-6`. What remains is the wait for saved logs and the log copy, which still uses `kubectl exec`.
- **The rest of D:** pod start, Ray and runtime setup don't go through these calls. They make up most of D's roughly 15 s.

## Why the real gain will be under 8.4 s

- **Opening the connection has a cost.** In the earlier test, job submission took 1.4 s on the first launch and 0.4–0.5 s on the next two. That analysis attributed the difference to opening the skylet tunnel, without confirming it. Every managed job launches a new cluster, so some launches may pay this.
- **E may not shrink by the full 3 s.** I didn't check whether the 1.19 s `is_definitely_autostopping` call blocks the job or runs alongside it. Only the 1.59 s queue step clearly delays the job's start.
- **gRPC calls aren't free.** Status and times stay two separate, cheap calls in F.
- **The trace is of `ej-prj-i2-5`, not `ej-prj-i2-6`.** Changes 6 and 7 are described as affecting phase H, so D, E and F should be about the same, but this wasn't traced on `ej-prj-i2-6`.

## What has been measured

Only plain `sky launch`, on an older branch with 4 nodes (`launch_latency_analysis_4_nodes.md` §6, 3 runs):

| Metric | Baseline | gRPC | Δ |
|---|---|---|---|
| Job submission (`Backend.execute`) | 3.68 s | 0.48 s | −3.2 s |
| "Cluster launched" → client returns | 11.7 s | 8.2 s | −3.5 s |

No fallback to SSH was seen in those runs. The 4 launches with gRPC on in `launch_latency_design_after_job2.md` §8.2 checked recorded job durations, not latency.

## Related notes

- **`launch_latency_design_after_job2.md` §9 item 5 undercounts gRPC.** It lists gRPC only against the head commands around submission. The trace shows it would also cover the `is_definitely_autostopping` calls and F's status check. Item 4 there, skipping `is_definitely_autostopping` after the controller's own launch, overlaps with this, so the two gains shouldn't be added.
- **Before making gRPC the default:** find out why `SKYPILOT_ENABLE_GRPC` is off by default, and test clusters whose skylet tunnel can't be reached, to check the fallback to SSH (from `launch_latency_analysis_4_nodes.md` §6).

## Next step

Run a `sky jobs launch` A/B of `ej-prj-i2-6` with and without `SKYPILOT_ENABLE_GRPC=1`, to replace the estimate above with a measurement.
