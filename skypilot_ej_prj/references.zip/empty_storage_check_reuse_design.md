# Design: Reuse an empty storage check result for an unchanged config

- **Commit:** `d771518f1` on `ej-prj-i3-2`, the only commit that branch adds to `ej-prj-i2-6`.
- **Status:** pushed to the fork, not merged.
- **Code:** `sky/check.py`, `sky/global_user_state.py`.
- **Tests:** `tests/unit_tests/test_sky/test_check_empty_storage_result.py`.
- **Results:** `bench_results/20261103-empty-storage-check-ab/`.
- **Related:** `local_run_speedup_tips.md`, which gets a similar saving from config.

## 1. Summary

With no storage cloud enabled, every launch reran the storage check, including its `aws` and `gcloud` commands, even for a task that only uses Kubernetes.

This change records when a check found nothing and which config it ran on. Later launches skip the check while the config is unchanged and the record is under 10 minutes old.

On a 6-node `sky jobs launch`, with launches about 40 s apart, **phase A drops from 6.85 s to 2.20 s** (p = 0.0047) and **client total from 41.31 s to 37.06 s** (p = 0.013). Launches more than 10 minutes apart get no saving (§7).

## 2. Problem

Phase A of `sky jobs launch` reaches the check through this path:

```
launch()                                          sky/jobs/server/core.py:1274
  _upload_files_to_controller()                   sky/jobs/server/core.py:191
    get_cached_enabled_storage_cloud_names_or_refresh()     sky/data/storage.py
      get_cached_enabled_clouds_or_refresh(STORAGE)         sky/check.py
        check_capability()  → parallel checks of every allowed cloud
          AWS: aws --version, aws configure list
          GCP: gcloud auth list, gcloud config get project
```

The stored list of enabled clouds is used if it has anything in it. An empty list means either "checked and found nothing" or "never checked", and the code treats both as "never checked". So a user with no storage credentials reruns the check on every launch.

Earlier traces put this at 4.75 s of phase A's 7.14 s, with `aws configure list` the largest part at 2.38 s. It costs less if `aws` isn't on the server's `PATH`, because the AWS check then stops at `aws --version`.

An existing cache doesn't help here. `_enabled_storage_cloud_names` in `sky/data/storage.py` reuses the answer only within a request.

## 3. Change

**Recording an empty result.** After a storage check that leaves the list empty, store this in the existing `config` table, under the key `empty_storage_check_<workspace>`:

```json
{"config_fingerprint": "<sha256 of the merged config>", "checked_at": 1793761861.6}
```

**Skipping the check.** `get_cached_enabled_clouds_or_refresh` already refreshes when the list is empty or the allowed clouds changed. It now skips that refresh when all of these hold:

| Condition | Why |
|---|---|
| The capability is storage | Compute behaves as before (§5) |
| The caller can write to the workspace | Others use the existing unstored path, unchanged |
| The allowed clouds list didn't change | A changed list must always recheck |
| The stored fingerprint matches the current config | A config edit must recheck |
| The record's age is at least 0 and under 600 s | Credentials aren't in the config (§4). A negative age means the clock moved back |

The fingerprint is the existing `current_config_fingerprint()`, a SHA-256 of the request's merged config.

**The limit is fixed from the time of the check.** Reusing the record doesn't extend it, so the check reruns at least every 10 minutes for launches that keep coming.

**What isn't skipped.** Storage-only providers (Cloudflare, CoreWeave, VastData, HuggingFace) are checked separately in `_enabled_storage_cloud_names`, and still run on every lookup.

## 4. Why fingerprint and expiry are both needed

The two conditions catch different changes:

| Change | Fingerprint | Expiry |
|---|---|---|
| Config edit, such as `aws.remote_identity` | Caught at once | Would catch it late |
| Credentials added, such as `~/.aws/credentials` | **Not seen**, since it isn't config | Caught within 10 minutes |
| Temporary check failure | **Not seen** | Caught within 10 minutes |

Checking credential files directly instead of using an expiry would mean listing every cloud's credential locations. Those include files, directories and environment variables that vary by cloud, and such a list would go out of date.

## 5. Behavior changes

| Situation | Before | After |
|---|---|---|
| Credentials added, then `sky check` | Enabled at once | Same: a non-empty list ignores the record |
| Credentials added, no `sky check` | Noticed on the next launch | **Noticed within 10 minutes** |
| Check fails temporarily, finding nothing | Retried on the next launch | **Reused for up to 10 minutes**, or until `sky check` |
| Task names a storage cloud that isn't enabled | `_is_storage_cloud_enabled` calls `check_capability` directly | Code path unchanged, not tested |
| Storage cloud already enabled | No check | Same |

Compute is excluded because an empty compute list is the error case for a launch, and a user who has just fixed their credentials should see that at once.

**Compatibility.** There's no API change or table migration. The record is one more row in `config`. An older server ignores it, and a newer server treats a missing row as "not checked". With a shared database, servers share the record too.

The key is scoped per user when Slurm `submit_as_user` is on, the same as the enabled clouds row.

## 6. Alternatives

| Alternative | Why not |
|---|---|
| Store a "checked" flag with no fingerprint or expiry | Config edits and new credentials would go unnoticed until `sky check` |
| Fingerprint only, as first suggested | Same problem for new credentials (§4) |
| Longer in-memory cache | Each server process would run its own check, and a restart would lose it |
| Have users set `allowed_clouds` | It works, and saves more (5.79 s), but only for those who know to set it |
| Apply to compute checks too | Larger behavior change, for no saving on the path measured here |

## 7. Results

**Setup:** the same commit (`407784c57`, equal to `ej-prj-i2-6`) with and without the patch, one kind node with 12 cores, a one-line `echo` on 6 nodes, the bytecode image in both arms, consolidation mode, the user's normal config, and `aws` on the server's `PATH`. There were 4 alternating blocks of 1 warm-up and 4 measured runs, so 8 measured runs per arm, and all succeeded. p-values are exact two-sided permutation tests on means.

| Phase (median, with range) | Without patch | With patch | Change | p |
|---|---|---|---|---|
| **A: client start → job row** | 6.85 s (6.5–7.1) | **2.20 s** (1.6–7.1) | **−4.65 s** | 0.0047 |
| B: row → STARTING | 2.41 s (2.1–4.8) | 2.47 s (1.8–4.5) | +0.06 s | 0.97 |
| C: STARTING → provisioning | 3.16 s (2.5–5.4) | 3.07 s (2.8–3.3) | −0.09 s | 0.43 |
| D: provisioning → job submitted | 16.16 s (14.6–26.8) | 15.08 s (14.3–21.2) | −1.08 s | 0.62 |
| E: job runs | 6.94 s (6.5–7.9) | 7.10 s (6.6–7.5) | +0.16 s | 0.69 |
| F: job ended → RUNNING | 2.37 s (2.0–4.7) | 2.35 s (2.0–2.7) | −0.02 s | 0.41 |
| G: RUNNING → SUCCEEDED | 0.11 s (0.1–0.2) | 0.14 s (0.1–0.2) | +0.03 s | 0.22 |
| H: SUCCEEDED → client exits | 2.71 s (2.2–4.3) | 2.56 s (2.0–4.2) | −0.15 s | 0.83 |
| **Client total** | 41.31 s (38.3–52.0) | **37.06 s** (34.6–43.2) | **−4.25 s** | 0.013 |

**Reading these numbers:**

- **Only phase A changes significantly.** That's where the skipped check runs.
- **Two patched runs were expiries.** `patched_b1_1` (7.14 s) and `patched_b3_4` (6.72 s) started about 610 s and 607 s after the record was written. The other 6 measured patched runs were 1.6–2.6 s.
- **This is the best case for frequency.** Launches were about 40 s apart. Launches more than 10 minutes apart would always find the record expired, and get no saving.
- **Phase C keeps its `aws configure list`.** It's a separate path, `get_cloud_credential_file_mounts`. Only `aws.remote_identity: NO_UPLOAD` removes it.
- **A separate run confirmed the record is stable.** Four launches in `bench_results/20261103-empty-storage-check-verify/` kept the same fingerprint and `checked_at`, with phase A at 9.34 s on the first and 1.97–2.36 s after that.

### Against master

A second run compared the whole branch with master (`796c5bcc8`), with no `allowed_clouds` or `NO_UPLOAD` on either side. Results are in `bench_results/20261103-i3-2-vs-master-no-tips/`. Each benchmark had 8 measured runs per side, and all succeeded.

| Benchmark (median, with range) | Master | `ej-prj-i3-2` | Change | p |
|---|---|---|---|---|
| `sky jobs launch` client total | 74.3 s (72.3–81.7) | 34.2 s (31.8–36.0) | −40.2 s | 0.0002 |
| `sky jobs launch` phase A | 7.0 s (6.6–7.2) | 2.1 s (1.8–2.3) | −4.8 s | 0.0002 |
| `sky launch` wall time | 46.70 s (41.5–56.1) | 27.57 s (24.8–33.2) | −19.13 s | 0.0002 |

- **This measures more than this change.** The gap also includes the earlier `ej-prj-i2-*` branches, and the bytecode image on the branch's side only. §7's table above is the measure of this change alone.
- **`sky launch` doesn't appear to benefit from this change.** It reaches the storage check only for tasks with storage mounts (`sky/task.py:1690`), and this task has none. That's from the code; no A/B has isolated it for `sky launch`.
- **No measured branch run hit an expired record,** with launches about 40 s apart.

## 8. Open decision: the 10-minute limit

The limit is `_EMPTY_STORAGE_CHECK_TTL_SECONDS` in `sky/check.py`. It sets the saving against how long a missed change can last:

| Limit | Who saves | How long new credentials or a failed check can last without `sky check` |
|---|---|---|
| 10 minutes (current) | Launches under 10 minutes apart | 10 minutes |
| 1 hour (suggested) | Launches under 1 hour apart | 1 hour |

Only the 10-minute limit has been tested. The saving per skipped check shouldn't depend on the limit, but that hasn't been measured.

## 9. Testing

**Unit tests** (`test_check_empty_storage_result.py`, 9 tests):

- An empty result is reused on the same config.
- A config change reruns the check, and the new result is the one reused.
- A record expires at exactly the limit, and a backward clock reruns the check.
- A changed allowed clouds list reruns the check.
- Credentials found after expiry are used, and a list stored by `sky check` takes effect at once.
- A non-empty result isn't recorded as empty.
- Compute checks are never skipped or recorded.

These ran with `test_check_persistence.py` and `data/test_enabled_storage_clouds_cache.py`, and all 46 passed. mypy is clean on both source files. The full unit suite hasn't been run.

**Not tested:** a real user adding credentials, a job using cloud storage, a remote or Postgres-backed server, or a non-writer of the workspace.

**Manual check:**

```bash
sky api stop; sky api start --deploy
sky jobs launch -y ej/task_bytecode.yaml     # runs the check and writes the record
sky jobs launch -y ej/task_bytecode.yaml     # phase A about 4.7 s shorter

sqlite3 ~/.sky/state.db \
  "select value from config where key like 'empty_storage_check_%'"
```

The stored `checked_at` should stay the same between the two launches. To see a recheck, change any value in `~/.sky/config.yaml` and launch again: `config_fingerprint` and `checked_at` should both change.

## 10. Before opening a PR

- **Base:** the branch sits on the `ej-prj-i2-*` line, so a PR needs this commit moved onto master or stacked on `dc6c01a92`.
- **One dependency:** `dc6c01a92` renames `_config_fingerprint` to `current_config_fingerprint`. Picked onto master alone, this commit must use the old name. That commit also adds the per-request cache in §2, so master's numbers may differ.
- **Test files:** the branch also carries `ej/` files added by `407784c57`, which don't belong in a PR.
- **Decide the limit** (§8).
- **Update `local_run_speedup_tips.md` once merged.** It says the check runs on every launch, and the `allowed_clouds` saving would shrink.
