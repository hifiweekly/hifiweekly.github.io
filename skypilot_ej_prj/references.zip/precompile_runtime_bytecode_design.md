# Design: Precompile the runtime venv's bytecode in the Kubernetes images

- **Status:** Proposal. Tested with a locally built image on `kind-skypilot`. No SkyPilot code or Dockerfile has changed.
- **Code under test:** `ej-prj-3-job1` (`5cb8dace3`).
- **Related:** `ray_start_sooner_ej-prj-3.md`, `launch_latency_consolidated_design.md` §15.
- **Results:**
  - `bench_results/20261101-164254-image-ab/` (launch comparison)
  - `bench_results/20261101-163023-gcs-trace2/` (pod trace)

## 1. Summary

The Kubernetes images install the runtime venv with `uv`, which doesn't compile Python bytecode by default. Every pod therefore compiles what it imports, each time it starts.

Precompiling the venv in the image cut the median `sky launch` of a 6-node cluster on kind **from 33.0 s to 26.1 s (−6.9 s, −21%, p = 0.0006)**. The only difference between those two images is the compile layer. The image grew by 180 MB.

**Proposal:** add `--compile-bytecode` to the runtime `uv pip install` in `Dockerfile_k8s` and `Dockerfile_k8s_gpu`.

## 2. Problem

### 2.1 Where the time goes before GCS starts

Workers can't start Ray until the head's GCS port opens, so everything before GCS delays the whole cluster. A timestamped trace of 5 launches on 6 nodes gave these head pod medians:

| Time | Step | Duration | Owner |
|---|---|---|---|
| 0.0 s | `uv pip install 'setuptools<70'` | 0.61 s | SkyPilot |
| ~0.8 s | `apply_patches.py` | 1.09 s | SkyPilot |
| ~1.9 s | Python startup + `import ray` | 0.37 s | Ray |
| ~2.3 s | **Remaining imports and CLI parsing** | **3.05 s** | **Ray** |
| ~5.4 s | Create `Node`, launch `gcs_server` | 0.03 s | Ray |
| ~5.4 s | `gcs_server` starts → first log line | 0.02 s | Ray |
| | **Script start → GCS first log** | **5.47 s** | |

The medians don't add up exactly. Starting GCS takes about 0.05 s; imports take 3.42 s.

### 2.2 Root cause

- **`uv` skips compilation by default.** `Dockerfile_k8s:79` and `Dockerfile_k8s_gpu:84` don't pass `--compile-bytecode`, unlike `pip`, which compiles on install by default.
- **The image confirms it:** the pins image has 0 `.pyc` files for Ray's 2,475 `.py` files, and 91 `.pyc` files for the 10,438 `.py` files in the venv's `site-packages`.
- **Pods compile at startup:** on a launched pod, the `.pyc` for `ray/scripts/scripts.py` was dated about 2–3 s after the container started.
- **The compile cost is large:** the first import of `ray.scripts.scripts` took 3.45 s in the pins image and 1.86 s in the compiled image, measured outside a cluster.

## 3. Proposal

Change the runtime install in both Dockerfiles:

```dockerfile
$HOME/.local/bin/uv pip install --compile-bytecode \
    'skypilot-nightly[remote,kubernetes]' \
    'ray[default]==2.56.1' 'pycryptodome==3.12.0' \
    'setuptools<70' 'click<8.3.0' && \
```

The benchmark used a separate `python -m compileall` layer instead (§5.1). The results therefore apply to compiled bytecode in general, but this exact flag still needs a check (§8).

### What stays uncompiled

- **Ray files changed by `apply_patches.py`:** `autoscaler`, `command_runner`, `log_monitor`, `resource_demand_scheduler`, `updater` and `worker`. Changing a source file invalidates its `.pyc`, so pods recompile those when they're imported.
- **SkyPilot itself:** the cluster's own wheel is installed at pod start, after the image is built.

### Alternatives considered

| Option | Why not (for now) |
|---|---|
| `compileall` as its own image layer | Works, as tested, but it's an extra step to maintain and adds a separate layer. It's the fallback if the flag misbehaves. |
| Compile only Ray and its heavy dependencies | Might reduce the 180 MB, but it needs a list to maintain, and the size saving hasn't been measured. |
| Skip the `ray.serve.scripts` import in `ray start` | Complementary, not a replacement (§7). |

## 4. Costs and risks

| Item | Assessment |
|---|---|
| **Image size** | 1.67 → 1.85 GB in Docker (+180 MB, about 11%). `crictl` on the kind node reports 411 → 447 MB. |
| **Pull time** | Not measured. The images were already on the node. New nodes pay any extra once. |
| **Build time** | The compile layer built in about 14 s natively. Cross-architecture builds under emulation may take longer; not measured. |
| **Python version** | `.pyc` files match the image's Python 3.10. A different interpreter ignores them and compiles as it does today. |
| **Stale bytecode** | Low risk. Python validates a `.pyc` against its source, and in the test a `.pyc` kept its build-time date in a running pod. |
| **Runtime behavior** | Same source code, so no behavior change is expected. |
| **Rollout** | `sky/clouds/kubernetes.py` says routine rebuilds repoint the existing tag to a new date tag in the catalog, without a tag bump. This looks like that kind of rebuild, but the release owners should confirm it. |
| **User images** | No change. Images built from the docs' snippet use `pip`, which compiles by default. Images built with `uv` get no benefit. |

## 5. Benchmark

### 5.1 Method

Three images, one launch at a time, on one kind node:

| Name | Image | How it was built |
|---|---|---|
| **Published** | `.../skypilot:202609010416-ray2.56.1` | The current published image |
| **Pins** | `skypilot-k8s-ej-prj-3:test` | A local `Dockerfile_k8s` build with `setuptools<70` and `click<8.3.0` |
| **Compiled** | `skypilot-k8s-ej-prj-3:compiled` | `FROM` Pins, plus `python -m compileall -q -j 0` on `site-packages` |

- **Launches:** 1 warm-up per image (dropped), then 8 measured launches per image, 27 in total. All succeeded.
- **Order:** rotated each round (published/pins/compiled, pins/compiled/published, compiled/published/pins).
- **Settings:** every image used `imagePullPolicy: IfNotPresent` and an explicit `image_id`. The pod specs confirmed both.
- **Task:** 6 nodes, `cpus: 1+`, `memory: 1+`, one `echo`.
- **Statistics:** exact two-sided permutation test on the difference of means, not adjusted for testing several metrics.

**Compiled vs Pins is the clean comparison,** because only the compile layer differs. Pins and Published were built separately (107 vs 108 resolved packages), so the gap between them can't be credited to the pins alone.

### 5.2 Results

Medians in seconds, with the range for the two totals:

| Metric | Published | Pins | **Compiled** | Compiled vs Pins | p | Compiled vs Published | p |
|---|---|---|---|---|---|---|---|
| **Client wall time** | 34.6 (32.1–35.2) | 33.0 (31.4–35.3) | **26.1** (25.2–32.1) | **−6.9** | 0.0006 | **−8.5** | 0.0003 |
| **Provisioning total** | 17.7 (16.7–18.7) | 16.9 (16.0–19.5) | **12.2** (11.4–17.5) | **−4.7** | 0.0011 | **−5.5** | 0.0006 |
| Pods ready | 3.0 | 2.8 | 3.0 | +0.1 | 0.99 | 0.0 | 0.44 |
| Runtime setup | 4.8 | 1.5 | 1.7 | +0.2 | 0.56 | −3.1 | 0.056 |
| Setup end → launched | 8.5 | 9.3 | **4.2** | **−5.1** | 0.0056 | −4.3 | 0.0002 |
| Skylet start | 4.6 | 4.6 | **2.7** | **−1.9** | 0.0002 | −1.9 | 0.0002 |
| Head container → GCS first log | 6.9 | 6.1 | **3.0** | **−3.0** | 0.0002 | −3.9 | 0.0002 |
| Head container → last raylet | 13.8 | 12.6 | **9.3** | **−3.3** | 0.0002 | −4.4 | 0.0002 |

Means for client wall time: 34.30, 33.06 and 26.82 s.

The two head container rows start from Kubernetes' `startedAt`, which has 1 s resolution. Their absolute values are less exact than §2.1's, which is why Pins shows 6.1 s against 5.47 s. Differences between images average that out.

### 5.3 Per-launch data

| Round | Published wall | Pins wall | Compiled wall | Published total | Pins total | Compiled total |
|---|---|---|---|---|---|---|
| 1 | 35.1 | 35.3 * | 26.2 | 17.3 | 19.4 * | 12.1 |
| 2 | 35.2 | 32.0 | 27.6 | 17.8 | 16.4 | 12.2 |
| 3 | 32.1 | 31.5 | 32.1 * | 16.7 | 16.3 | 17.5 * |
| 4 | 34.4 | 33.3 | 26.1 | 18.7 | 17.3 | 12.9 |
| 5 | 34.8 | 32.7 | 25.3 | 17.7 | 16.8 | 12.0 |
| 6 | 34.8 | 33.7 | 26.1 | 18.0 | 17.1 | 12.2 |
| 7 | 33.6 | 34.6 * | 25.2 | 17.3 | 19.5 * | 11.4 |
| 8 | 34.4 | 31.4 | 25.9 | 18.7 | 16.0 | 12.4 |

\* A launch with a dry-run stall of about 12 s (§6).

### 5.4 Reading the results

- **The gain is wider than Ray's imports.** GCS, full cluster join and skylet start all got faster. Skylet's gain probably comes from its dependencies being compiled, although SkyPilot's own wheel isn't.
- **About 2.2 s of the wall-time gain is outside provisioning** (−6.9 s against −4.7 s). It wasn't traced; job submission and the job's own Python startup are the likely places.
- **Runtime setup doesn't change,** which fits: its slow step is a network resolve, not Python imports.
- **Ray still finishes last in a normal launch.** Setup end → launched is 4.2 s, against 2.7 s for skylet.
- **Every Compiled launch without a stall (11.4–12.9 s) beat every Pins launch (16.0–19.5 s) on provisioning.**

## 6. What this doesn't fix

**The dry-run stall remains.** In the rebuilt images, the `setuptools` resolve is gone, but the `uv pip install --dry-run` resolve still stalls on one or two workers, in a tight 12.18–12.94 s range:

| Image | Measured launches with a stall | Effect |
|---|---|---|
| Pins | 2 of 8 | Runtime setup 10.8–11.3 s instead of about 1.5 s |
| Compiled | 1 of 8, plus the warm-up | Provisioning 17.5 s instead of about 12.2 s |

The cause isn't confirmed. Precompiling also makes the stall more visible, because Ray no longer takes long enough to hide it. `ej-prj-3-job2` moves the dry run out of the way, and it's worth retesting on the compiled image.

## 7. Related option: skip the Serve import

`ray/scripts/scripts.py:2977` (Ray 2.56.1) imports `ray.serve.scripts` only to register the `ray serve` command, and that pulls in pandas and FastAPI. With that import blocked, the CLI import took:

| Image | With Serve | Without Serve | Saving |
|---|---|---|---|
| Pins, no bytecode | 2.77 s | 1.30 s | 1.47 s |
| Compiled | 1.03 s | 0.49 s | 0.54 s |

These are idle measurements (3 runs each), not launches. Blocking the import also removes `ray serve`, so a real fix would register that command lazily through SkyPilot's Ray patches. It's the only option here that could help uncompiled user images, and it's left for a separate proposal.

## 8. Limits of this test

- **Local kind only:** one node, with images already present. There's no pull cost and no remote registry.
- **Not tested with `imagePullPolicy: Always`,** today's template default. Every image used `IfNotPresent`.
- **Not tested with `sky jobs launch`.** Only `sky launch` was measured.
- **Not tested with `--compile-bytecode`.** The test used `compileall`.
- **Worker imports weren't timed separately.** Only the head has a per-step trace.
- **One machine and one batch,** with 8 launches per image.

## 9. Test plan

1. Build `Dockerfile_k8s` with `--compile-bytecode`. Confirm that `.pyc` files exist across `site-packages`, that the pins are met, and that the size is close to 1.85 GB.
2. Build `Dockerfile_k8s_gpu` the same way and confirm it succeeds.
3. Repeat the three-image `sky launch` comparison, with the flag-built image as Compiled.
4. Run `jobs-ab` on `sky jobs launch` with the compiled image.
5. Run the Kubernetes smoke tests on the new image (`/smoke-test --kubernetes`).
6. Measure the pull time and compressed size against a real registry.

## 10. Open questions

1. Is about 180 MB acceptable for the default image? The GPU image's cost hasn't been measured.
2. Can this ship as a routine rebuild that repoints the existing tag, or does it need a new tag?
3. Should the docs recommend `--compile-bytecode` to users who build custom images with `uv`?

## 11. Reproducing

The scripts are saved beside the results, in `harness/`.

```bash
# Build the compiled image from the pins image, then load both into kind.
docker build -t skypilot-k8s-ej-prj-3:compiled \
    ej/bench_results/20261101-164254-image-ab/harness
kind load docker-image skypilot-k8s-ej-prj-3:test \
    skypilot-k8s-ej-prj-3:compiled --name skypilot

# Run the comparison (about 20 minutes), then analyze it.
bash ej/bench_results/20261101-164254-image-ab/harness/image_ab.sh
python ej/bench_results/20261101-164254-image-ab/harness/img.py \
    ej/bench_results/<timestamp>-image-ab
```

- **Base image:** the harness `Dockerfile` builds `FROM skypilot-k8s-ej-prj-3:test`, a local image. Build it from `Dockerfile_k8s` on `ej-prj-3-job1` first if you don't have it.
- **API server:** the comparison uses whichever server is running, so start it on the branch being tested.
- **Pod trace:** `bench_results/20261101-163023-gcs-trace2/harness/gcs_trace2.sh` temporarily edits the pod template and reverts it on exit.
