#!/usr/bin/env python
"""Runs bench_launch_latency.py with no speedup settings.

The benchmark's isolated servers normally set allowed_clouds: [kubernetes].
This removes it, keeping only allowed_contexts, which pins the context. The
config is rewritten after Variant.setup and before any server starts.
"""
import importlib.util
import pathlib
import sys

REPO = pathlib.Path('/run/media/ejiang/2T2/Projects/skypilot')
path = REPO / 'tests/kubernetes/launching_benchmarks/bench_launch_latency.py'
spec = importlib.util.spec_from_file_location('bench_launch_latency', path)
bench = importlib.util.module_from_spec(spec)
sys.modules['bench_launch_latency'] = bench
spec.loader.exec_module(bench)

orig_setup = bench.Variant.setup


def setup(self):
    orig_setup(self)
    config = self.runtime / 'config.yaml'
    config.write_text(
        f'kubernetes:\n  allowed_contexts:\n    - {self.context}\n')
    print(f'[{self.name}] config:\n{config.read_text()}', flush=True)


bench.Variant.setup = setup
sys.exit(bench.main())
