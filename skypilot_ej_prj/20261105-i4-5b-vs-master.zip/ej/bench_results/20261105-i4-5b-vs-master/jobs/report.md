# sky jobs launch A/B: 796c5bcc8041a9dcf92c1182fabbafd9a5ab9ed2 (796c5bcc8) vs ej-prj-i4-5 (fa974f21e)

- 6 nodes on `kind-skypilot`, consolidation mode.
- 4 alternating blocks of 1 warm-up + 4 measured runs. Measured, clean and successful runs: base 8, candidate 8.

## Phases (seconds, median and range)

| Phase | base | candidate | Δ median |
|---|---|---|---|
| A: client start -> job row created | 7.0 (6.4–7.2) | 2.3 (1.8–2.7) | -4.7 |
| B: row created -> STARTING | 2.8 (2.3–5.5) | 2.4 (1.9–3.7) | -0.4 |
| C: STARTING -> provisioning starts | 3.2 (2.5–3.6) | 3.2 (2.4–3.8) | +0.0 |
| D: provisioning -> job submitted | 33.1 (30.8–42.9) | 10.4 (9.9–11.4) | -22.6 |
| E: job runs on the cluster | 8.7 (8.2–10.0) | 6.8 (6.5–6.9) | -2.0 |
| F: job ended -> RUNNING | 2.9 (1.6–3.4) | 2.5 (2.1–2.9) | -0.5 |
| G: RUNNING -> SUCCEEDED | 12.6 (3.8–20.7) | 0.2 (0.1–1.1) | -12.4 |
| H: SUCCEEDED -> client exits | 4.8 (2.6–6.0) | 2.8 (2.6–3.9) | -2.0 |
| to_SUCCEEDED: client start -> SUCCEEDED | 70.2 (66.9–80.7) | 27.9 (27.2–29.0) | -42.2 |
| total: client total | 75.0 (70.8–83.4) | 30.8 (30.5–32.9) | -44.1 |

Permutation test on the client total (difference of means, two-sided): p = 0.0000.

## Phase D stages (seconds, median and range)

| Stage | base | candidate |
|---|---|---|
| 'Provisioning on' event -> provision log starts | 0.46 (0.1–0.9) | 0.53 (0.1–1.0) |
| create pods, wait until Running | 2.72 (2.6–3.2) | 1.89 (1.7–2.4) |
| SSH readiness | 0.25 (0.2–0.3) | 0.33 (0.3–0.4) |
| internal_file_mounts | 1.19 (1.1–2.9) | 1.23 (1.2–1.3) |
| setup_runtime_on_cluster | 7.98 (2.5–24.3) | 2.00 (1.8–2.3) |
| Ray wait + skylet start | 16.84 (7.8–20.0) | 1.06 (0.7–1.4) |
| cluster launched -> job submitted | 3.57 (3.4–5.6) | 3.52 (3.4–3.6) |
| phase D total | 33.08 (30.8–42.9) | 10.43 (9.9–11.4) |
| skylet start on its own | 1.69 (1.6–1.8) | 0.47 (0.3–0.6) |

## Runs

| Run | Job | Clean | rc | Total |
|---|---|---|---|---|
| base_b1_w | 854 | True | 0 | 91.6 |
| base_b1_1 | 855 | True | 0 | 72.6 |
| base_b1_2 | 856 | True | 0 | 70.8 |
| base_b1_3 | 857 | True | 0 | 77.0 |
| base_b1_4 | 858 | True | 0 | 81.7 |
| candidate_b2_w | 859 | True | 0 | 44.4 |
| candidate_b2_1 | 860 | True | 0 | 30.5 |
| candidate_b2_2 | 861 | True | 0 | 32.9 |
| candidate_b2_3 | 862 | True | 0 | 30.6 |
| candidate_b2_4 | 863 | True | 0 | 31.4 |
| base_b3_w | 864 | True | 0 | 79.0 |
| base_b3_1 | 865 | True | 0 | 72.9 |
| base_b3_2 | 866 | True | 0 | 83.4 |
| base_b3_3 | 867 | True | 0 | 72.9 |
| base_b3_4 | 868 | True | 0 | 77.6 |
| candidate_b4_w | 869 | True | 0 | 47.6 |
| candidate_b4_1 | 870 | True | 0 | 30.6 |
| candidate_b4_2 | 871 | True | 0 | 30.9 |
| candidate_b4_3 | 872 | True | 0 | 30.7 |
| candidate_b4_4 | 873 | True | 0 | 31.2 |
