#!/bin/bash
# master merge-base vs ej-prj-i4-5, with no speedup settings on either side.
set -u
REPO=/run/media/ejiang/2T2/Projects/skypilot
OUT=/run/media/ejiang/2T2/Projects/skypilot/ej/bench_results/20261105-i4-5b-vs-master
BASE=796c5bcc8041a9dcf92c1182fabbafd9a5ab9ed2
cd "$REPO"
export PATH="$REPO/.venv/bin:$PATH"
unset SKYPILOT_GLOBAL_CONFIG
python "$OUT/sky_launch_no_tips.py" run --baseline-ref "$BASE" --candidate-ref ej-prj-i4-5 \
    --task "$REPO/ej/task_published_ifnotpresent.yaml" \
    --candidate-task "$REPO/ej/task_bytecode.yaml" \
    --runs 8 --warmup 1 --context kind-skypilot --out "$OUT/sky-launch"
echo "sky-launch rc=$?"
python ej/reproduce_benchmarks.py jobs-ab --nodes 6 \
    --base "$BASE" --candidate ej-prj-i4-5 \
    --base-task "$REPO/ej/task_published_ifnotpresent.yaml" \
    --candidate-task "$REPO/ej/task_bytecode.yaml" \
    --blocks 4 --runs 4 --warmup 1 --out "$OUT/jobs"
echo "jobs-ab rc=$?"
sky api info | head -5
git branch --show-current
echo ALL_DONE
