# Launch latency A/B: baseline vs. ej-prj-1

| Metric | Baseline median (mean ± sd, n) | Candidate median (mean ± sd, n) | Δ median | p (one-sided) |
|---|---|---|---|---|
| post_runtime_s (primary) | 17.04s (15.43 ± 4.01, 8) | 1.87s (1.74 ± 0.77, 8) | -15.17s (-89%) | 0.0000 |
| provision_total_s | 28.66s (30.04 ± 3.87, 8) | 7.20s (7.04 ± 0.66, 8) | -21.47s (-75%) | 0.0000 |
| pods_ready_s | 2.74s (2.78 ± 0.18, 8) | 1.83s (1.89 ± 0.19, 8) | -0.92s (-33%) | 0.0000 |
| runtime_setup_s | 11.58s (11.84 ± 5.02, 8) | 3.39s (3.41 ± 0.27, 8) | -8.20s (-71%) | 0.0000 |

Commits seen in provision logs: baseline=796c5bcc8041, candidate=fa974f21e79d

## Checks

- [x] Each build ran its own, distinct commit
- [x] All launches succeeded and ran on every rank
- [x] No candidate launch fell back to restarting Ray
- [x] Candidate never ran the old polling loop
- [x] Primary metric lower with p < 0.05

**Verdict: VALID**

Primary metric `post_runtime_s` is the segment ej-prj-1 changes: from the end of `setup_runtime_on_cluster` to "Cluster launched" (Ray wait + skylet start). p is a one-sided permutation test on the means.
